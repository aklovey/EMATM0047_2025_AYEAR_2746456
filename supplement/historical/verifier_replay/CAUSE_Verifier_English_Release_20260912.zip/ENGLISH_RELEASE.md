English-language distribution

Non-English passages in documentation and recorded prompt/reasoning fields have been translated for this release. The original records are retained in the private local archive. Observed answers, scoring labels, seeds and numerical results remain those of the original experiment. Recorded token counts and original text hashes refer to the original run, not to translated passages. Recorded character offsets also refer to the original text. These translations must not be treated as byte-exact raw text or as a new experiment.
