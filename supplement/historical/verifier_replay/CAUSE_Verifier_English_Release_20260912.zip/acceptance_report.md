# Acceptance report for CAUSE probabilistic verifier integration

**Acceptance status — interface measurements, fixed-candidate replay, service restoration and AutoDL shutdown are complete.** Full online PNS and calibration with independent labels remain NOT_RUN under the original specification. Original evidence has been fully archived remotely, but no local copy of that raw archive is available. The runtime numbers below use the main task's latest terminal JSON/ledger summaries. Preparing this report made no model requests. The early GPU-not-started and POST=0 state in requirement_matrix.md has been updated and must not be used as the current conclusion.

This task established complete score-distribution retrieval, strict failure handling and discrete/continuous scoring comparisons on the same pool. Independent ground-truth labels for causal trajectories are unavailable, so it does not claim that continuous scores are more accurate and does not enable a new acceptance action.

## Completed work

- Used the existing D41 instance, first auditing without GPUs and configuring an independent client, then starting two TP=1 replicas for verification. It retained vLLM 0.27.1 and the existing Qwen3.6-35B-A3B weights, without training or downloading weights again. The actual torch version was 2.13.0+cu130 with CUDA 13.0, and the container had 240 GiB memory and 50 CPUs.
- Actual schema checks, complete score IDs, a single position, raw sampling invariance, Chat prefill/RAW comparison and the original PNS prefix capability probe all PASS on both services. The official compare completed a toy API smoke test with 3 POSTs and scores of approximately 0.9999693193 and 0.1513126762. These results are reported separately as diagnostics of the official implementation.
- Completed replay of a fixed set of 10 questions and 42 existing candidates. The main process exited with code 0 and produced 126 criterion records, comprising 122 VALID and 4 INVALID, retaining every original candidate and failure. The discrete baseline reused the same review and distribution, with 0 extra model calls.
- Delivered the three criteria, strict exception states, candidate/question/hash binding, HTTP reservations and prohibition of resending, independent recovery evidence, calibration commands and a patch for the actual PNS insertion point. The final full offline suite passed **131 tests / 14.010 seconds**, as recorded in final_test_run.log.
- The optional insertion point in the original PNS adapter is disabled by default. 10 offline cases using actual adapter/policy paths with replay rows verified that legacy objects and statistics remained unchanged. A separate no-network smoke test of the enabled factory checked the actual run_frozen_replay interface, producing three UNKNOWN records and HTTP=0. SHA256 values for the 13 original local runtime files were unchanged before and after the checks.
- Gracefully stopped the two services used by this task. The restore process, PID 20089, exited with code 0, restoring the initially stopped service state. GPU compute apps were empty and memory.used was 0 on both GPUs. Monitoring PID 2002 exited with code 0 after 5846 one-second samples and 0 read errors. The AutoDL platform shutdown state was **D41 (fxqnqh00m3-1d1e6b8d) shut down, 907 still shut down; no instance was released**.

## Measured evidence addressing the eight acceptance questions

### 1. Was vLLM retained or changed, and what exact version and reason applied?

vLLM **0.27.1** was retained. Each of the two existing GPUs hosted one TP=1 replica. Each replica continued to use BF16, max_model_len=16384, the qwen3 reasoning parser, generation_config=vllm, prefix caching and the raw_logprobs/max_logprobs=20 settings verified on the instance. The existing service already supported exact token-ID retrieval, so the inference stack was not upgraded.

The client is isolated from the inference environment. The exact description of the official dependency is PyPI llm-verifier 0.2.0, with fine_grained_reward.py pinned byte-for-byte to the audited Git commit 8db8a114355a9d7fdf9a8d1d5c87f6aeebd18770. The original PyPI module backup is retained, and complete hashes were checked before and after the modification. The entire wheel is not presented as that Git checkout.

The model's Hub revision is unknown. This task uses the local snapshot identifier fb4c30fc93d2f7a19cd4d3b0727456820a044e8ebc07c556f0abb5661fb668eb, based on SHA256 values for six configuration files and the filenames, sizes and mtime_ns of 26 shards. The full weights were not hashed, so this identifier cannot be treated as a verified Hub revision. Cache identity is restricted to this task's service lifecycle.

### 2. Were all score-token probabilities retrieved, and were there approximations or fallbacks?

Both TP1 probes passed in actual measurements. The fixed scoring suffix is two newlines followed by [score]. A–T are distinct single-token IDs 32–51. RAW requests send the actual prompt token IDs directly and return one generated position, checking usage, the complete target-ID subset and the permitted extra sampled token. Comparison with Chat prefill at the same prefix and raw sampling invariance within the prespecified tolerance passed.

The strict main path does not substitute structured_outputs, logit_bias or incomplete top-k labels for exact results. It conditionally normalises the complete raw distribution over the labels and calculates the expectation with A=1,T=0. VALID means that the scoring record's interface and distribution satisfy the protocol; it does not mean that the question or trajectory is objectively correct.

Both request schemas in OpenAPI 3.1.0 declare support for choice and logprob_token_ids. The actual constraint behaviour of choice was not independently verified, and the strict main path does not rely on it. The official compare retains its constrained/top-k behaviour and source audit and is used only as an API smoke test. Its floating-point outputs do not enter the strict main results. The main path has no fallback to a textual discrete score or a default 0.5.

### 3. What results did each of the three criteria produce, and were hard errors hidden by averaging?

| Criterion | VALID / all records | INVALID / UNKNOWN decision records | Within-group candidate-pair discrete ties → continuous ties | Selection changes across 10 decision groups |
|---|---:|---:|---:|---:|
| query_fidelity | 41 / 42 | 1 | 64/64 → 0/64 | 7 |
| derivation_validity | 40 / 42 | 2 | 27/60 → 0/60 | 6 |
| conclusion_support | 41 / 42 | 1 | 57/64 → 0/64 | 9 |

The three criteria are saved and assessed separately, without an average-score acceptance gate. All three criteria for the original invalid candidate retain UNKNOWN. A different candidate's derivation_validity review reached the 2048-token cap and terminated as review_length without a rerun. Independent ground truth for causal trajectories/criteria is insufficient, so high model scores cannot substitute for a quality judgement.

### 4. What are the tie rates, selections and joint correctness for discrete and continuous scoring?

The table above uses identical candidates, criteria, reviews and complete logprob distributions. Discrete scoring takes the argmax grade, while continuous scoring takes the conditional expectation, without changing the prompt or model or adding requests for the baseline. Valid candidate-pair counts are 64,60,64, differing because the criteria have different numbers of available records.

Ties use a tolerance of 1e-10. Continuous scores distinguish ties between discrete grades in this dataset and change diagnostic selections in 7/6/9 groups. **Removing ties or changing selections does not establish more accurate ranking. Very small continuous differences also cannot automatically be interpreted as practically meaningful quality differences.**

Joint causal correctness and TPR, FPR/TNR are **UNKNOWN / not estimated**. Existing answer-only labels cannot serve as independent labels for causal trajectories or the three criteria. Quality coverage also remains unknown. The actual pool supports only the M=1,2 sampling points; no additional sampling or candidate duplication is used to produce M=4/8/16/32.

### 5. What are the counts for incorrect acceptances, correct rejections, unknowns, recovery, truncation and interface failures?

- New acceptance actions were 0 and new rejection actions were 0; acceptance was not enabled. The classifier's incorrect-acceptance and correct-rejection counts and rates cannot be estimated without independent trajectory labels and are recorded as UNKNOWN. The absence of acceptance actions cannot be used to claim an error rate of 0.
- The main replay contains 126 criterion records, comprising 122 VALID and 4 INVALID. Three arise from the three criteria of historical invalid candidate candidate_c00ab28d9c526ee22c77835a. One arises from a truncated derivation_validity review of candidate_8efc0ca7d4caa75a35519469.
- Historical rollouts comprise 41 completed and 1 failed candidate. The failure belongs to q8752 REPLACE/r1 and was not removed from the 42 original samples. The new review_length count in this run is 1. The two failure types are accounted for separately, and ordinary max_tokens=1 score-read length is not counted as rollout truncation.
- Main replay transport failures were 0 and pending requests were 0. All 245 records have dispatch, response received and a complete response. The failed review was not rerun, and K remains 1.
- Independent recovery checks cover 42 candidates. Recovery classification is not applicable to 20 KEEP candidates; the semantic recovery mechanism is UNKNOWN for 22 DELETE/REPLACE candidates. The appearance or disappearance of literal fragments is not treated as proof that a semantic operation was reconstructed.
- Independent tools produced 212 records. Prefix provenance passed for 42, and intervention slots passed for 42. Completion and answer format each had 41 passes/1 failure. The same original generator associated with the two REPLACE candidates was independently read, giving 2 input-boundary passes. These results do not establish complete causal-derivation correctness and were not included in the blind scoring prompts.

### 6. What were the actual HTTP counts, tokens, GPU memory, latency and cache use?

| Stage | POST | GET | Actual prompt tokens | Actual completion tokens | Actual total tokens |
|---|---:|---:|---:|---:|---:|
| Dual-service capability probes | 10 | 6 | 1,144 | 14 | 1,158 |
| Official compare toy smoke | 3 | 0 | 3,129 | 819 | 3,948 |
| Main fixed-candidate replay | 245 | 0 | 878,534 | 61,950 | 940,484 |
| Total | **258** | **6** | **882,807** | **62,783** | **945,590** |

This table counts requests from the three model/capability-probe audit ledgers. Platform/Jupyter operations, material downloads and operational polling are not counted as model calls. Reserved identities, dispatch markers, confirmed responses and unknown outcomes are recorded separately. Reserved must not be treated as an HTTP request that has occurred.

The main replay's frozen ceiling was 246 POST / 4,030,464 tokens / 3,600 seconds; actual use was 245 POST. Budget charged/reserved was 1,130,560, while actual usage was 940,484. These accounting measures are kept separate. Main-run wall time was 1912.9933 seconds, median per-request latency was 6.83983 seconds, maximum latency was 116.14094 seconds, and actual client peak=2. The booster never ran and generated HTTP=0.

Peak GPU memory in one-second samples was **82,881 MiB** for GPU0 and **82,741 MiB** for GPU1. Monitoring has stopped after 5846 samples and 0 errors. These are sampled peaks, not mathematical upper bounds on memory use at every instant. After restoration, memory.used=0 on both GPUs.

Score-cache reuse was not enabled, with **0** hits. KV/prefix-cache counters cover each engine's lifetime since startup, including probes and the main replay. GPU0 recorded 304,128 hits / 440,290 queries (69.0745%), and GPU1 recorded 300,960 / 442,517 (68.0109%). These are not main-replay-only counts or score-result cache hits. Discrete scores directly reuse the existing distributions and do not add independent K. urllib time limits are implemented by prohibiting starts after the deadline, using socket timeouts and rejecting late results; exact wall-clock forced interruption is not claimed.

### 7. Were the original PNS semantics and generation budget preserved?

This run scores frozen actual candidates, with additional PNS rollout=0. KEEP/DELETE/REPLACE, the original RAW continuation and original sample counts are unchanged. Failures and duplicates are not deduplicated by content. M is the original per-condition sample count, K=1 is the number of reviews per criterion, and C=3. The verifier's 2048+1 budget does not replace the legacy rollout budget.

The shortest full question under the original complete protocol requires 40 suffix rollouts, and the adaptive path requires approximately 60 at minimum. Both exceed this task's limit of 32 additional rollouts; the two shortest questions require more. The full online smoke status is therefore **NOT_RUN_BUDGET_GATE**. Targets were not silently removed from questions, conditions were not changed, and legacy round counts were not lowered.

integration provides the actual adapter insertion point, a script for generating an isolated copy restricted by source hashes, and a disabled-by-default observer. The scope of its offline evidence for preserving legacy accepted objects and condition statistics is documented. It did not take over acceptance or rejection during an actual online PNS process. Engineering candidates [4,8,16], additional K/PPT and new acceptance thresholds were not presented as frozen formal defaults.

### 8. Was restoration actually rehearsed?

**Service restoration was actually rehearsed and passed.** The remote restore_original_service.sh calls the dual-service controller, verifies service identity for this task by PID/starttime/argv and stops the services gracefully. Restore PID 20089 exited with code 0. The initially stopped state was restored, GPU compute apps were empty, GPU memory use returned to zero on both cards, and monitoring stopped normally.

The final AutoDL D41 platform state was verified in the UI as **D41 (fxqnqh00m3-1d1e6b8d) shut down, 907 still shut down; no instance was released**. At the time, the platform displayed approximately 14 days 23 hours 59 minutes until D41 would be released. That countdown was only an observed snapshot; no release action was performed.

## Incomplete work and blockers

1. **Missing independent development candidates and trajectory/criterion labels for 50–100 candidates — CALIBRATION_NOT_RUN.** calibrate_verifier.py and calibration_usage.md are provided. They require dev/eval separation by question, explicit risk targets and independent evidence. Labels are not invented, and calibration does not use answer-only labels or model self-evaluation. acceptance_enabled=false.
2. **Full online PNS smoke — NOT_RUN_BUDGET_GATE.** The minimum valid budget of 40/60 exceeds 32. This remains unrun under the specification and is not an online-success conclusion.
3. **Local raw archive copy — not downloaded.** The remote raw archive and member-hash verification are complete, as are service and platform shutdown. The remaining limitation is that no local copy of the raw archive is available.
4. **Limits of actual quality verification.** Independent recovery auditing still has 22 semantic-recovery UNKNOWNs, and full-trajectory joint correctness has not been estimated. Interface PASS, fewer ties and code-test coverage do not resolve these limits.

## Evidence archive

Remote file

    /root/autodl-tmp/CAUSE-verifier-20260909/CAUSE-verifier-20260909-evidence.tar.gz

The archive contains **36,617,627 bytes and 2792 files**, with a PASS on per-member hash verification. Its SHA256 is **f65fc27693be2dd44cd7edb87f383851635a42c7ffa89e370c907e9f7fcb6bf3**, and the manifest SHA256 is **3a16a96329a928463d7be292c38a02117250f64c106c8fa847820db56738f18f**. It includes new raw HTTP files, three consistent SQLite backups, code actually executed at the time, environment logs and restoration evidence. Hash checks passed individually for 528 request/response files, and the hashes of three historical source files were unchanged.

The raw archive **remains on the data disk of the existing, shut-down instance and has not been downloaded locally**. The local delivery contains updated source, the frozen candidate pool, audit/statistics summaries and this report. The remote archive is authoritative for the code actually executed and raw evidence. Later local integration fixes are not presented as having been used in this model run.

## One reproduction command

The following recalculates discrete/continuous statistics from saved distributions without new model calls. Run it when the instance is reachable; model services do not need to be started. Inputs are the verified actual frozen pool and complete scoring records, and the output must be a new file.

    /root/autodl-tmp/CAUSE-verifier-20260909/client-offline-env/bin/python /root/autodl-tmp/CAUSE-verifier-20260909/package/scripts/analyze_replay.py --replay-dir "/root/autodl-tmp/CAUSE-verifier-20260909/replay-data" --scores "/root/autodl-tmp/CAUSE-verifier-20260909/replay-dual-001/score_records.jsonl" --output /root/autodl-tmp/CAUSE-verifier-20260909/reproduced_statistics.new.json

## One restoration command

This command was executed by the main task and verified to exit with code 0. It requires the instance to be reachable.

    sh /root/autodl-tmp/CAUSE-verifier-20260909/restore_original_service.sh

## Zero-request budget gate for online smoke

The local online_smoke_gate.py was actually executed. It checked the SHA256 of the original 56-question input, reproduced total safe steps=1691, and found that the minimum qid=29590 has 10 safe steps. KEEP2+DELETE2 requires at least 40>32, so it returned NOT_RUN_PROTOCOL_MINIMUM_EXCEEDS_32. The script has no execute entry point and makes 0 additional HTTP requests/rollouts. It is delivered locally only and was not deployed remotely. The command uses a new output file.

    python package/scripts/online_smoke_gate.py --source-input "C:/Users/aklovey/Documents/Codex/2026-08-17/qwen36-pns-256/work/batch56/batch_input_56.jsonl" --output online_smoke_gate_result.new.json

The local terminal summary is based on observed_runtime_results.json, remote_artifact_proof.json, online_smoke_gate_result.json and final_test_run.log. The remote path and verification values for the complete original evidence are stated above.

## Local delivery and version

Local source commit is `7db749852234deafcd4f4ecedc4e098736b5befc`. `CAUSE_Verifier_English_Release_20260912.zip` contains source, 131 tests and their log, the frozen candidate pool, independent recovery evidence, calibration/concurrency instructions and this report. `delivery_manifest.json` records each file's SHA256, and `delivery_verification.json` records archive verification. The complete Git history is also saved in `CAUSE_Verifier_source.bundle`.

The subsequently prepared concurrency ceiling is 4 per GPU and 8 overall. The 11 independent tests for `boost_replay.py` cover the shared budget and prohibition of resending, but the actual peak for this batch remains 2. The booster was not executed, and GPU throughput at concurrency 8 is not claimed to have been verified.

Installation/environment evidence in the remote archive consists of `install_offline_client.py`, `finish_client_dependencies.py`, `client_requirements_lock.txt`, `offline_dependency_copy_manifest.json`, `official_source_patch_report.json`, `environment_audit_no_gpu.json`, `gpu_environment_audit.json` and `original_service_manifest.json`. These installation scripts retain the environment paths used at the time and must not be reused blindly in another environment. `final-evidence/` contains three consistent SQLite backups. The main distributions are in `replay-dual-001/score_records.jsonl`, and raw bytes are in `verifier_http_artifacts/`.

The measured driver version was 595.58.03, with two NVIDIA RTX PRO 6000 Blackwell Server Edition GPUs, each having 97,887 MiB total memory. The separate KV cache dtype was not independently confirmed and is recorded as unknown. Model BF16 is not used to infer every cache implementation detail automatically.
