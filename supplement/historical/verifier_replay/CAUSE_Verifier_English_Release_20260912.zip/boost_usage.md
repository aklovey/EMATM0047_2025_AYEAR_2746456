# Replay booster and its actual use in this batch

The main replay in this batch used the two original TP1 services and two serial workers, with an observed peak client concurrency of **2**. The main process, PID 14366, has ended. The booster **was not enabled for this batch** and sent no additional model requests to the remote host.

The tool's total concurrency limit of 8 comes from its design of two original workers plus three additional workers per GPU, together with local overlap tests using fake transport and a real temporary SQLite database. Tests observed a mock peak concurrency of 8, only one send for the same identity, and no global-budget overrun. **This is not a measurement of GPU load, throughput or ranking quality at concurrency 8.**

For the current batch, use inspect only and do not add --execute. Do not send extra requests to reach the ceiling of 246. Failures, truncated reviews or the absence of a valid scoring prefix can all make the actual request count lower than that ceiling.

## Read-only inspect

Reuse the main run's actual paths and frozen time limit. The output must be a new directory.

    python scripts/boost_replay.py --candidates "$Candidates" --raw-rollouts "$RawRollouts" --original-requests "$OriginalRequests" --manifest "$Manifest" --config "$FrozenConfig" --original-run "$OriginalRunDirectory" --tokenizer-path "$ExistingModelPath" --endpoint-0 http://127.0.0.1:8000 --endpoint-1 http://127.0.0.1:8001 --capabilities-0 "$Capabilities0" --capabilities-1 "$Capabilities1" --journal "$SharedJournal" --http-artifacts "$SharedHttpArtifacts" --output "$NewInspectDirectory" --max-seconds "$OriginalMaxSeconds"

By default, the tool only reads the complete main pool, original parallel_plan and shared journal, then writes remaining_work_and_risks.json. It does not send HTTP requests, load model weights or operate on the old processes. The report distinguishes terminal identities, in-flight/reserved-only identities, unregistered review identities and the upper bound on unregistered score-read identities. That score-read upper bound is not a number of additional requests that must be sent.

## Constraints for future authorised use

The script preserves the original run_id, request_id, seed, payload, qid-to-GPU routing and full-pool budget. The global budget is 246 requests / 4,030,464 tokens, with reviews and score-reads each capped at 123. It is not multiplied by the number of GPUs or workers.

- If the same ID has succeeded and the original request envelope, original response bytes and SHA256 all match exactly, only the cache is reused. This is neither a new POST nor an additional set of K independent reviews.
- For RESERVED or in-flight identities, wait only for that actual identity to reach a terminal state. An observation timeout returns UNKNOWN without changing the row or resending.
- Failed identities remain failed. They are not upgraded to OK or resent.
- Only unregistered identities can enter contention through the original JournaledClient. SQLite BEGIN IMMEDIATE determines the sole owner. The loser of a Duplicate race switches to waiting/cache use rather than creating another identity.
- The six additional workers, at most three per GPU, together with the two confirmed original workers give a client concurrency ceiling of 8. A single-booster file lock prevents a second booster from starting on the same journal. Unrelated clients are outside this guarantee.
- The original processes and output files remain unchanged. Final reconstruction uses verified original responses for the same IDs. A local UNKNOWN produced by the original coordinator because of Duplicate does not override a complete actual response or conceal a genuine failure.

The tool guarantees only that its own booster completes reviews before reading scores. It cannot claim control over a global phase barrier in the original process. The old process may begin score-reading while other reviews remain active, which is recorded as runtime_ordering_change_observed.

## Interpreting states

- WAITING_FOR_SHARED_JOURNAL means actual RESERVED/in-flight identities remain. The result is only CURRENT_SHARED_JOURNAL_SNAPSHOT, and authoritative_snapshot_is_final is false. The full round cannot be described as complete.
- INCOMPLETE_SHARED_WORK means all existing identities are terminal, but actual valid review or score-read identities that have not been registered are still missing. This cannot be described as having no remaining work.
- RECONSTRUCTION_INCOMPLETE means an authoritative cache-reconstruction worker or saved artifact is incomplete. NO_NEW_WORK must not hide this failure.
- NO_NEW_WORK means no additional dispatch occurred, all registered identities are terminal, the actual valid request set is complete, and authoritative reconstruction has no failures. This invocation performs cache reconstruction only. Score-reads that are no longer valid after a truncated review are not generated merely to fill the budget.
- COMPLETE or COMPLETE_WITH_UNKNOWN means all registered identities are terminal and actual valid/unknown scores are reported. UNKNOWN is never filled with 0.5 or treated as acceptance.

The tool never generates new rollouts or enables acceptance.

## Local tests

    & 'D:\CodexTools\cause-academic\venv\Scripts\python.exe' -m unittest discover -s work/verifier-task/package/tests -p test_boost_replay.py -v

Tests use saved-response formats, fake HTTP transport and real temporary SQLite databases, with no real network model calls. Coverage includes waiting for in-flight work, no resending after terminal failure, rejection of changed payloads or corrupted responses, atomic duplicate races, the 6+2 mock peak, the shared budget, NO_NEW_WORK when a completed batch legitimately lacks score-reads after review truncation, and the requirement that active identities take precedence by displaying WAITING.
