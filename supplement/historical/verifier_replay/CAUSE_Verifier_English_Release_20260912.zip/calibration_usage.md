# Independent development calibration commands

The added package/scripts/calibrate_verifier.py reads only local files. It does not import a model or HTTP client, generate candidates or change acceptance. The legacy fixed replay pool of 42 candidates and its answer-only labels are insufficient for this calibration. Successfully reading scores through an interface must not be described as completed calibration.

Threshold candidates, permitted FPR, minimum TPR, confidence level and minimum heldout positive/negative label counts are all required arguments. Variables in the commands below must come from an independently frozen research plan; the script has no default quality threshold. Thresholds apply to the A..T conditional expected score, not P(correct).

## Inputs

- candidates.jsonl uses the frozen blind-pool format. Each row contains only candidate_id, task_id, task and rollout, and task_id must match the canonical JSON hash of the original question. The development set must contain 50–100 actual candidates; evaluation candidates are counted separately. Do not copy or resample candidates to reach the required count.
- score_records.jsonl contains saved complete raw distributions for the three criteria, with at most one record per candidate/criterion. The script recalculates expectations and verifies binding to the full candidate-text hash. Missing distributions/INVALID are abstentions and cannot be filled with 0.5.
- question_split.json explicitly lists dev_task_ids and eval_task_ids. The question sets must be completely separate and cover all candidates. Multiple candidates from the same question must not be randomly split between sets.
- independent_labels.jsonl has one row per candidate and explicitly labels all three criteria pass/fail/unknown. Its structure is shown below.
- evidence/ contains actual local JSON audit records supporting the labels. The script reads them and checks SHA256 and binding to the question, full text, criterion and judgement source. It does not execute any code within the files.

Label sidecar structure. The markers below illustrate the format only and must not be presented as evidence already obtained.

    {
      "candidate_id": "candidate_ID",
      "task_id": "task_HASH",
      "candidate_hash": "FULL_ROLLOUT_CANONICAL_JSON_SHA256",
      "criteria": {
        "query_fidelity": {
          "label": "pass",
          "source_kind": "independent_executable_check",
          "source_id": "AUDITED_CHECKER_AND_VERSION",
          "scope": "causal_criterion_trajectory",
          "model_generated": false,
          "verifier_scores_used": false,
          "evidence_refs": [{"path":"candidate_query.json","sha256":"ACTUAL_FILE_SHA256"}]
        },
        "derivation_validity": {"label":"unknown","source_kind":"unavailable","evidence_refs":[]},
        "conclusion_support": {"label":"unknown","source_kind":"unavailable","evidence_refs":[]}
      }
    }

source_kind accepts only independent_executable_check or independent_expert_audit. Human audits or executable checks must be independent of the verifier scores in this run. Answer-equivalence labels, LLM self-evaluation, high model scores and a candidate's claim to have been checked do not meet the independent-ground-truth requirement. Where evidence is unavailable, use unknown as in the example rather than inventing evidence.

Each non-unknown evidence JSON must contain the following fields.

    {
      "candidate_id": "candidate_ID",
      "task_id": "task_HASH",
      "candidate_hash": "FULL_ROLLOUT_CANONICAL_JSON_SHA256",
      "criterion": "query_fidelity",
      "label": "pass",
      "source_kind": "independent_executable_check",
      "source_id": "AUDITED_CHECKER_AND_VERSION",
      "scope": "causal_criterion_trajectory",
      "model_generated": false,
      "verifier_scores_used": false,
      "result": {"actual_check_result":"SOURCE_BACKED_EVIDENCE"},
      "result_hash": "RESULT_CANONICAL_JSON_SHA256"
    }

The canonical JSON SHA256 uses the package's cause_verifier.core.content_hash. The outer evidence ref SHA256 is computed over the actual file bytes; the two must not be confused. The researcher is responsible for the independence of evidence sources. File-format and hash verification do not themselves provide an additional scientific ground-truth judgement.

## Development plan

Run this in the task directory. The command only writes a plan, and its status remains NOT_RUN.

    & 'D:\CodexTools\cause-academic\venv\Scripts\python.exe' work/verifier-task/package/scripts/calibrate_verifier.py plan --pool-manifest work/verifier-task/replay-data/manifest.json --thresholds "$ThresholdGrid" --max-fpr $MaximumFPR --min-tpr $MinimumTPR --confidence $FamilywiseConfidence --min-heldout-positive $MinimumHeldoutPositives --min-heldout-negative $MinimumHeldoutNegatives --output work/verifier-task/calibration_plan.json

The plan reports the current pool size, the requirement for 50–100 development candidates, and the minimum number of independent heldout positive and negative questions needed for each criterion under the best-case scenario of zero errors. It does not create labels, split files or calibration thresholds. Exit code 2 means that no valid gate candidate was produced and should not trigger an automatic retry.

## Calibration once actual independent labels are available

First freeze the question split and explicit risk targets, then run the following command.

    & 'D:\CodexTools\cause-academic\venv\Scripts\python.exe' work/verifier-task/package/scripts/calibrate_verifier.py calibrate --candidates "$CalibrationData/candidates.jsonl" --scores "$CalibrationData/score_records.jsonl" --labels "$CalibrationData/independent_labels.jsonl" --split "$CalibrationData/question_split.json" --evidence-root "$CalibrationData/evidence" --calibration-id "$CalibrationId" --thresholds "$ThresholdGrid" --max-fpr $MaximumFPR --min-tpr $MinimumTPR --confidence $FamilywiseConfidence --min-heldout-positive $MinimumHeldoutPositives --min-heldout-negative $MinimumHeldoutNegatives --output "$CalibrationData/calibration_result.json"

For each criterion, the development set selects a threshold meeting the explicit empirical FPR/TPR targets, first maximising TPR, then minimising FPR, and choosing the lower threshold if a tie remains. The threshold is determined only from the development set, after which heldout metrics are calculated. A heldout failure does not trigger a new threshold selection. The same heldout set must not be repeatedly modified to obtain a pass.

Each of the three criteria separately reports all threshold candidates, the development selection, heldout TP/FP/TN/FN, unknown labels, abstentions without valid scores, TPR/FPR/FNR and metrics for the actual acceptance policy. The three criteria are not averaged to conceal hard errors.

A gate candidate additionally requires the following.

- Each criterion has explicit minimum numbers of independent positive and negative heldout labels.
- The heldout set contains at most one candidate per question, and questions are the independent evaluation sampling units. Multiple candidates from the same question are retained for descriptive statistics but cannot be treated as independent binomial trials. The script does not delete candidates to manufacture the required independent sample count.
- Six one-sided exact Clopper–Pearson bounds use Bonferroni alpha/6 to cover the three FPR upper bounds and three TPR lower bounds, meeting the joint confidence and risk/sensitivity targets declared in advance. The guarantee depends on independent question sampling. File verification cannot establish data representativeness.

Missing files, missing independent labels, insufficient development candidates or question leakage produce NOT_RUN. Completed calculations that fail evidence/risk requirements produce CALIBRATION_REJECTED. A sufficient pass produces only CALIBRATION_GATE_CANDIDATE, still with acceptance_enabled:false. Before enabling it, a separate audit must confirm that the model, tokenizer, template, criteria and scoring-protocol identities match the saved calibration scores, and acceptance mode must be explicitly selected.

## Executed protocol tests

    & 'D:\CodexTools\cause-academic\venv\Scripts\python.exe' -m unittest discover -s work/verifier-task/package/tests -p test_calibration.py -v

Tests use temporary synthetic candidates, manually specified distributions and synthetic evidence with hashes. They are not evidence of project accuracy or calibration performance. Coverage includes independent-evidence binding, rejection of answer labels/LLM labels, question leakage, minimum counts, lack of confidence guarantees despite zero empirical FPR, correlated candidates from the same question, unknown accounting, and the rule that heldout failure cannot change development thresholds.
