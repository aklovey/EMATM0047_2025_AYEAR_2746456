# CAUSE probabilistic scoring verifier

This package is an independent local vLLM client that defaults to shadow mode. The complete raw logprobs over the twenty A–T grades are used to calculate a conditional expected grade, which is not a calibrated probability of correctness. The three criteria are recorded separately, and unknown items are not automatically accepted.

The fixed replay on 2026-09-09 is complete, covering 10 questions and 42 historical candidates, with 245 main HTTP requests, 122 valid scores and 4 unknown items. Each of the two GPUs ran one TP1 replica, and the observed peak client concurrency was 2. An additional scheduling tool supporting up to 8 concurrent requests was subsequently prepared at the user's request but was not enabled for this batch. Its concurrency and protection against resending were verified using local mock transport and SQLite tests.

The independent code repository is isolated from the original project, model environment and historical candidate sources. `scripts/replay_verifier.py` defaults to preflight inspection. Real requests require the complete frozen configuration, actual capability probes and the shared ledger. Do not rerun a completed batch or interpret unused budget as requests that must be sent.

## Entry points

- `src/cause_verifier/core.py` implements scoring, hard checks and calibration gates.
- `src/cause_verifier/client.py` implements the local endpoint allowlist, atomic reservations before sending, raw request and response hashes, budgets and prohibition of resending.
- `src/cause_verifier/scorer.py` performs reviews and reads scores at a fixed position, verifying twenty unique single-token IDs at every actual prefix.
- `scripts/parallel_replay.py` shares one frozen candidate pool and budget between two TP1 services.
- `scripts/boost_replay.py` defaults to read-only inspect mode and adds at most three workers per GPU. See `boost_usage.md` in the delivery directory.
- `scripts/analyze_replay.py` derives discrete and continuous comparisons from the same saved distribution without calling the model.
- `scripts/calibrate_verifier.py` performs offline development/held-out calibration only when independent trajectory annotations are available.
- `integration/USAGE.md` describes the optional shadow insertion point in the actual legacy adapter, a copy-only patch restricted by source hashes, and verification without network access.

## Local verification

Run `python -m unittest discover -s tests -v` in this directory. All 131 final tests passed, as recorded in the delivered `final_test_run.log`. Tests use mocks or saved responses and do not issue real model requests.

The locally delivered source includes booster, calibration and integration tools that are absent from the snapshot actually executed remotely. The two versions are recorded separately, and a new source hash must not be presented as the executed version. The actual replay's raw distributions, HTTP files and consistent SQLite backup are stored in the remote evidence archive. Its path and SHA256 are recorded in `remote_artifact_proof.json` in the delivery directory.

Additional online PNS rollouts were stopped as required because the original protocol's minimum of 40/60 exceeds this task's limit of 32. Independent annotations for 50–100 trajectories were not provided, so calibration and acceptance remain disabled.
