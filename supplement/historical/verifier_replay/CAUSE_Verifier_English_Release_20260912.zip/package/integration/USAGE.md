# Optional shadow insertion point for runtime_v1

This directory provides a patch for the actual adapter that is restricted by source hashes. The original files in D:\CAUSE\qwen_pns_adaptive_20260826\runtime_v1 were not modified. 13 files have been checked locally, and the complete SHA256 list is stored in runtime_v1_shadow_patch.json. This tool has not rewritten the legacy deployment files used by the main workflow either.

## Verified paths in the actual implementation

1. The generate function inside Batch56AdaptiveAdapter.run_item in src/qwen_pns_batch56_adapter.py calls _generate_trial at original lines 410–421, then appends to vote_history and returns the same RolloutTrial. The patch calls the optional observer after _generate_trial returns and before vote_history is appended.
2. _generate_trial at original lines 458–582 continues to use the original task_from_prompt, _execute_task, response-assets checks, encoding, local_path_audit and trial_from_qwen_journal_row. The patch does not replace any of these steps.
3. parse_completion_response in runtime_bundle/batch56_runner.py, original lines 1052–1074, assigns valid=1 only when there is stop, exact prompt IDs, closed reasoning and a parseable final answer. correct is calculated separately against gold after valid. The patch can therefore infer structural completion from valid_for_vote without sending correct or gold to the observer.
4. run_adaptive_keep_delete in src/qwen_pns_adaptive.py, original lines 279–365, continues to retain invalid entries, matched rounds and all raw slots independently. run_adaptive_candidate_lineage, original lines 371–466, continues to determine acceptance using the original majority, length and legacy audit. The new observer's results do not enter these functions.

## Changes and default state

Only the adapter gains a shadow_observer constructor parameter, which defaults to None. With enabled=false, no observer is constructed, no scorer is imported, and no verifier request is generated. The optional callback's return value is completely ignored, and exceptions do not replace the original RolloutTrial object.

The allowlisted data consists only of the original question's system/user role-content, the current complete reasoning/final_content, opaque hash IDs for the task and candidate, and structural completion status. gold, correct, lineage, plaintext request keys, legacy scores, legacy audits and intervention labels are not passed to the scorer. Question and candidate text may naturally contain causal concepts. This restriction concerns engineering metadata and does not delete or alter the question.

The factory in cause_verifier_runtime_shadow.py requires explicit shadow settings, capabilities that actually PASS, a dedicated JournaledClient, a fixed ScorerConfig, a frozen question-hash allowlist, and total request and token limits. Each criterion is scored separately, with at most 6 verifier HTTP requests per candidate. It calls the package's cause_verifier.shadow.shadow_hook to write shadow observations while always keeping calibration=None and acceptance=false. Failed/UNKNOWN attempts are written to separate records and never change legacy statistics or accepted objects.

shadow_settings.disabled.json is a disabled connection template, not online budget authorisation for this run. Enabling it requires prior binding to actual caps, the same model/tokenizer/template identity, a question allowlist and fixed limits. Simply changing enabled to true and running without those checks is insufficient.

## Command that creates only a new copy

Run the following command in this directory. destination must be a new directory outside the original runtime.

    python build_shadow_runtime_copy.py --source-runtime D:\CAUSE\qwen_pns_adaptive_20260826\runtime_v1 --destination <new-isolated-runtime>

The command checks every source file, copies the 13 files to a new directory, applies three exact replacements only in that new copy, and finally rechecks that the original files are unchanged. It does not execute a runner. runtime_v1_shadow.patch provides a directly reviewable diff, and adapter_patched_preview.py is its complete preview.

## Connecting it in a future authorised run

Add both package/src and this integration directory to the runtime's PYTHONPATH. Use the following connection where the original launcher constructs Batch56AdaptiveAdapter, at original lines 79–84 of scripts/run_qwen_pns_adaptive.py.

    observer = build_shadow_observer(
        settings=frozen_shadow_settings, capabilities=verified_capabilities,
        client=dedicated_journaled_client, tokenizer=existing_local_tokenizer,
        scorer_config=frozen_scorer_config, rubrics=three_causal_rubrics,
        output_dir=new_shadow_output, allowed_evidence=explicit_allowed_evidence,
        record=local_append_only_record,
    )
    adapter = Batch56AdaptiveAdapter(
        runtime=runtime, runner=runner, config=config,
        item_workers=args.item_workers, shadow_observer=observer,
    )

build_shadow_observer is imported from cause_verifier_runtime_shadow. The remaining objects correspond to the verified interfaces in the existing run_frozen_replay. The factory connects through the keyword-only candidates argument. A no-network factory smoke test using the actual scorer's original invalid-candidate branch produced three UNKNOWN records, with both HTTP reservations and sends equal to 0. The dedicated client and scorer's total request/token limits must exactly match settings, and configuration must reserve the worst-case budget for all allowed candidates. The observer has a separate serial lock, does not use the legacy generation client, and does not include verifier requests in legacy rollout counts. The verifier still maintains its own complete accounting. The original task hash is SHA256(json.dumps({'messages':original_messages},sort_keys=True,ensure_ascii=False).encode()).

The original launcher has not been replaced, and this online connection has not been executed. The original valid minimum online budget is 40/60, exceeding this task's limit of at most 32 additional rollouts. The legacy runner's --execute is therefore not run, and its conditions or minimum rounds are not changed to manufacture a pass.

## Offline demonstration of the actual paths and its limits

    python demonstrate_shadow_no_network.py --runtime D:\CAUSE\qwen_pns_adaptive_20260826\runtime_v1 --report <new-report.json>

shadow_path_verification.json records 10 passing cases. Using the original KEEP/DELETE statistics path and the original candidate-acceptance path separately, it compares disabled observers with observers that return UNKNOWN, return a replacement object, modify a copy or throw an exception. Execution uses the original generate closure extracted from the actual adapter, the actual _generate_trial/_execute_task, the actual trial conversion and both actual policies. Only the journal, executor, asset assertions and legacy path audit use explicit fake data. The acceptance path obtains the original accept, and the observer cannot turn it into reject. The original returned object, raw/invalid counts, vote_history and final decision are all identical.

This establishes callback isolation and preservation of statistics at this insertion point. It does not establish full run_item initialisation/export, actual online scoring quality, network-failure timing or numerical equivalence under concurrent scheduling. Real network/model calls were 0, tokenizer API calls were 0, and the hashes of the current 13 local source files were identical before and after the demonstration.
