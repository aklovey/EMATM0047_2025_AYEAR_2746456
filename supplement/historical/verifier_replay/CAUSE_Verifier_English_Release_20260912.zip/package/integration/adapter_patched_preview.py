from __future__ import annotations

import concurrent.futures
import importlib.util
import json
import os
import sys
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Sequence

from .qwen_pns_adaptive import (
    POLICY_VERSION,
    AdaptivePnsCotRunResult,
    AdaptiveRolloutConfig,
    AdaptiveSeedSchedule,
    QwenPnsCotParent,
    ReplacementGeneration,
    RolloutTrial,
    generate_optimized_pnscot,
    replacement_generation_from_qwen_journal_row,
    trial_from_qwen_journal_row,
    write_pnscot_artifact_jsonl,
)


ADAPTER_VERSION = "qwen_pns_batch56_adapter_v1"


class QidAffinityRequestExecutorPool:
    """Keep every question on one generation replica while sharing a journal."""

    def __init__(
        self,
        executors: Sequence[Any],
        *,
        backend_labels: Sequence[str] | None = None,
        route_observer: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        if not executors:
            raise ValueError("at least one request executor is required")
        self._executors = tuple(executors)
        labels = tuple(backend_labels or ())
        if labels and len(labels) != len(self._executors):
            raise ValueError("backend labels must match request executors")
        self._backend_labels = labels or tuple(
            f"replica-{index}" for index in range(len(self._executors))
        )
        self._route_observer = route_observer

    def execute(self, task: Any) -> dict[str, Any]:
        backend_index = int(task.qid) % len(self._executors)
        result = self._executors[backend_index].execute(task)
        if result.get("new_post") is True and self._route_observer is not None:
            self._route_observer(
                {
                    "request_key": str(task.request_key),
                    "qid": int(task.qid),
                    "backend_index": backend_index,
                    "backend": self._backend_labels[backend_index],
                }
            )
        return result


def install_qid_affinity_request_pool(
    runtime: Any,
    runner: Any,
    *,
    base_urls: Sequence[str],
    item_workers: int,
) -> QidAffinityRequestExecutorPool:
    """Install a frozen dual-replica generation topology on one journal."""

    normalized_urls = tuple(str(url).rstrip("/") for url in base_urls)
    if len(normalized_urls) < 2:
        raise ValueError("qid-affinity routing requires at least two base URLs")
    if any(not url for url in normalized_urls):
        raise ValueError("base URLs must be non-empty")
    contract = {
        "version": "qid_mod_v1",
        "generation_base_urls": list(normalized_urls),
        "generation_route": "qid_mod_backend_count",
        "tokenize_base_url": normalized_urls[0],
        "global_item_workers": int(item_workers),
        "automatic_failover": False,
    }
    meta_key = "adaptive_api_pool_contract_v1"
    previous = runner.journal.get_meta(meta_key)
    runner.journal.set_meta(meta_key, contract, require_same=True)
    if previous is None:
        runner.journal.event("api_pool_cutover", contract)

    executors = [
        runtime.RequestExecutor(runner.journal, runtime.HttpJsonApi(url))
        for url in normalized_urls
    ]
    pool = QidAffinityRequestExecutorPool(
        executors,
        backend_labels=normalized_urls,
        route_observer=lambda payload: runner.journal.event(
            "generation_route", payload
        ),
    )
    runner.executor = pool
    return pool


class _AdaptiveRunLock:
    def __init__(self, handle: Any, *, windows: bool) -> None:
        self._handle = handle
        self._windows = windows
        self._closed = False

    def close(self) -> None:
        if self._closed:
            return
        try:
            self._handle.seek(0)
            if self._windows:
                import msvcrt

                msvcrt.locking(self._handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
        finally:
            self._closed = True
            self._handle.close()

    def __enter__(self) -> _AdaptiveRunLock:
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()


def acquire_adaptive_run_lock(path: str | Path) -> _AdaptiveRunLock:
    """Acquire a real non-blocking single-runner lock on Windows and POSIX."""

    lock_path = Path(path)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+b")
    windows = os.name == "nt"
    try:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
            os.fsync(handle.fileno())
        handle.seek(0)
        if windows:
            import msvcrt

            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, BlockingIOError) as exc:
        handle.close()
        raise RuntimeError(
            "another adaptive Qwen PNS runner already holds the run lock"
        ) from exc
    return _AdaptiveRunLock(handle, windows=windows)


@dataclass
class ExecutionAccounting:
    """Separate logical requests, journal reuse, reservations, and real POSTs."""

    requested_slots: int = 0
    reused_slots: int = 0
    registered_slots: int = 0
    actual_generation_posts: int = 0
    infrastructure_errors: int = 0

    def begin(self) -> None:
        self.requested_slots += 1

    def fail_before_registration(self) -> None:
        self.infrastructure_errors += 1

    def finish(
        self,
        *,
        existed: bool,
        row: dict[str, Any] | None,
        result: dict[str, Any] | None,
        raised: bool = False,
    ) -> None:
        if existed:
            self.reused_slots += 1
        elif row is not None:
            self.registered_slots += 1
        if result is not None:
            self.actual_generation_posts += int(bool(result.get("new_post")))
            self.infrastructure_errors += int(bool(result.get("infra_error")))
            return
        posted = bool(row and row.get("posting_at") is not None)
        self.actual_generation_posts += int(not existed and posted)
        self.infrastructure_errors += int(raised)


class Batch56AdaptiveAdapter:
    """Run the adaptive policy through the frozen batch56 Qwen runtime.

    The adapter intentionally reuses batch56's request bodies, response parser,
    reserve-before-POST journal, prompt cache, tokenizer, replacement prompt,
    and local path auditor.  Only orchestration changes: valid trials can grow
    from two to five, invalid trials consume separate bounded raw slots, and a
    deterministic 3:2 result is terminal at the five-valid horizon.
    """

    def __init__(
        self,
        *,
        runtime: Any,
        runner: Any,
        config: AdaptiveRolloutConfig | None = None,
        item_workers: int = 16,
        journal_reference: str | None = None,
        shadow_observer: Callable[[dict[str, Any]], Any] | None = None,
    ) -> None:
        self.runtime = runtime
        self.runner = runner
        self._shadow_observer = shadow_observer  # Default off; never decides acceptance.
        self.config = config or AdaptiveRolloutConfig()
        self.config.validate()
        if item_workers < 1:
            raise ValueError("item_workers must be positive")
        if item_workers > 48:
            raise ValueError("item_workers must not exceed 48")
        self.item_workers = item_workers
        reference = journal_reference or Path(runner.journal.path).name
        if not isinstance(reference, str) or not reference.strip():
            raise ValueError("journal_reference must be a nonempty string")
        self.journal_reference = reference
        self._journal_reference_explicit = journal_reference is not None
        self.seeds = AdaptiveSeedSchedule()
        self._initialized = False
        _validate_runtime(runtime)

    def initialize(self) -> None:
        """Create an adaptive journal contract without invoking model/token APIs."""

        if self._initialized:
            return
        snapshot = Path(self.runner.run_dir) / "batch_input_56_adaptive.jsonl"
        source = Path(self.runner.input_path).read_bytes()
        if snapshot.exists():
            if snapshot.read_bytes() != source:
                raise RuntimeError(
                    "adaptive run input differs from its frozen snapshot"
                )
        else:
            with snapshot.open("xb") as handle:
                handle.write(source)

        contract = {
            "adapter_version": ADAPTER_VERSION,
            "policy_version": POLICY_VERSION,
            "model": getattr(self.runtime, "MODEL", None),
            "max_model_len": getattr(self.runtime, "MAX_MODEL_LEN", None),
            "suffix_requested_max_tokens": getattr(
                self.runtime, "SUFFIX_REQUESTED_MAX_TOKENS", None
            ),
            "replacement_requested_max_tokens": getattr(
                self.runtime, "REPLACEMENT_REQUESTED_MAX_TOKENS", None
            ),
            "sampling": (
                self.runtime.sampling_fields()
                if callable(getattr(self.runtime, "sampling_fields", None))
                else None
            ),
            "initial_valid_rounds": self.config.initial_valid_rounds,
            "max_valid_rounds": self.config.max_valid_rounds,
            "max_raw_attempts_per_lineage": self.config.max_raw_attempts_per_lineage,
            "seed_schedule": asdict(self.seeds),
            "decision_rule": (
                "KEEP correct > DELETE correct at horizon "
                f"{self.config.max_valid_rounds}; "
                f"{self.config.max_valid_rounds // 2 + 1}:"
                f"{self.config.max_valid_rounds // 2} accepted"
            ),
            "invalid_trials_vote": False,
            "selection": "complete Qwen tokens, chars, candidate id; audited fail-closed",
            "item_workers": self.item_workers,
            "journal_reference": self.journal_reference,
        }
        journal = self.runner.journal
        journal.set_meta("adaptive_rollout_contract", contract, require_same=True)
        journal.register_items(self.runner.items)
        recovery = journal.recover_unknown()
        if any(recovery.values()):
            journal.event("adaptive_resume_recovery", recovery)
        recover_responses = getattr(self.runner, "_recover_response_received", None)
        if callable(recover_responses):
            recover_responses()
        self._initialized = True

    def run(self, *, output_path: str | Path) -> list[dict[str, Any]]:
        """Run/resume all items and create or verify one immutable JSONL artifact."""

        output = Path(output_path)
        reference = Path(self.journal_reference)
        referenced_journal = (
            reference if reference.is_absolute() else output.parent / reference
        ).resolve()
        actual_journal = Path(self.runner.journal.path).resolve()
        if referenced_journal != actual_journal:
            qualifier = "explicit" if self._journal_reference_explicit else "default"
            raise ValueError(
                f"{qualifier} journal reference does not resolve from the artifact directory; "
                "keep the artifact in run-dir or pass a resolvable journal_reference"
            )
        self.initialize()
        self.runner.ensure_wave_prompts(self.runner.items)
        items = list(self.runner.items)
        if self.item_workers == 1:
            artifacts = [self.run_item(item) for item in items]
        else:
            by_qid: dict[int, dict[str, Any]] = {}
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=self.item_workers
            ) as pool:
                futures = {
                    pool.submit(self.run_item, item): int(item["question_id"])
                    for item in items
                }
                for future in concurrent.futures.as_completed(futures):
                    qid = futures[future]
                    by_qid[qid] = future.result()
            artifacts = [by_qid[int(item["question_id"])] for item in items]
        self._write_or_verify_artifacts(output, artifacts)
        return artifacts

    def journal_lifecycle_accounting(self) -> dict[str, Any]:
        """Return stable journal-lifetime counts, including all resumed invocations."""

        rows = self.runner.journal.request_rows()
        states = Counter(str(row.get("state") or "missing") for row in rows)
        return {
            "registered_slots": len(rows),
            "actual_generation_posts": sum(
                row.get("posting_at") is not None for row in rows
            ),
            "responses_received": sum(
                row.get("response_received_at") is not None for row in rows
            ),
            "state_counts": dict(sorted(states.items())),
        }

    def run_item(self, item: dict[str, Any]) -> dict[str, Any]:
        """Run one registered item, or return its exact completed adaptive result."""

        qid = int(item["question_id"])
        completed = self._completed_artifact(qid)
        if completed is not None:
            return completed

        parent_tokens = self._parent_token_count(qid)
        parent_audit = self.runtime.local_path_audit(
            item,
            candidate_key="parent_original",
            reasoning=item["parent_reasoning"],
            final_content=item["parent_final_content"],
            provenance_ok=True,
        )
        if (
            parent_audit.get("passed") is not True
            or parent_audit.get("coherent", True) is False
        ):
            raise RuntimeError(f"parent path audit failed q{qid}")
        self.runner.journal.store_audit(qid, "parent_original", 0, parent_audit)

        parent = QwenPnsCotParent(
            question_id=qid,
            query_type=str(item["query_type"]),
            original_cot=str(item["parent_reasoning"]),
            parent_answer=str(item["parent_answer"]),
            original_qwen_tokens=parent_tokens,
            parent_audit=parent_audit,
        )
        segments = {
            int(segment.step_index): segment
            for segment in self.runtime.item_segments(item)
        }
        eligible_steps = [
            step
            for step, segment in segments.items()
            if not bool(segment.answer_exposed_prefix)
        ]
        if len(eligible_steps) != int(item["safe_step_count"]):
            raise RuntimeError(f"safe step count changed for q{qid}")

        accounting = ExecutionAccounting()
        vote_history: dict[int, dict[str, list[RolloutTrial]]] = {
            step: {"keep": [], "delete": []} for step in eligible_steps
        }

        def generate(
            step_index: int,
            lineage: str,
            _valid_round: int,
            raw_attempt: int,
            replacement_text: str | None,
        ) -> RolloutTrial:
            trial = self._generate_trial(
                item=item,
                parent=parent,
                step_index=step_index,
                lineage=lineage,
                raw_attempt=raw_attempt,
                replacement_text=replacement_text,
                accounting=accounting,
            )
            if self._shadow_observer is not None:
                try:
                    import hashlib
                    from cause_verifier_runtime_shadow import blind_rollout_observation
                    opaque_id = hashlib.sha256(str(trial.request_key).encode("utf-8")).hexdigest()
                    observation = blind_rollout_observation(
                        task_messages=item["messages"], reasoning=trial.reasoning,
                        final_content=trial.final_content, opaque_candidate_id=opaque_id,
                        completed=trial.valid_for_vote is True,
                    )
                    self._shadow_observer(observation)  # Return value intentionally ignored.
                except Exception:
                    pass  # Observer UNKNOWN/error cannot alter the legacy trial or counters.
            if lineage in {"keep", "delete"}:
                vote_history[step_index][lineage].append(trial)
            return trial

        def generate_replacement(step_index: int) -> ReplacementGeneration:
            history = vote_history[step_index]
            return self._generate_replacement(
                item=item,
                segment=segments[step_index],
                keep_correct=sum(trial.correct is True for trial in history["keep"]),
                delete_correct=sum(
                    trial.correct is True for trial in history["delete"]
                ),
                accounting=accounting,
            )

        result = generate_optimized_pnscot(
            parent,
            eligible_step_indexes=eligible_steps,
            generate=generate,
            generate_replacement=generate_replacement,
            full_pns_asset={"journal": self.journal_reference, "qid": qid},
            config=self.config,
        )
        self._persist_replacement_decisions(item, segments, result)
        artifact = result.artifact
        artifact["adaptive_rollout"]["completion_invocation_accounting"] = asdict(
            accounting
        )
        record = {
            "schema_version": 1,
            "result_type": ADAPTER_VERSION,
            "policy_version": POLICY_VERSION,
            "question_id": qid,
            "artifact": artifact,
        }
        self.runner.journal.complete_item(qid, record)
        return artifact

    def _generate_trial(
        self,
        *,
        item: dict[str, Any],
        parent: QwenPnsCotParent,
        step_index: int,
        lineage: str,
        raw_attempt: int,
        replacement_text: str | None,
        accounting: ExecutionAccounting,
    ) -> RolloutTrial:
        qid = int(item["question_id"])
        accounting.begin()
        execution_started = False
        try:
            if lineage not in {"keep", "delete", "replace"}:
                raise ValueError(f"unsupported lineage: {lineage}")
            if lineage == "replace" and not (
                replacement_text and replacement_text.strip()
            ):
                raise ValueError(
                    "REPLACE continuation requires frozen replacement text"
                )
            if lineage != "replace" and replacement_text is not None:
                raise ValueError("replacement text must not enter KEEP/DELETE requests")
            prompt_key = f"q{qid}-s{step_index:03d}-{lineage}"
            prompt = self.runner.journal.get_prompt(prompt_key)
            if prompt is None:
                raise RuntimeError(f"missing frozen prompt {prompt_key}")
            task = self.runtime.task_from_prompt(
                prompt,
                qid=qid,
                step=step_index,
                branch=lineage,
                rollout=raw_attempt,
                gold=item["gold_answer"],
                seeds=self.seeds,
            )
            execution_started = True
            row = self._execute_task(task, accounting)
        except Exception:
            if not execution_started:
                accounting.fail_before_registration()
            raise
        if row is None:
            return RolloutTrial(
                valid_for_vote=False,
                candidate_id=f"{lineage}_s{step_index}:t{raw_attempt}",
                request_key=task.request_key,
                error="request row missing after execution",
            )
        try:
            self.runtime.assert_response_assets(row)
        except RuntimeError as exc:
            return RolloutTrial(
                valid_for_vote=False,
                candidate_id=f"{lineage}_s{step_index}:t{raw_attempt}",
                request_key=task.request_key,
                error=f"response_asset_invalid: {exc}",
                metadata={"journal_state": row.get("state")},
            )

        encoding_error: str | None = None
        if (
            row.get("complete_chain") is not None
            and row.get("chain_token_count") is None
        ):
            try:
                encoding = self.runtime.ensure_encoding(
                    self.runner.journal,
                    self.runner.api,
                    key=f"chain-{row['request_key']}",
                    qid=qid,
                    purpose="complete_candidate_chain",
                    source_key=row["request_key"],
                    text=row["complete_chain"],
                )
                self.runner.journal.update_chain_encoding(row["request_key"], encoding)
                row = self.runner.journal.request_row(row["request_key"])
                assert row is not None
            except (
                Exception
            ) as exc:  # tokenization failure blocks export, not the answer vote
                encoding_error = f"{type(exc).__name__}: {exc}"

        audit: dict[str, Any] | None = None
        if (
            row.get("valid") == 1
            and row.get("correct") == 1
            and isinstance(row.get("chain_token_count"), int)
            and int(row["chain_token_count"]) < parent.original_qwen_tokens
        ):
            candidate_key = f"{lineage}_s{step_index}:t{raw_attempt}"
            prompt = self.runner.journal.get_prompt(row["prompt_key"])
            prefix = prompt.get("frozen_prefix") if prompt else None
            provenance_ok = bool(
                isinstance(prefix, str)
                and isinstance(row.get("reasoning_suffix"), str)
                and row.get("complete_chain") == prefix + row["reasoning_suffix"]
            )
            audit = self.runtime.local_path_audit(
                item,
                candidate_key=candidate_key,
                reasoning=str(row.get("complete_chain") or ""),
                final_content=str(row.get("final_content") or ""),
                provenance_ok=provenance_ok,
            )
            self.runner.journal.store_audit(
                qid, candidate_key, int(row.get("request_seq") or raw_attempt), audit
            )
        trial = trial_from_qwen_journal_row(
            row,
            parent_qwen_tokens=parent.original_qwen_tokens,
            parent_answer=parent.parent_answer,
            audit=audit,
        )
        if encoding_error:
            trial = RolloutTrial(
                **{
                    **asdict(trial),
                    "error": encoding_error,
                    "metadata": {**trial.metadata, "encoding_error": encoding_error},
                }
            )
        return trial

    def _generate_replacement(
        self,
        *,
        item: dict[str, Any],
        segment: Any,
        keep_correct: int,
        delete_correct: int,
        accounting: ExecutionAccounting,
    ) -> ReplacementGeneration:
        qid = int(item["question_id"])
        step = int(segment.step_index)
        request_key = f"q{qid}-s{step:03d}-replacement-generate-r0"
        trigger = {
            "qid": qid,
            "step_index": step,
            "keep_correct": keep_correct,
            "delete_correct": delete_correct,
            "triggered": True,
            "generation_request_key": request_key,
            "state": "triggered_pending",
        }
        accounting.begin()
        execution_started = False
        try:
            self.runner.journal.upsert_replacement(trigger)
            spec = self.runtime.PromptSpec(
                prompt_key=f"q{qid}-s{step:03d}-replacement-generate",
                qid=qid,
                step=step,
                branch="replacement_generate",
                endpoint="/v1/chat/completions",
                messages=self.runtime.replacement_messages(item, segment),
                requested_max_tokens=self.runtime.REPLACEMENT_REQUESTED_MAX_TOKENS,
            )
            prompt = self.runtime.ensure_prompt(
                self.runner.journal, self.runner.api, spec
            )
            task = self.runtime.task_from_prompt(
                prompt,
                qid=qid,
                step=step,
                branch="replacement_generate",
                rollout=0,
                gold=None,
                seeds=self.seeds,
            )
            execution_started = True
            row = self._execute_task(task, accounting)
            if row is None:
                raise RuntimeError("replacement request row missing after execution")
            self.runtime.assert_response_assets(row, replacement_generation=True)
            generation = replacement_generation_from_qwen_journal_row(row)
            if not generation.valid:
                raise RuntimeError(generation.error or "replacement generation invalid")
            branch = self.runtime.make_replace_branch(
                item["parent_reasoning"], segment, generation.replacement_text
            )
            replace_spec = self.runtime.PromptSpec(
                prompt_key=f"q{qid}-s{step:03d}-replace",
                qid=qid,
                step=step,
                branch="replace",
                endpoint="/v1/completions",
                frozen_prefix=branch.prefix,
                serialized_prompt=item["base_serialized_prompt"] + branch.prefix,
            )
            self.runtime.ensure_prompt(
                self.runner.journal, self.runner.api, replace_spec
            )
            self.runner.journal.upsert_replacement(
                {
                    **trigger,
                    "state": "frozen",
                    "replacement_text": generation.replacement_text,
                    "replacement_with_delimiter": branch.replacement_text,
                    "replace_prefix": branch.prefix,
                }
            )
            return generation
        except Exception as exc:
            if not execution_started:
                accounting.fail_before_registration()
            error = f"{type(exc).__name__}: {exc}"
            self.runner.journal.upsert_replacement(
                {**trigger, "state": "generation_failed", "error": error}
            )
            return ReplacementGeneration(
                valid=False, request_key=request_key, error=error
            )

    def _execute_task(
        self, task: Any, accounting: ExecutionAccounting
    ) -> dict[str, Any] | None:
        existing = self.runner.journal.request_row(task.request_key)
        existed = existing is not None
        try:
            result = self.runner.executor.execute(task)
        except Exception:
            row = self.runner.journal.request_row(task.request_key)
            accounting.finish(existed=existed, row=row, result=None, raised=True)
            raise
        row = self.runner.journal.request_row(task.request_key)
        accounting.finish(existed=existed, row=row, result=result)
        return row

    def _persist_replacement_decisions(
        self,
        item: dict[str, Any],
        segments: dict[int, Any],
        result: AdaptivePnsCotRunResult,
    ) -> None:
        qid = int(item["question_id"])
        for step_result in result.step_results:
            decision = step_result.keep_delete.decision
            triggered = decision.action == "trigger_replace"
            generation = step_result.replacement_generation
            row: dict[str, Any] = {
                "qid": qid,
                "step_index": step_result.step_index,
                "keep_correct": decision.keep_correct,
                "delete_correct": decision.delete_correct,
                "triggered": triggered,
                "generation_request_key": generation.request_key
                if generation
                else None,
                "state": (
                    "frozen"
                    if generation and generation.valid
                    else "generation_failed"
                    if triggered
                    else "operationally_inconclusive"
                    if decision.action == "inconclusive_operational"
                    else "not_triggered"
                ),
                "error": generation.error if generation else None,
            }
            if generation and generation.valid:
                branch = self.runtime.make_replace_branch(
                    item["parent_reasoning"],
                    segments[step_result.step_index],
                    generation.replacement_text,
                )
                row.update(
                    {
                        "replacement_text": generation.replacement_text,
                        "replacement_with_delimiter": branch.replacement_text,
                        "replace_prefix": branch.prefix,
                    }
                )
            self.runner.journal.upsert_replacement(row)

    def _parent_token_count(self, qid: int) -> int:
        row = next(
            (row for row in self.runner.journal.item_rows() if row["qid"] == qid), None
        )
        if row is None or not isinstance(row.get("parent_token_count"), int):
            raise RuntimeError(f"parent encoding missing for q{qid}")
        return int(row["parent_token_count"])

    def _completed_artifact(self, qid: int) -> dict[str, Any] | None:
        row = next(
            (row for row in self.runner.journal.item_rows() if row["qid"] == qid), None
        )
        if row is None or row.get("state") != "completed":
            return None
        payload = json.loads(row.get("result_json") or "null")
        if (
            not isinstance(payload, dict)
            or payload.get("result_type") != ADAPTER_VERSION
        ):
            raise RuntimeError(
                f"q{qid} was completed by a different runner; use a fresh adaptive run directory"
            )
        artifact = payload.get("artifact")
        if not isinstance(artifact, dict):
            raise RuntimeError(f"completed adaptive item q{qid} lacks its artifact")
        return artifact

    @staticmethod
    def _write_or_verify_artifacts(
        path: Path, artifacts: Sequence[dict[str, Any]]
    ) -> None:
        if not path.exists():
            write_pnscot_artifact_jsonl(path, artifacts)
            return
        existing = [
            json.loads(line)
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        if existing != list(artifacts):
            raise RuntimeError(
                "existing adaptive PNSCoT artifact differs; refusing overwrite"
            )


def load_batch56_runtime(path: str | Path) -> ModuleType:
    """Load the copied frozen batch56 runner without modifying its source."""

    runner_path = Path(path).resolve()
    if not runner_path.is_file():
        raise FileNotFoundError(runner_path)
    module_name = "cause_qwen_batch56_runtime"
    previous = sys.modules.pop(module_name, None)
    sys.path.insert(0, str(runner_path.parent))
    try:
        spec = importlib.util.spec_from_file_location(module_name, runner_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load batch56 runtime from {runner_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        _validate_runtime(module)
        return module
    except Exception:
        sys.modules.pop(module_name, None)
        if previous is not None:
            sys.modules[module_name] = previous
        raise
    finally:
        sys.path.remove(str(runner_path.parent))


def _validate_runtime(runtime: Any) -> None:
    required = (
        "PromptSpec",
        "REPLACEMENT_REQUESTED_MAX_TOKENS",
        "assert_response_assets",
        "ensure_encoding",
        "ensure_prompt",
        "item_segments",
        "local_path_audit",
        "make_replace_branch",
        "replacement_messages",
        "task_from_prompt",
    )
    missing = [name for name in required if not hasattr(runtime, name)]
    if missing:
        raise TypeError(f"batch56 runtime is missing: {', '.join(missing)}")
