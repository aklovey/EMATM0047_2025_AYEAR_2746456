"""Create an isolated runtime copy and apply only the source-hash-pinned shadow delta."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def sha(data):
    return hashlib.sha256(data).hexdigest()


def build(source_runtime, destination, patch_path):
    source, destination = Path(source_runtime).resolve(), Path(destination).resolve()
    if source == destination or source in destination.parents:
        raise ValueError("Output must be outside the original runtime")
    if destination.exists():
        raise ValueError("Output must be a new directory")
    patch = json.loads(Path(patch_path).read_text(encoding="utf-8"))
    originals = {}
    for relative, expected in patch["source_sha256"].items():
        original = (source / relative).read_bytes()
        if sha(original) != expected:
            raise ValueError("Source changed: " + relative)
        originals[relative] = original
    relative = patch["target"]
    modified = originals[relative].decode("utf-8")
    for hunk in patch["replacements"]:
        if modified.count(hunk["old"]) != 1:
            raise ValueError("Original insertion context is not unique")
        modified = modified.replace(hunk["old"], hunk["new"], 1)
    compiled_bytes = modified.encode("utf-8")
    if sha(compiled_bytes) != patch["target_sha256"]:
        raise ValueError("Constructed patched source hash mismatch")
    compile(modified, relative, "exec", dont_inherit=True)
    destination.mkdir(parents=True)
    for name, data in originals.items():
        output = destination / name
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(compiled_bytes if name == relative else data)
    if any(sha((source / name).read_bytes()) != expected for name, expected in patch["source_sha256"].items()):
        raise RuntimeError("Original source changed during copy")
    return {"status": "ISOLATED_SHADOW_COPY_PREPARED", "source_runtime": str(source),
        "destination": str(destination), "original_files_unchanged": True,
        "copied_files": len(originals), "shadow_default": "off",
        "model_calls": 0, "patched_adapter_sha256": patch["target_sha256"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-runtime", required=True)
    parser.add_argument("--destination", required=True)
    parser.add_argument("--patch", default=str(Path(__file__).with_name("runtime_v1_shadow_patch.json")))
    args = parser.parse_args()
    print(json.dumps(build(args.source_runtime, args.destination, args.patch), indent=2))
