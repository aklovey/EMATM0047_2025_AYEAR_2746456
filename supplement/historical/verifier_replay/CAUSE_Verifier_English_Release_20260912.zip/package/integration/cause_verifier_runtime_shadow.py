"""Optional observer for the exact runtime_v1 adapter insertion point.

This module never receives the legacy correctness vote, gold, audit, lineage,
parent chain, or plaintext request key. The adapter ignores its return value.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import threading
from typing import Any, Mapping


def blind_rollout_observation(*, task_messages, reasoning, final_content,
                              opaque_candidate_id, completed):
    if not isinstance(opaque_candidate_id, str) or len(opaque_candidate_id) != 64 or any(
            char not in "0123456789abcdef" for char in opaque_candidate_id):
        raise ValueError("Candidate identity must already be an opaque SHA256")
    messages = []
    for message in task_messages:
        if (not isinstance(message, dict) or set(message) != {"role", "content"}
                or message["role"] not in ("system", "user")
                or not isinstance(message["content"], str)):
            raise ValueError("Only original textual task messages are allowed")
        messages.append({"role": message["role"], "content": message["content"]})
    if not messages or not isinstance(reasoning, str) or not isinstance(final_content, str):
        raise ValueError("Missing original task or candidate text")
    task = {"messages": messages}
    task_id = hashlib.sha256(json.dumps(task, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    return {"candidate_id": opaque_candidate_id, "task_id": task_id, "task": task,
            "rollout": {"reasoning": reasoning, "final_content": final_content},
            "operational": {"status": "valid" if completed is True else "unknown",
                            "completed": completed is True,
                            "finish_reason": "stop" if completed is True else None}}


def build_shadow_observer(*, settings: Mapping[str, Any], capabilities, client,
                          tokenizer, scorer_config, rubrics, output_dir,
                          allowed_evidence=(), record):
    """Explicit factory; importing this module or an off setting makes no HTTP.

    Bind a dedicated JournaledClient and frozen ScorerConfig before any legacy
    generation. This entry point never permits acceptance. Each observed valid
    candidate requires at most six verifier HTTP requests (3 review + 3 read).
    """
    if settings.get("enabled") is not True:
        return None
    if settings.get("mode") != "shadow" or settings.get("acceptance_enabled") is not False:
        raise ValueError("Only explicitly enabled shadow mode is supported")
    maximum = settings.get("max_candidates")
    if isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < 1:
        raise ValueError("Freeze a positive max_candidates before starting")
    if not settings.get("allowed_task_ids") or not all(
            isinstance(value, str) and len(value) == 64 for value in settings["allowed_task_ids"]):
        raise ValueError("Freeze the source-question hash allowlist")
    from cause_verifier.client import JournaledClient
    from cause_verifier.scorer import (_capability, sanitize_blind_candidate,
        sanitize_evidence, run_frozen_replay)
    from cause_verifier.core import Candidate, HardCheck, ScoreRecord, verify_rollout
    from cause_verifier.shadow import shadow_hook
    if not isinstance(client, JournaledClient):
        raise TypeError("A dedicated no-resend JournaledClient is required")
    if settings.get("max_http_requests") != 6 * maximum:
        raise ValueError("Freeze exactly six verifier HTTP slots per allowed candidate")
    if client.limits["global"].max_requests != settings["max_http_requests"]:
        raise ValueError("Dedicated client global request cap differs from frozen shadow settings")
    if client.limits["global"].max_tokens != settings.get("max_tokens"):
        raise ValueError("Explicit shadow and client token caps must match")
    if scorer_config.max_requests != settings["max_http_requests"] or scorer_config.max_tokens != settings["max_tokens"]:
        raise ValueError("Scorer and client must share the same frozen global budgets")
    scorer_config.validate()
    _capability(capabilities, scorer_config, client)
    evidence = list(allowed_evidence)
    sanitize_evidence(evidence)  # Reject oracle or unapproved evidence before any HTTP.
    target = Path(output_dir).resolve()
    if target.exists() and any(target.iterdir()):
        raise ValueError("A new separate observer output directory is required")
    target.mkdir(parents=True, exist_ok=True)
    lock, seen = threading.Lock(), set()

    def observe(envelope):
        # Copy the whitelist before invoking the scorer; mutation cannot reach legacy objects.
        with lock:
            if set(envelope) != {"candidate_id", "task_id", "task", "rollout", "operational"}:
                raise ValueError("Shadow envelope contains non-allowlisted fields")
            row = sanitize_blind_candidate({key: envelope[key] for key in
                ("candidate_id", "task_id", "task", "rollout")})
            row = json.loads(json.dumps(row, ensure_ascii=False))
            operational = dict(envelope["operational"])
            if set(operational) != {"status", "completed", "finish_reason"}:
                raise ValueError("Only structural completion status is permitted")
            if row["task_id"] not in settings["allowed_task_ids"]:
                return {"status": "UNKNOWN", "reason": "question_outside_frozen_allowlist"}
            cid = row["candidate_id"]
            if cid in seen or len(seen) >= maximum:
                return {"status": "UNKNOWN", "reason": "duplicate_or_observation_budget"}
            seen.add(cid)  # Reserve observer identity before any scoring, including failures.
            destination = target / cid
            summary = run_frozen_replay(candidates=[row], operational_status={cid: operational},
                evidence_by_candidate={cid: evidence}, client=client, tokenizer=tokenizer,
                config=scorer_config, capabilities=capabilities, rubrics=rubrics,
                output_dir=destination)
            raw_scores = json.loads((destination / "score_records.json").read_text(encoding="utf-8"))
            scores = {item["criterion"]: ScoreRecord(**item) for item in raw_scores}
            verification = verify_rollout(scores, [HardCheck("independent_original_question_evidence",
                "unknown", detail="Shadow attachment has no independent trajectory labels")],
                task_information_sufficient=True, rollout_finish_reason=operational["finish_reason"],
                rollout_completed=operational["completed"])
            candidate = Candidate(cid, row["rollout"], verification, objective_value=0.)
            # The legacy callback return object never enters this observer. This local
            # sentinel demonstrates that package.shadow cannot override a decision.
            sentinel = object()
            wrapped = shadow_hook(lambda: sentinel, parent_id=cid,
                parent_rollout=row["rollout"], candidates=[candidate],
                record=lambda event: record({"candidate_id": cid, "task_id": row["task_id"],
                    "event": event, "scoring_summary": summary,
                    "observer_http_accounting": client.summary(),
                    "legacy_decision_modified": False, "legacy_generation_budget_modified": False}),
                calibration=None)
            assert wrapped() is sentinel
            return {"status": verification.status, "acceptance_enabled": False}
    def observer(envelope):
        try:
            outcome = observe(envelope)
            if outcome.get("status") in ("UNKNOWN", "unknown"):
                try:
                    record({"event": "verifier_shadow_unknown",
                            "candidate_id": envelope.get("candidate_id"), "outcome": outcome,
                            "legacy_decision_modified": False,
                            "observer_http_accounting": client.summary()})
                except Exception:
                    pass
            return outcome
        except Exception as exc:
            try:
                record({"event": "verifier_shadow_error", "error_type": type(exc).__name__,
                        "legacy_decision_modified": False,
                        "observer_http_accounting": client.summary()})
            except Exception:
                pass
            return {"status": "UNKNOWN", "reason": "observer_exception", "acceptance_enabled": False}
    return observer
