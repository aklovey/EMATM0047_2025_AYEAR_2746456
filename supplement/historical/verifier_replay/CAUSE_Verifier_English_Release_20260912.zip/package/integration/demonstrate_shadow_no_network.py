"""Exercise real adapter closure, _generate_trial and adaptive decisions with replay rows."""
import argparse
import ast
import copy
from dataclasses import asdict
import hashlib
import importlib.util
import json
from pathlib import Path
import socket
import sys
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

sys.dont_write_bytecode = True  # The original runtime is strictly read-only.
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def demonstrate(runtime_path):
    runtime_path = Path(runtime_path).resolve()
    frozen = json.loads((HERE / "runtime_v1_shadow_patch.json").read_text(encoding="utf-8"))
    def current_hashes():
        return {name: hashlib.sha256((runtime_path/name).read_bytes()).hexdigest()
                for name in frozen["source_sha256"]}
    before = current_hashes()
    if before != frozen["source_sha256"]:
        raise ValueError("Current runtime files differ from the reviewed snapshot")
    package_name = "_offline_real_pns_shadow_test"
    package = ModuleType(package_name)
    package.__path__ = [str(runtime_path / "src")]
    sys.modules[package_name] = package
    core = load_module(package_name + ".qwen_pns_adaptive",
                       runtime_path / "src/qwen_pns_adaptive.py")
    adapter_module = load_module(package_name + ".qwen_pns_batch56_adapter",
                                 HERE / "adapter_patched_preview.py")
    source = (HERE / "adapter_patched_preview.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    klass = next(node for node in tree.body if isinstance(node, ast.ClassDef)
                 and node.name == "Batch56AdaptiveAdapter")
    run_item = next(node for node in klass.body if isinstance(node, ast.FunctionDef)
                    and node.name == "run_item")
    original_closure = next(node for node in run_item.body if isinstance(node, ast.FunctionDef)
                            and node.name == "generate")
    factory = ast.parse("def make_generate(self,item,parent,accounting,vote_history):\n pass\n").body[0]
    factory.body = [copy.deepcopy(original_closure), ast.Return(ast.Name("generate", ast.Load()))]
    namespace = dict(adapter_module.__dict__)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[factory], type_ignores=[])),
                 "<exact-real-generate-closure>", "exec"), namespace)
    outcomes = []
    for policy_name in ("keep_delete", "candidate_acceptance"):
        baseline = None
        for observer_mode in ("off", "unknown", "replacement_return", "mutate_copy", "raise"):
            observed = []
            item = {"question_id": 1, "gold_answer": "yes",
                    "messages": [{"role": "user", "content": "Synthetic original causal question"}],
                    "intervention_label": "DO_NOT_LEAK_INTERVENTION",
                    "audit_reference": {"offline_oracle": "DO_NOT_LEAK_ORACLE"}}
            item_before = copy.deepcopy(item)
            parent = core.QwenPnsCotParent(1, "synthetic", "Frozen parent reasoning", "yes",
                                           100, {"passed": True})
            rows = {}
            def task_from_prompt(prompt, *, qid, step, branch, rollout, gold, seeds):
                key = f"q{qid}-s{step:03d}-{branch}-r{rollout}"
                valid = not (branch == "keep" and rollout == 1)
                correct = valid and (branch == "keep" or policy_name == "candidate_acceptance")
                rows[key] = {"request_key": key, "prompt_key": f"q{qid}-s{step:03d}-{branch}",
                    "branch": branch, "step_index": step, "rollout": rollout, "state": "completed",
                    "complete_chain": "prefix Fixed synthetic derivation.", "reasoning_suffix": "Fixed synthetic derivation.",
                    "final_content": '{"answer":"yes"}' if correct else '{"answer":"no"}',
                    "valid": int(valid), "correct": int(correct), "chain_token_count": 20,
                    "chain_char_count": 34, "parsed_answer": "yes" if correct else "no",
                    "finish_reason": "stop" if valid else "length",
                    "invalid_reason": None if valid else "mock_truncation", "request_seq": rollout}
                return SimpleNamespace(request_key=key, gold_answer=gold)
            journal = SimpleNamespace(
                get_prompt=lambda key: {"prompt_key": key, "frozen_prefix": "prefix "},
                request_row=lambda key: rows.get(key), store_audit=lambda *args: None)
            runner = SimpleNamespace(journal=journal,
                executor=SimpleNamespace(execute=lambda task: {"new_post": False, "infra_error": False}),
                api=SimpleNamespace(post=lambda *a, **kw: (_ for _ in ()).throw(AssertionError("NETWORK FORBIDDEN"))))
            runtime = SimpleNamespace(task_from_prompt=task_from_prompt,
                assert_response_assets=lambda row: None,
                local_path_audit=lambda *a, **kw: {"passed": True, "fixture": "fake offline audit"},
                ensure_encoding=lambda *a, **kw: (_ for _ in ()).throw(AssertionError("TOKEN API FORBIDDEN")))
            def observer(payload):
                observed.append(copy.deepcopy(payload))
                if observer_mode == "raise":
                    raise RuntimeError("synthetic observer failure")
                if observer_mode == "mutate_copy":
                    payload["task"]["messages"][0]["content"] = "observer attempted mutation"
                    payload["rollout"]["reasoning"] = "observer attempted replacement"
                return {"status": "UNKNOWN", "replace_legacy_trial": True, "accepted": False}
            adapter = adapter_module.Batch56AdaptiveAdapter.__new__(adapter_module.Batch56AdaptiveAdapter)
            adapter.runtime, adapter.runner = runtime, runner
            adapter.seeds = core.AdaptiveSeedSchedule()
            adapter._shadow_observer = None if observer_mode == "off" else observer
            accounting = adapter_module.ExecutionAccounting()
            history = {1: {"keep": [], "delete": []}}
            generate = namespace["make_generate"](adapter, item, parent, accounting, history)
            originals = []
            def invoke(branch, matched, raw):
                trial = generate(1, branch, matched, raw, None)
                originals.append(trial)
                if branch in ("keep", "delete"):
                    assert history[1][branch][-1] is trial
                return trial
            with patch.object(socket, "socket", side_effect=AssertionError("NETWORK FORBIDDEN")):
                if policy_name == "keep_delete":
                    outcome = core.run_adaptive_keep_delete(invoke)
                else:
                    outcome = core.run_adaptive_candidate_lineage("delete", invoke, parent=parent)
            packed = {"outcome": asdict(outcome), "accounting": asdict(accounting),
                      "vote_history": {key: [asdict(value) for value in values]
                                       for key, values in history[1].items()}}
            if baseline is None:
                baseline = packed
            assert packed == baseline, "Observer changed legacy decision/counts/objects"
            assert item == item_before, "Observer mutated original item"
            assert accounting.actual_generation_posts == 0
            if observer_mode != "off":
                assert len(observed) == len(originals)
                for envelope in observed:
                    assert set(envelope) == {"candidate_id", "task_id", "task", "rollout", "operational"}
                    serialized = json.dumps(envelope)
                    assert "DO_NOT_LEAK" not in serialized and "gold_answer" not in serialized
                    assert "correct" not in envelope["operational"]
            if policy_name == "candidate_acceptance":
                assert outcome.decision.action == "accept"
                assert any(outcome.selected_trial.trial is trial for trial in originals)
            outcomes.append({"policy": policy_name, "observer": observer_mode,
                "legacy_result_equal": True, "same_return_object_in_history": True,
                "raw_slots": accounting.requested_slots, "journal_reused_slots": accounting.reused_slots,
                "generation_posts": 0, "observed_callbacks": len(observed),
                "decision": asdict(outcome.decision),
                "legacy_result_sha256": hashlib.sha256(json.dumps(packed, sort_keys=True).encode()).hexdigest()})
    after = current_hashes()
    assert before == after
    return {"status": "PASS_OFFLINE_REAL_ADAPTER_PATH_WITH_REPLAY_ROWS",
        "cases": outcomes, "original_file_count": len(before), "original_files_unchanged": before == after,
        "source_hashes": before, "model_calls": 0, "tokenizer_api_calls": 0,
        "executed_real_paths": ["Batch56AdaptiveAdapter.run_item.generate closure",
            "Batch56AdaptiveAdapter._generate_trial", "Batch56AdaptiveAdapter._execute_task",
            "trial_from_qwen_journal_row", "run_adaptive_keep_delete", "run_adaptive_candidate_lineage"],
        "mock_boundaries": ["journal replay rows", "executor returns new_post=False",
            "prompt task construction", "response-assets assertion", "local path audit fixture"],
        "not_verified": ["actual online model transport", "full run_item initialization/export",
            "online timing or batch-scheduling numerical equivalence"],
        "online_not_run_reason": "Current original 40/60 minimum exceeds the 32-new-rollout cap; no budget reduction or protocol substitution"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", required=True)
    parser.add_argument("--report", required=True)
    args = parser.parse_args()
    result = demonstrate(args.runtime)
    with Path(args.report).open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
    print(json.dumps({"status": result["status"], "cases": len(result["cases"]),
                      "model_calls": 0, "original_files_unchanged": True}))
