#!/usr/bin/env python3
"""Analyze exact score records without regenerating any candidate/distribution."""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.replay import coverage_curves, read_jsonl, summarize_scores, write_frozen


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay-dir", type=Path, required=True)
    parser.add_argument("--scores", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = list(read_jsonl(args.replay_dir / "raw_rollouts.jsonl"))
    labels = list(read_jsonl(args.replay_dir / "offline_labels.jsonl"))
    scores = list(read_jsonl(args.scores))
    result = summarize_scores(raw, scores, offline_labels=labels)
    result["coverage"] = coverage_curves(raw, labels)
    write_frozen(args.output, result)
    print(json.dumps({"status": result["status"], "score_records": len(scores),
                      "output": str(args.output.resolve())}))


if __name__ == "__main__":
    main()
