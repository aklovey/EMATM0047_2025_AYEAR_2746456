#!/usr/bin/env python3
"""Run isolated post-hoc recovery and executable evidence checks; zero model calls."""
import argparse
import json
import sqlite3
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.replay import file_sha256, read_jsonl, write_frozen
from cause_verifier.recovery_evidence import audit_recovery_evidence, inspect_openapi_choice


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--raw-rollouts", type=Path, required=True)
    parser.add_argument("--original-requests", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--source-journal", type=Path, help="Optional complete original read-only PNS journal to recover existing replacement-generator evidence")
    parser.add_argument("--openapi", type=Path, help="Optional saved real OpenAPI body or HTTPRecord JSON; never fetched here")
    args = parser.parse_args()
    raw_rows = list(read_jsonl(args.raw_rollouts))
    generators = []
    if args.source_journal:
        connection = sqlite3.connect(args.source_journal.resolve(strict=True).as_uri() + "?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        try:
            for qid, step in sorted({(row["question_id"], row["target_step"]) for row in raw_rows if row["condition"] == "replace"}):
                found = connection.execute("SELECT * FROM requests WHERE qid=? AND step_index=? AND branch='replacement_generate'", (qid, step)).fetchall()
                if len(found) != 1:
                    raise ValueError("Expected exactly one original frozen replacement-generation request")
                generators.append({key: value for key, value in dict(found[0]).items() if key != "headers_json"})
        finally:
            connection.close()
    result = audit_recovery_evidence(list(read_jsonl(args.input)), raw_rows,
                                     list(read_jsonl(args.original_requests)), run_id=args.run_id,
                                     replacement_generators=generators)
    manifest = {"run_id": args.run_id, "source_files": [{"role": name, "path": str(path.resolve()), "sha256": file_sha256(path)}
        for name, path in (("input", args.input), ("raw_rollouts", args.raw_rollouts), ("original_requests", args.original_requests))],
        "summary": result["summary"], "posthoc_only": True, "scoring_distribution_changed": False}
    if args.source_journal:
        manifest["source_files"].append({"role": "complete_original_journal", "path": str(args.source_journal.resolve()),
                                         "sha256": file_sha256(args.source_journal)})
    write_frozen(args.output / "recovery_records.jsonl", result["records"], jsonl=True)
    write_frozen(args.output / "tool_evidence.jsonl", result["evidence"], jsonl=True)
    write_frozen(args.output / "manifest.json", manifest)
    write_frozen(args.output / "original_replacement_generators.jsonl", generators, jsonl=True)
    if args.openapi:
        observed = inspect_openapi_choice(json.loads(args.openapi.read_text(encoding="utf-8")))
        observed["source_file"] = str(args.openapi.resolve())
        observed["source_sha256"] = file_sha256(args.openapi)
        write_frozen(args.output / "structured_outputs_choice.json", observed)
    print(json.dumps({"status": "POSTHOC_EVIDENCE_COMPLETE", "output": str(args.output.resolve()), **result["summary"]}))


if __name__ == "__main__":
    main()
