#!/usr/bin/env python3
"""Add three workers per existing GPU without stopping or modifying the old run.

Existing identities are read/waited, never resent. Six new serial workers plus
the unchanged two original workers give at most eight client dispatches. SQLite
BEGIN IMMEDIATE in the unchanged client arbitrates ownership and all budgets.
"""
from __future__ import annotations
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing, contextmanager
from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import threading
import time

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from cause_verifier.client import (HTTPRecord, JournaledClient, DuplicateRequestError,
                                  _canonical_endpoint, _json_bytes)
from cause_verifier.core import CRITERIA, canonical_json
from cause_verifier.scorer import (ScorerConfig, ScorerPreflightError, _capability,
    bind_operational_status, run_frozen_replay, verify_frozen_pool_manifest)
from parallel_replay import (assign_workers, freeze, full_pool_limits, read_json, read_jsonl,
                             recover_worker_records, load_tokenizer_and_snapshot)


class PayloadMismatch(ScorerPreflightError):
    pass


def journal_rows(path):
    uri = Path(path).resolve().as_uri() + "?mode=ro"
    with closing(sqlite3.connect(uri, uri=True, timeout=30)) as db:
        db.row_factory = sqlite3.Row
        return [dict(row) for row in db.execute("SELECT * FROM requests ORDER BY reserved_at")]


def one_row(path, identity):
    uri = Path(path).resolve().as_uri() + "?mode=ro"
    with closing(sqlite3.connect(uri, uri=True, timeout=30)) as db:
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT * FROM requests WHERE request_id=?", (identity,)).fetchone()
        return dict(row) if row else None


class Audit:
    def __init__(self, path=None):
        self.path = Path(path) if path else None
        self.lock = threading.Lock()
        self.events = []

    def record(self, action, **fields):
        row = {"at": time.time(), "action": action, **fields}
        with self.lock:
            self.events.append(row)
            if self.path:
                with self.path.open("a", encoding="utf-8", newline="\n") as handle:
                    handle.write(canonical_json(row) + "\n")
                    handle.flush()
                    os.fsync(handle.fileno())


class ExtraSlots:
    """Only fresh delegate attempts occupy the six added slots, three per GPU."""
    def __init__(self):
        self.gpu = [threading.BoundedSemaphore(3), threading.BoundedSemaphore(3)]
        self.global_slots = threading.BoundedSemaphore(6)
        self.lock = threading.Lock()
        self.active = 0
        self.peak = 0
        self.per_gpu = [0, 0]
        self.gpu_peak = [0, 0]

    @contextmanager
    def acquire(self, gpu):
        with self.gpu[gpu], self.global_slots:
            with self.lock:
                self.active += 1
                self.per_gpu[gpu] += 1
                self.peak = max(self.peak, self.active)
                self.gpu_peak[gpu] = max(self.gpu_peak[gpu], self.per_gpu[gpu])
            try:
                yield
            finally:
                with self.lock:
                    self.active -= 1
                    self.per_gpu[gpu] -= 1


@dataclass
class ReplayHTTPRecord(HTTPRecord):
    replay_cache_hit: bool = False
    replay_wait_seconds: float = 0.0
    new_transport_dispatch_marked: bool = False
    independent_review_increment: int = 0


class ReplayAwareClient:
    """A read-only observer of existing rows, with one delegate attempt for new IDs."""
    def __init__(self, delegate, *, gpu, owners, audit, slots, wait_seconds=900,
                 poll_seconds=.25, allow_new=True, barrier=None, worker=None):
        self.delegate, self.endpoint = delegate, delegate.endpoint
        self.gpu, self.owners, self.audit, self.slots = gpu, owners, audit, slots
        self.wait_seconds, self.poll_seconds, self.allow_new = wait_seconds, poll_seconds, allow_new
        self.barrier, self.worker = barrier, worker
        if wait_seconds < 0 or poll_seconds <= 0:
            raise ValueError("Invalid journal observation time budget")

    def _expected(self, path, payload, fields):
        if self.owners.get(fields["candidate_id"]) != self.gpu:
            raise PayloadMismatch("Candidate-to-GPU routing differs from the original frozen run")
        if fields["stage"] not in {"verifier_review", "verifier_score_read"}:
            raise PayloadMismatch("Booster permits no new rollout or non-verifier HTTP stage")
        envelope = {"method": "POST", "endpoint": self.endpoint, "path": path,
            "payload": payload, "stage": fields["stage"], "qid": fields["qid"],
            "candidate_id": fields["candidate_id"], "prompt_tokens": fields["prompt_tokens"]}
        raw = _json_bytes(envelope)
        return raw, hashlib.sha256(raw).hexdigest()

    def _check_row(self, row, digest):
        if row["request_sha256"] != digest:
            self.audit.record("payload_mismatch", request_id=row["request_id"],
                expected_sha256=digest, recorded_sha256=row["request_sha256"])
            raise PayloadMismatch("Same request identity has a different frozen envelope/payload; refusing reuse or POST")

    def _unknown(self, identity, status, start, row=None):
        self.audit.record("unknown_no_resend", request_id=identity, status=status,
                          waited_seconds=time.monotonic() - start)
        return ReplayHTTPRecord(identity, status, error="Reserved/failed identity remains consumed; no resend",
            reserved_tokens=(row or {}).get("reserved_tokens", 0),
            replay_cache_hit=row is not None, replay_wait_seconds=time.monotonic() - start)

    def _reconstruct(self, row, expected, digest, start):
        self._check_row(row, digest)
        common = dict(request_id=row["request_id"], status=row["status"],
            http_status=row.get("http_status"), request_path=row.get("request_file"),
            raw_response_path=row.get("response_file"), usage=json.loads(row["usage_json"]) if row.get("usage_json") else None,
            elapsed_seconds=row.get("elapsed_seconds") or 0, error=row.get("error"),
            finish_reason=row.get("finish_reason"), request_sha256=row["request_sha256"],
            raw_response_sha256=row.get("response_sha256"), reserved_tokens=row["reserved_tokens"],
            actual_total_tokens=row.get("actual_total_tokens"),
            transport_attempted=row.get("transport_attempted_at") is not None,
            response_received=row.get("response_received_at") is not None,
            response_complete=row.get("response_complete_at") is not None,
            replay_cache_hit=True, replay_wait_seconds=time.monotonic() - start)
        # A genuine terminal failure stays a failure even if a usable-looking
        # response exists. It is never retried or upgraded to OK.
        if row["status"] != "OK":
            self.audit.record("reuse_terminal_failure_no_resend", request_id=row["request_id"], status=row["status"])
            return ReplayHTTPRecord(**common)
        try:
            stem = hashlib.sha256(row["request_id"].encode()).hexdigest()
            request_file = self.delegate.artifact_dir / (stem + ".request.json")
            response_file = self.delegate.artifact_dir / (stem + ".response.bin")
            if (Path(row["request_file"]).resolve() != request_file.resolve()
                    or Path(row["response_file"]).resolve() != response_file.resolve()
                    or row.get("response_complete_at") is None or row.get("finished_at") is None
                    or not isinstance(row.get("http_status"), int) or not 200 <= row["http_status"] < 300):
                raise ValueError("Successful row lacks complete bound request/response artifact evidence")
            saved_request, saved_response = request_file.read_bytes(), response_file.read_bytes()
            if saved_request != expected or hashlib.sha256(saved_request).hexdigest() != digest:
                raise ValueError("Saved request envelope differs from the expected frozen request")
            if not row.get("response_sha256") or hashlib.sha256(saved_response).hexdigest() != row["response_sha256"]:
                raise ValueError("Saved response hash is absent or changed")
            body = json.loads(saved_response.decode("utf-8"))
            if not isinstance(body, dict) or body.get("usage") != common["usage"]:
                raise ValueError("Saved response or recorded usage differs from the terminal row")
            common["response"] = body
        except (OSError, ValueError, TypeError, KeyError) as exc:
            self.audit.record("artifact_invalid_no_resend", request_id=row["request_id"], reason=str(exc))
            return self._unknown(row["request_id"], "REPLAY_ARTIFACT_UNKNOWN", start, row)
        self.audit.record("reuse_complete_response", request_id=row["request_id"], status=row["status"],
                          response_sha256=row["response_sha256"], independent_review_increment=0, new_http_post=False)
        return ReplayHTTPRecord(**common)

    def _observe(self, identity, expected, digest, start):
        deadline = start + self.wait_seconds
        while True:
            try:
                row = one_row(self.delegate.journal_path, identity)
            except sqlite3.OperationalError:
                row = None
                if time.monotonic() >= deadline:
                    return self._unknown(identity, "REPLAY_JOURNAL_OBSERVATION_UNKNOWN", start)
                time.sleep(self.poll_seconds)
                continue
            if row is None:
                return self._unknown(identity, "REPLAY_RESERVED_ID_DISAPPEARED", start)
            self._check_row(row, digest)
            if row.get("finished_at") is not None and row["status"] != "RESERVED":
                return self._reconstruct(row, expected, digest, start)
            if time.monotonic() >= deadline:
                return self._unknown(identity, "REPLAY_ACTIVE_OR_RESERVED_UNKNOWN", start, row)
            time.sleep(min(self.poll_seconds, max(0, deadline - time.monotonic())))

    def post(self, path, payload, *, request_id, stage, qid, candidate_id, prompt_tokens):
        fields = dict(request_id=request_id, stage=stage, qid=qid, candidate_id=candidate_id, prompt_tokens=prompt_tokens)
        expected, digest = self._expected(path, payload, fields)
        if self.barrier is not None and stage == "verifier_score_read":
            self.barrier.before_score(self.worker)
        start = time.monotonic()
        row = one_row(self.delegate.journal_path, request_id)
        if row is not None:
            self._check_row(row, digest)
            return self._observe(request_id, expected, digest, start)
        if not self.allow_new:
            return self._unknown(request_id, "REPLAY_NOT_REGISTERED_NO_NEW_WORK", start)
        with self.slots.acquire(self.gpu):
            # Recheck after waiting for a slot; the old process may have won.
            row = one_row(self.delegate.journal_path, request_id)
            if row is not None:
                self._check_row(row, digest)
                return self._observe(request_id, expected, digest, start)
            try:
                record = self.delegate.post(path, payload, **fields)
            except DuplicateRequestError:
                self.audit.record("atomic_race_lost_reuse", request_id=request_id)
                return self._observe(request_id, expected, digest, start)
        self.audit.record("new_delegate_terminal", request_id=request_id, status=record.status,
            transport_dispatch_marked=record.transport_attempted, response_received=record.response_received)
        return ReplayHTTPRecord(**asdict(record), replay_cache_hit=False,
            new_transport_dispatch_marked=record.transport_attempted,
            independent_review_increment=1 if stage == "verifier_review" and record.transport_attempted else 0)


class OwnBarrier:
    """Only covers the booster workers, never claims control over the old process."""
    def __init__(self, output, count, seconds):
        self.output, self.count = Path(output), count
        self.condition, self.ready = threading.Condition(), set()
        self.deadline, self.failure, self.frozen = time.monotonic() + seconds, None, False

    def _freeze(self):
        if len(self.ready) == self.count and not self.frozen and not self.failure:
            phases = [read_json(self.output / f"worker_{i}" / "score_preflight.json") for i in range(self.count)]
            freeze(self.output / "booster_score_preflight.json", {"scope": "booster_workers_only",
                "global_phase_barrier_claimed": False, "worker_score_preflights": phases})
            self.frozen = True

    def before_score(self, worker):
        with self.condition:
            self.ready.add(worker)
            try:
                self._freeze()
            except Exception as exc:
                self.failure = str(exc)
            self.condition.notify_all()
            while not self.frozen and not self.failure:
                remaining = self.deadline - time.monotonic()
                if remaining <= 0:
                    self.failure = "Booster-only phase barrier timeout"
                    break
                self.condition.wait(min(30, remaining))
            if self.failure:
                raise ScorerPreflightError(self.failure)

    def terminal(self, worker, error=None):
        with self.condition:
            self.ready.add(worker)
            self.failure = self.failure or error
            try:
                self._freeze()
            except Exception as exc:
                self.failure = self.failure or str(exc)
            self.condition.notify_all()


@contextmanager
def single_booster(journal):
    """One live booster per journal, without reserving fake request identities."""
    path = Path(str(Path(journal).resolve()) + ".booster.lock")
    with path.open("a+b") as handle:
        if path.stat().st_size == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def inspect_remaining(rows, original_plan, config):
    review_ids = {entry["request_id"] for entry in original_plan["full_pool_preflight"]["requests"]}
    score_ids = {identity.replace(":review:0", ":score_read:0") for identity in review_ids}
    known = {row["request_id"] for row in rows}
    if len(known) != len(rows) or not known <= review_ids | score_ids:
        raise ScorerPreflightError("Journal contains duplicate or unrelated identities")
    charged = sum(max(row["reserved_tokens"], row.get("actual_total_tokens") or 0) for row in rows)
    return {"registered_identities": len(rows), "terminal": sum(row.get("finished_at") is not None for row in rows),
        "reserved_or_inflight": sum(row.get("finished_at") is None for row in rows),
        "status_counts": dict(Counter(row["status"] for row in rows)),
        "unregistered_review_ids": sorted(review_ids - known),
        "unregistered_score_ids_upper_bound": sorted(score_ids - known),
        "remaining_request_budget": config.max_requests - len(rows),
        "remaining_charged_token_budget": config.max_tokens - charged,
        "score_count_qualification": "Some score IDs are never eligible after failed/truncated reviews; this is an upper bound",
        "risk_notes": [
            "Old coordinator may record local UNKNOWN after losing an atomic identity race; old files remain unchanged.",
            "Old coordinator may score while other reviews are still active; global phase order is not promised.",
            "Registered failures or uncertain reservations never retry; only verified terminal OK artifacts can restore scores.",
            "Six added workers plus the original two bound client concurrency at eight; unrelated clients are outside this assumption."]}


def ordering_audit(rows, review_ids):
    indexed = {row["request_id"]: row for row in rows}
    early = []
    intervals = []
    for row in rows:
        start = row.get("transport_attempted_at")
        if start is None:
            continue
        end = row.get("response_complete_at") or row.get("finished_at")
        intervals.append((start, 1))
        if end is not None:
            intervals.append((end, -1))
        if row["stage"] == "verifier_score_read":
            unfinished = [identity for identity in review_ids
                if identity not in indexed or indexed[identity].get("finished_at") is None or indexed[identity]["finished_at"] > start]
            if unfinished:
                early.append({"score_request_id": row["request_id"], "review_identities_not_terminal_at_dispatch": unfinished})
    active = peak = 0
    for timestamp, delta in sorted(intervals, key=lambda pair: (pair[0], pair[1])):
        active += delta
        peak = max(peak, active)
    return {"global_phase_barrier_claimed": False, "runtime_ordering_change_observed": bool(early),
        "early_score_dispatches": early, "journal_client_interval_peak": peak,
        "interval_definition": "dispatch marker through complete response or terminal client outcome; unresolved dispatch intervals remain open",
        "uncertain_network_outcomes": sum(row.get("transport_attempted_at") is not None
            and row.get("response_received_at") is None for row in rows)}


def completion_state(rows, *, new_dispatches, invalid_scores, required_request_ids=(), reconstruction_errors=()):
    """An observation timeout never turns live shared-journal work into completion."""
    pending = [row["request_id"] for row in rows if row.get("finished_at") is None]
    missing = sorted(set(required_request_ids) - {row["request_id"] for row in rows})
    if pending:
        status = "WAITING_FOR_SHARED_JOURNAL"
    elif reconstruction_errors:
        status = "RECONSTRUCTION_INCOMPLETE"
    elif missing:
        status = "INCOMPLETE_SHARED_WORK"
    elif not new_dispatches:
        status = "NO_NEW_WORK"
    elif invalid_scores:
        status = "COMPLETE_WITH_UNKNOWN"
    else:
        status = "COMPLETE"
    finished = not pending and not missing and not reconstruction_errors
    return {"status": status, "all_registered_requests_terminal": not pending,
        "pending_shared_request_ids": pending,
        "missing_legitimate_request_ids": missing, "reconstruction_errors": list(reconstruction_errors),
        "result_scope": "TERMINAL_SHARED_JOURNAL_RECONSTRUCTION" if finished else "CURRENT_SHARED_JOURNAL_SNAPSHOT",
        "authoritative_snapshot_is_final": finished}


def run_boost(*, candidates, raw_rows, original_requests, manifest, rubrics, config,
              original_run, tokenizers, endpoints, capabilities, journal_path, artifact_dir,
              output_dir, max_seconds, timeout=300, wait_seconds=900, execute=False,
              api_key=None, transports=None):
    config.validate()
    verify_frozen_pool_manifest(candidates, raw_rows, manifest)
    operational = bind_operational_status(candidates, raw_rows, original_requests)
    _, owners, _ = assign_workers(candidates, manifest)
    limits, _ = full_pool_limits(candidates, operational, config, max_seconds)
    old_plan = read_json(Path(original_run) / "parallel_plan.json")
    if (old_plan["config"] != asdict(config) or old_plan["candidate_owner"] != owners
            or old_plan["full_pool_limits"] != {key: asdict(value) for key, value in limits.items()}
            or old_plan["endpoints"] != list(map(_canonical_endpoint, endpoints))):
        raise ScorerPreflightError("Booster changed original config, routing, endpoint or complete-pool budget")
    initial_rows = journal_rows(journal_path)
    remaining = inspect_remaining(initial_rows, old_plan, config)
    expected_reviews = {entry["request_id"]: entry for entry in old_plan["full_pool_preflight"]["requests"]}
    for row in initial_rows:
        stem = hashlib.sha256(row["request_id"].encode()).hexdigest()
        if (Path(row["request_file"]).resolve() != (Path(artifact_dir) / (stem + ".request.json")).resolve()
                or Path(row["response_file"]).resolve() != (Path(artifact_dir) / (stem + ".response.bin")).resolve()
                or row["endpoint"] != _canonical_endpoint(endpoints[owners[row["candidate_id"]]])):
            raise ScorerPreflightError("Booster must use the original endpoint route and the identical shared HTTP artifact directory")
        if row["request_id"] in expected_reviews:
            entry = expected_reviews[row["request_id"]]
            expected_envelope = {"method": "POST", "endpoint": row["endpoint"], "path": "/v1/chat/completions",
                "payload": entry["payload"], "stage": "verifier_review", "qid": entry["row"]["task_id"],
                "candidate_id": entry["row"]["candidate_id"], "prompt_tokens": entry["prompt_tokens"]}
            if hashlib.sha256(_json_bytes(expected_envelope)).hexdigest() != row["request_sha256"]:
                raise PayloadMismatch("Existing review journal identity differs from the original frozen request")
    output = Path(output_dir)
    if output.exists() and any(output.iterdir()):
        raise ScorerPreflightError("Booster output must be new; existing run files remain unchanged")
    output.mkdir(parents=True, exist_ok=True)
    freeze(output / "remaining_work_and_risks.json", remaining)
    if not execute:
        return {"status": "INSPECT_ONLY", "model_requests": 0, "remaining": remaining}
    if len(tokenizers) != 6 or len({id(item) for item in tokenizers}) != 6:
        raise ScorerPreflightError("Exactly six independent tokenizer objects are required")
    shards = [[] for _ in range(6)]
    cursor = [0, 0]
    for row in candidates:
        gpu = owners[row["candidate_id"]]
        worker = gpu * 3 + cursor[gpu] % 3
        cursor[gpu] += 1
        shards[worker].append(row)
    if not all(shards):
        raise ScorerPreflightError("This booster requires nonempty fixed shards for all six workers")
    audit = Audit(output / "cache_and_dispatch_audit.jsonl")
    slots, barrier = ExtraSlots(), OwnBarrier(output, 6, max_seconds)
    transports = transports or (None, None)
    clients = [JournaledClient(endpoints[i // 3], journal_path, artifact_dir, allowed_endpoints=endpoints,
        limits=limits, timeout=timeout, api_key=api_key, transport=transports[i // 3]) for i in range(6)]
    for i in range(6):
        _capability(capabilities[i // 3], config, clients[i])
    # All new preflights must exactly reproduce the old run's request identities,
    # seeds, serialized payloads and precise prompt-token counts.
    expected = {entry["request_id"]: entry for entry in old_plan["full_pool_preflight"]["requests"]}
    observed = set()
    for worker in range(6):
        plan = run_frozen_replay(candidates=shards[worker], rubrics=rubrics, client=None,
            tokenizer=tokenizers[worker], capabilities={}, config=config,
            output_dir=output / f"preflight_{worker}", operational_status=operational, preflight_only=True)["preflight"]
        for entry in plan["requests"]:
            old = expected.get(entry["request_id"])
            if old is None or entry["request_id"] in observed or any(entry[key] != old[key] for key in ("payload", "seed", "prompt_tokens", "serialized_prompt")):
                raise ScorerPreflightError("Booster request differs from the frozen original preflight")
            observed.add(entry["request_id"])
    if observed != set(expected):
        raise ScorerPreflightError("Booster shards do not cover all original review identities")
    freeze(output / "boost_plan.json", {"run_id": config.run_id, "candidate_owner_gpu": owners,
        "worker_candidate_ids": [[row["candidate_id"] for row in shard] for shard in shards],
        "added_workers_per_gpu": 3, "original_worker_bound": 2, "combined_client_concurrency_bound": 8,
        "budgets_unchanged": True, "request_ids_seeds_payloads_unchanged": True,
        "global_phase_barrier_claimed": False, "new_rollout_requests": 0})

    def work(worker, authoritative=False):
        client = ReplayAwareClient(clients[worker], gpu=worker // 3, owners=owners, audit=audit,
            slots=slots, wait_seconds=wait_seconds, allow_new=not authoritative,
            barrier=None if authoritative else barrier, worker=worker)
        error = None
        try:
            return run_frozen_replay(candidates=shards[worker], rubrics=rubrics, client=client,
                tokenizer=tokenizers[worker], capabilities=capabilities[worker // 3], config=config,
                output_dir=output / (f"authoritative_{worker}" if authoritative else f"worker_{worker}"),
                operational_status=operational)
        except Exception as exc:
            error = type(exc).__name__ + ": " + str(exc)
            return {"status": "WORKER_FAILED", "error": error}
        finally:
            if not authoritative:
                barrier.terminal(worker, error)

    with ThreadPoolExecutor(max_workers=6, thread_name_prefix="cause-boost") as executor:
        worker_results = list(executor.map(work, range(6)))
    # A cache-only second pass uses complete authoritative HTTP rows rather than
    # the old process's local UNKNOWNs or a race-losing first-pass placeholder.
    # If observation ends with live identities, this remains a CURRENT snapshot.
    authoritative_results = [work(worker, authoritative=True) for worker in range(6)]
    index, recoveries, reconstruction_errors = {}, [], []
    required_score_ids = set()
    for worker in range(6):
        records, recovery = recover_worker_records(output / f"authoritative_{worker}", shards[worker], authoritative_results[worker])
        recoveries.append(recovery)
        if authoritative_results[worker].get("status") == "WORKER_FAILED":
            reconstruction_errors.append(f"authoritative worker {worker} failed: " + str(authoritative_results[worker].get("error")))
        if recovery["status"] != "CLEAN":
            reconstruction_errors.append(f"authoritative worker {worker} has missing/corrupt terminal-score artifacts")
        try:
            phase = read_json(output / f"authoritative_{worker}" / "score_preflight.json")
            valid_ids = {entry["request_id"] for entry in phase["requests"]}
            if not valid_ids <= {identity.replace(":review:0", ":score_read:0") for identity in expected}:
                raise ValueError("Unexpected score identity in authoritative preflight")
            required_score_ids.update(valid_ids)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            reconstruction_errors.append(f"authoritative worker {worker} score-preflight evidence unavailable: " + type(exc).__name__)
        for record in records:
            key = record["candidate_id"], record["criterion"]
            if key in index:
                raise ScorerPreflightError("Duplicate candidate/criterion during authoritative merge")
            index[key] = record
    merged = [index[row["candidate_id"], criterion] for row in candidates for criterion in CRITERIA]
    with (output / "score_records.jsonl").open("x", encoding="utf-8", newline="\n") as handle:
        for row in merged:
            handle.write(canonical_json(row) + "\n")
    freeze(output / "score_records.json", merged)
    final_rows = journal_rows(journal_path)
    final_remaining = inspect_remaining(final_rows, old_plan, config)
    ordering = ordering_audit(final_rows, set(expected))
    if slots.peak > 6 or max(slots.gpu_peak) > 3 or final_remaining["remaining_request_budget"] < 0 or final_remaining["remaining_charged_token_budget"] < 0:
        raise ScorerPreflightError("Added-concurrency or unchanged shared-budget invariant failed")
    new_events = [event for event in audit.events if event["action"] == "new_delegate_terminal" and event["transport_dispatch_marked"]]
    invalid_scores = sum(row["status"] != "VALID" for row in merged)
    state = completion_state(final_rows, new_dispatches=len(new_events), invalid_scores=invalid_scores,
        required_request_ids=set(expected) | required_score_ids, reconstruction_errors=reconstruction_errors)
    summary = {**state,
        "run_id": config.run_id, "candidate_count": len(candidates), "criterion_records": len(merged),
        "valid_score_records": sum(row["status"] == "VALID" for row in merged),
        "invalid_score_records": invalid_scores,
        "added_transport_dispatches_marked": len(new_events),
        "required_review_identity_count": len(expected), "actual_eligible_score_identity_count": len(required_score_ids),
        "cache_events_are_not_new_http_or_independent_K": True,
        "additional_client_call_peak": slots.peak, "additional_peak_per_gpu": slots.gpu_peak,
        "original_worker_bound": 2, "combined_client_concurrency_bound": 8,
        "ordering_audit": ordering, "remaining": final_remaining,
        "client_accounting": clients[0].summary(), "worker_results": worker_results,
        "authoritative_results": authoritative_results, "recovery_audits": recoveries,
        "original_process_and_outputs_modified": False, "new_rollout_requests": 0, "acceptance_enabled": False}
    freeze(output / "boost_summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("candidates", "raw-rollouts", "original-requests", "manifest", "config", "original-run",
                 "tokenizer-path", "endpoint-0", "endpoint-1", "capabilities-0", "capabilities-1",
                 "journal", "http-artifacts", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--rubrics", default=str(PACKAGE / "rubrics.json"))
    parser.add_argument("--max-seconds", type=float, required=True)
    parser.add_argument("--timeout", type=float, default=300)
    parser.add_argument("--wait-seconds", type=float, default=900)
    parser.add_argument("--api-key-env")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    config = ScorerConfig(**read_json(args.config))
    candidates, manifest = read_jsonl(args.candidates), read_json(args.manifest)
    if len(candidates) != 42 or len(manifest["qid_order"]) != 10 or config.max_requests != 246 or config.max_tokens != 4030464 or not config.run_id.endswith("001"):
        parser.error("Keep the original 42/10/run001 plan and global 246 requests / 4030464 tokens")
    caps = [read_json(args.capabilities_0), read_json(args.capabilities_1)]
    pairs = [load_tokenizer_and_snapshot(args.tokenizer_path, config) for _ in range(6)] if args.execute else []
    for worker, (_, snapshot) in enumerate(pairs):
        if caps[worker // 3].get("model_local_snapshot_fingerprint") != snapshot["model_local_snapshot_fingerprint"]:
            parser.error("Endpoint capability snapshot differs from the current local model")
    key = os.environ.get(args.api_key_env) if args.api_key_env else None
    if args.api_key_env and not key:
        parser.error("Explicit local service auth environment variable is absent")
    kwargs = dict(candidates=candidates, raw_rows=read_jsonl(args.raw_rollouts),
        original_requests=read_jsonl(args.original_requests), manifest=manifest, rubrics=read_json(args.rubrics),
        config=config, original_run=args.original_run, tokenizers=[pair[0] for pair in pairs],
        endpoints=[args.endpoint_0, args.endpoint_1], capabilities=caps, journal_path=args.journal,
        artifact_dir=args.http_artifacts, output_dir=args.output, max_seconds=args.max_seconds,
        timeout=args.timeout, wait_seconds=args.wait_seconds, execute=args.execute, api_key=key)
    if args.execute:
        with single_booster(args.journal):
            result = run_boost(**kwargs)
    else:
        result = run_boost(**kwargs)
    print(canonical_json({key: value for key, value in result.items()
        if key not in {"worker_results", "authoritative_results", "recovery_audits", "client_accounting"}}))


if __name__ == "__main__":
    main()
