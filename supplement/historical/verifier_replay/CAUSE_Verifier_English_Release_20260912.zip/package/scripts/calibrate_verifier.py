#!/usr/bin/env python3
"""Offline calibration with independent labels and disjoint development/eval questions.

No HTTP or model imports; acceptance is never enabled. All threshold/risk targets
are explicit. Six one-sided exact binomial bounds use Bonferroni alpha/6 for the
three FPR upper and three TPR lower bounds at the requested familywise confidence.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
from typing import Mapping

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.core import CRITERIA, canonical_json, content_hash
from cause_verifier.replay import derive_paired_scores

SOURCES = {"independent_executable_check", "independent_expert_audit"}
SCOPE = "causal_criterion_trajectory"


class NotRun(ValueError):
    pass


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def validate_targets(thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative):
    if not thresholds or len(thresholds) != len(set(thresholds)):
        raise NotRun("Provide an explicit unique threshold grid")
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 0 <= v <= 1 for v in thresholds):
        raise NotRun("Thresholds must be finite grades in [0,1]")
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in (max_fpr, min_tpr, confidence)):
        raise NotRun("Risk/sensitivity/confidence targets must be explicit finite numbers")
    if not 0 < max_fpr < 1 or not 0 <= min_tpr < 1 or not 0 < confidence < 1:
        raise NotRun("Require 0<max_fpr<1, 0<=min_tpr<1 and 0<confidence<1")
    if any(isinstance(v, bool) or not isinstance(v, int) or v < 1 for v in (min_positive, min_negative)):
        raise NotRun("Explicit positive heldout label minima are required")


def binomial_cdf(k, n, p):
    if p <= 0:
        return 1.0
    if p >= 1:
        return 1.0 if k >= n else 0.0
    logs = [math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
            + i * math.log(p) + (n - i) * math.log1p(-p) for i in range(k + 1)]
    peak = max(logs)
    return min(1.0, math.exp(peak) * math.fsum(math.exp(v - peak) for v in logs))


def binomial_upper(k, n, alpha):
    """One-sided exact Clopper-Pearson upper bound, using only the standard library."""
    if n < 0 or not 0 <= k <= n or not 0 < alpha < 1:
        raise ValueError("Invalid binomial-bound inputs")
    if n == 0:
        return None
    if k == n:
        return 1.0
    if k == 0:
        return -math.expm1(math.log(alpha) / n)
    low, high = k / n, 1.0
    for _ in range(80):
        midpoint = (low + high) / 2
        if binomial_cdf(k, n, midpoint) > alpha:
            low = midpoint
        else:
            high = midpoint
    return high


def binomial_lower(k, n, alpha):
    if n == 0:
        return None
    return max(0.0, 1 - binomial_upper(n - k, n, alpha))


def validate_label(label, candidate, criterion, evidence_root):
    if not isinstance(label, Mapping) or label.get("label") not in {"pass", "fail", "unknown"}:
        raise NotRun("Each criterion requires an explicit pass/fail/unknown label")
    if label["label"] == "unknown" and label.get("source_kind") == "unavailable":
        if label.get("evidence_refs") != []:
            raise NotRun("Unavailable unknown labels cannot claim evidence")
        return "unknown", []
    if (label.get("source_kind") not in SOURCES or label.get("scope") != SCOPE
            or label.get("model_generated") is not False or label.get("verifier_scores_used") is not False
            or not isinstance(label.get("source_id"), str) or not label["source_id"].strip()
            or not isinstance(label.get("evidence_refs"), list) or not label["evidence_refs"]):
        raise NotRun("Missing independent criterion provenance; answer-only or model-derived labels are not truth")
    verified = []
    for ref in label["evidence_refs"]:
        if not isinstance(ref, Mapping) or set(ref) != {"path", "sha256"}:
            raise NotRun("Evidence references require relative path and SHA256")
        if not isinstance(ref["path"], str) or not ref["path"] or Path(ref["path"]).is_absolute():
            raise NotRun("Evidence paths must be relative to the explicit evidence-root")
        path = (evidence_root / ref["path"]).resolve(strict=True)
        if not path.is_relative_to(evidence_root) or not path.is_file() or path.stat().st_size > 2_000_000:
            raise NotRun("Evidence escapes its root, is not a file, or exceeds 2 MB")
        if sha(path) != ref["sha256"]:
            raise NotRun("Independent evidence SHA256 mismatch")
        record = read_json(path)
        expected = {"candidate_id": candidate["candidate_id"], "task_id": candidate["task_id"],
                    "candidate_hash": content_hash(candidate["rollout"]), "criterion": criterion,
                    "label": label["label"], "source_kind": label["source_kind"], "source_id": label["source_id"],
                    "scope": SCOPE, "model_generated": False, "verifier_scores_used": False}
        if any(record.get(key) != value for key, value in expected.items()):
            raise NotRun("Evidence is not bound to this task, candidate full text, criterion and independent verdict")
        if "result" not in record or record.get("result_hash") != content_hash(record["result"]):
            raise NotRun("Independent evidence result payload/hash is absent or inconsistent")
        verified.append(dict(ref))
    return label["label"], verified


def load_dataset(candidates, scores, labels, split, evidence_root):
    indexed = {}
    for row in candidates:
        if set(row) != {"candidate_id", "task_id", "task", "rollout"}:
            raise NotRun("Candidates must use the frozen blind schema")
        if row["candidate_id"] in indexed:
            raise NotRun("Duplicate candidate identity")
        if row["task_id"] != "task_" + content_hash(row["task"])[:20]:
            raise NotRun("Original question content changed after task identity was frozen")
        indexed[row["candidate_id"]] = row
    if not indexed:
        raise NotRun("No actual candidate records")
    if not isinstance(split, Mapping) or set(split) != {"dev_task_ids", "eval_task_ids"}:
        raise NotRun("Explicit dev_task_ids and eval_task_ids are required")
    if any(not isinstance(split[key], list) or not split[key] or len(split[key]) != len(set(split[key])) for key in split):
        raise NotRun("Question splits must be nonempty lists without duplicates")
    dev_tasks, eval_tasks = set(split["dev_task_ids"]), set(split["eval_task_ids"])
    if dev_tasks & eval_tasks:
        raise NotRun("A question occurs in both development and evaluation")
    if dev_tasks | eval_tasks != {row["task_id"] for row in candidates}:
        raise NotRun("Question splits must cover exactly the complete frozen candidate pool")
    dev_count = sum(row["task_id"] in dev_tasks for row in candidates)
    if not 50 <= dev_count <= 100:
        raise NotRun(f"Development requires 50-100 actual candidates; found {dev_count}")
    label_index = {row["candidate_id"]: row for row in labels}
    if len(label_index) != len(labels) or set(label_index) != set(indexed):
        raise NotRun("One independent label sidecar row is required per candidate")
    score_index = {}
    for score in scores:
        cid, criterion = score.get("candidate_id"), score.get("criterion")
        if cid not in indexed or criterion not in CRITERIA:
            raise NotRun("Unexpected candidate/criterion in saved scores")
        if (cid, criterion) in score_index:
            raise NotRun("Multiple saved scores cannot be cherry-picked or counted as fresh labels")
        if score.get("status") == "VALID":
            if score.get("candidate_hash") != content_hash(indexed[cid]["rollout"]):
                raise NotRun("Saved score refers to another candidate full text")
            try:
                derived = derive_paired_scores(score)
            except (ValueError, TypeError, KeyError) as exc:
                raise NotRun("Saved exact distribution is invalid: " + str(exc)) from exc
            if derived.get("status") != "valid":
                raise NotRun("Saved score is not a valid exact distribution")
            score_index[cid, criterion] = derived["expectation"]
        else:
            score_index[cid, criterion] = None
    dataset = {part: {criterion: [] for criterion in CRITERIA} for part in ("dev", "eval")}
    evidence_refs = []
    for cid, candidate in indexed.items():
        sidecar = label_index[cid]
        if (sidecar.get("task_id") != candidate["task_id"]
                or sidecar.get("candidate_hash") != content_hash(candidate["rollout"])
                or not isinstance(sidecar.get("criteria"), Mapping) or set(sidecar["criteria"]) != set(CRITERIA)):
            raise NotRun("Independent sidecar must bind original task, full candidate and all three criteria")
        part = "dev" if candidate["task_id"] in dev_tasks else "eval"
        for criterion in CRITERIA:
            label, refs = validate_label(sidecar["criteria"][criterion], candidate, criterion, evidence_root)
            evidence_refs.extend(refs)
            dataset[part][criterion].append({"candidate_id": cid, "task_id": candidate["task_id"],
                "label": label, "score": score_index.get((cid, criterion))})
    eval_count = len(candidates) - dev_count
    return dataset, {"dev_candidates": dev_count, "eval_candidates": eval_count,
        "dev_questions": len(dev_tasks), "eval_questions": len(eval_tasks), "question_disjoint": True,
        "heldout_single_candidate_per_question": eval_count == len(eval_tasks),
        "verified_evidence_file_references": len(evidence_refs), "evidence_refs_hash": content_hash(evidence_refs)}


def confusion(rows, threshold):
    counts = dict(TP=0, FP=0, TN=0, FN=0, unknown_labels=0, unknown_scores=0,
                  positive_score_abstentions=0, negative_score_abstentions=0,
                  positive_labels=0, negative_labels=0, total_candidates=len(rows))
    for row in rows:
        if row["score"] is None:
            counts["unknown_scores"] += 1
        if row["label"] == "unknown":
            counts["unknown_labels"] += 1
            continue
        positive = row["label"] == "pass"
        counts["positive_labels" if positive else "negative_labels"] += 1
        if row["score"] is None:
            counts["positive_score_abstentions" if positive else "negative_score_abstentions"] += 1
            continue
        accepts = row["score"] >= threshold
        counts[("TP" if accepts else "FN") if positive else ("FP" if accepts else "TN")] += 1
    positive, negative = counts["TP"] + counts["FN"], counts["FP"] + counts["TN"]
    ratio = lambda a, b: a / b if b else None
    counts.update(resolved_positive_labels=positive, resolved_negative_labels=negative,
        TPR=ratio(counts["TP"], positive), FPR=ratio(counts["FP"], negative), FNR=ratio(counts["FN"], positive),
        operational_acceptance_TPR=ratio(counts["TP"], counts["positive_labels"]),
        operational_acceptance_FPR=ratio(counts["FP"], counts["negative_labels"]),
        metric_denominator="TPR/FPR/FNR use independent known labels with valid scores; unknown truth and abstentions are separate")
    return counts


def evaluate(dataset, *, thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative):
    validate_targets(thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative)
    alpha = (1 - confidence) / (2 * len(CRITERIA))
    per_criterion, selected, blockers = {}, {}, []
    # Freeze every threshold using development rows before inspecting ANY eval row.
    for criterion in CRITERIA:
        table = [{"threshold": t, "metrics": confusion(dataset["dev"][criterion], t)} for t in sorted(thresholds)]
        feasible = [row for row in table if row["metrics"]["TPR"] is not None and row["metrics"]["FPR"] is not None
                    and row["metrics"]["TPR"] >= min_tpr and row["metrics"]["FPR"] <= max_fpr]
        if not feasible:
            blockers.append(criterion + ": no development threshold meets explicit empirical FPR/TPR goals")
            per_criterion[criterion] = {"development_grid": table, "selected_threshold": None, "heldout": None}
            continue
        best = min(feasible, key=lambda row: (-row["metrics"]["TPR"], row["metrics"]["FPR"], row["threshold"]))
        selected[criterion] = best["threshold"]
        per_criterion[criterion] = {"development_grid": table, "selected_threshold": best["threshold"],
                                    "development_selected_metrics": best["metrics"]}
    for criterion, threshold in selected.items():
        heldout = confusion(dataset["eval"][criterion], threshold)
        positive, negative = heldout["resolved_positive_labels"], heldout["resolved_negative_labels"]
        upper = binomial_upper(heldout["FP"], negative, alpha)
        lower = binomial_lower(heldout["TP"], positive, alpha)
        enough = positive >= min_positive and negative >= min_negative
        passes = enough and upper is not None and lower is not None and upper <= max_fpr and lower >= min_tpr
        heldout.update(FPR_one_sided_exact_upper=upper, TPR_one_sided_exact_lower=lower,
            individual_bound_alpha=alpha, label_sample_minima_met=enough,
            independent_heldout_risk_and_sensitivity_goals_met=passes)
        per_criterion[criterion]["heldout"] = heldout
        if not enough:
            blockers.append(criterion + ": insufficient independently labeled positive/negative heldout candidates with valid scores")
        elif not passes:
            blockers.append(criterion + ": heldout exact bounds do not meet explicit FPR/TPR goals")
    evidence_sufficient = all(
        confusion(dataset["dev"][criterion], thresholds[0])["resolved_positive_labels"] >= 1
        and confusion(dataset["dev"][criterion], thresholds[0])["resolved_negative_labels"] >= 1
        and confusion(dataset["eval"][criterion], thresholds[0])["resolved_positive_labels"] >= min_positive
        and confusion(dataset["eval"][criterion], thresholds[0])["resolved_negative_labels"] >= min_negative
        for criterion in CRITERIA)
    return {"per_criterion": per_criterion, "selected_thresholds": selected, "blocking_reasons": blockers,
        "independent_label_counts_sufficient": evidence_sufficient,
        "gate_candidate_eligible": not blockers and set(selected) == set(CRITERIA),
        "selection_rule": "Development only: maximize TPR, minimize FPR, then lower threshold on ties",
        "unknown_policy": "Unknown truth is never forced pass/fail. Invalid or absent scores abstain; never replace with 0.5.",
        "heldout_protocol": "One evaluation after development thresholds freeze; no refitting on heldout",
        "bounds": "One-sided exact Clopper-Pearson; Bonferroni alpha/6 for three FPR upper and three TPR lower bounds; requires independent heldout question sampling",
        "targets": {"threshold_grid": sorted(thresholds), "max_fpr": max_fpr, "min_tpr": min_tpr,
            "familywise_confidence": confidence, "min_heldout_positive": min_positive,
            "min_heldout_negative": min_negative, "individual_bound_alpha": alpha}}


def make_plan(manifest, *, thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative):
    validate_targets(thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative)
    alpha = (1 - confidence) / 6
    needed_negative = math.ceil(math.log(alpha) / math.log1p(-max_fpr))
    needed_positive = math.ceil(math.log(alpha) / math.log(min_tpr)) if min_tpr > 0 else 0
    return {"status": "NOT_RUN", "reason": "Development plan only; no calibration or accuracy established",
        "existing_pool_candidates": manifest.get("frozen_raw_rollout_count"),
        "development_candidates_required": {"minimum": 50, "maximum": 100},
        "split_schema": {"dev_task_ids": ["task_id_from_original_question"], "eval_task_ids": ["different_task_id"]},
        "existing_answer_only_labels_usable_as_criterion_truth": False,
        "heldout_best_case_requirements_per_criterion": {
            "negative_labels_with_zero_false_accepts": max(min_negative, needed_negative),
            "positive_labels_with_zero_false_rejects": max(min_positive, needed_positive),
            "qualification": "Counts grow when errors occur; valid scores and at most one heldout candidate per independent question required"},
        "explicit_targets": {"threshold_grid": sorted(thresholds), "max_fpr": max_fpr, "min_tpr": min_tpr,
                             "familywise_confidence": confidence},
        "labels_required": "All three independent criterion labels, source and hashed local evidence per candidate",
        "acceptance_enabled": False, "model_requests": 0}


def run_calibration(*, candidate_path, score_path, label_path, split_path, evidence_root,
                    calibration_id, thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative):
    output = {"status": "NOT_RUN", "acceptance_enabled": False, "model_requests": 0,
              "calibration_gate_candidate": None, "calibration_id": calibration_id}
    try:
        validate_targets(thresholds, max_fpr, min_tpr, confidence, min_positive, min_negative)
        if not isinstance(calibration_id, str) or not calibration_id.strip():
            raise NotRun("Explicit calibration_id is required")
        paths = {"candidates": Path(candidate_path), "scores": Path(score_path),
                 "labels": Path(label_path), "question_split": Path(split_path)}
        missing = [role for role, path in paths.items() if not path.is_file()]
        if missing:
            raise NotRun("Missing actual input files: " + ", ".join(missing))
        root = Path(evidence_root).resolve(strict=True)
        if not root.is_dir():
            raise NotRun("Evidence root is not an existing directory")
        dataset, counts = load_dataset(read_jsonl(paths["candidates"]), read_jsonl(paths["scores"]),
                                      read_jsonl(paths["labels"]), read_json(paths["question_split"]), root)
        evaluation = evaluate(dataset, thresholds=thresholds, max_fpr=max_fpr, min_tpr=min_tpr,
                              confidence=confidence, min_positive=min_positive, min_negative=min_negative)
        if not counts["heldout_single_candidate_per_question"]:
            evaluation["blocking_reasons"].append("Heldout has multiple candidates from the same question; correlated candidates are not independent binomial trials")
            evaluation["gate_candidate_eligible"] = False
            for criterion in CRITERIA:
                heldout = evaluation["per_criterion"][criterion].get("heldout")
                if heldout is not None:
                    heldout["independence_assumption_satisfied"] = False
                    heldout["FPR_one_sided_exact_upper"] = None
                    heldout["TPR_one_sided_exact_lower"] = None
                    heldout["independent_heldout_risk_and_sensitivity_goals_met"] = False
        final_status = ("NOT_RUN" if not evaluation["independent_label_counts_sufficient"]
                        else "CALIBRATION_GATE_CANDIDATE" if evaluation["gate_candidate_eligible"]
                        else "CALIBRATION_REJECTED")
        output.update(status=final_status,
            counts=counts, evaluation=evaluation,
            source_files={role: {"path": str(path.resolve()), "sha256": sha(path)} for role, path in paths.items()},
            evidence_scope="Declared independent provenance and candidate/criterion/verdict binding verified against hashed local files; files are never executed")
        if final_status == "NOT_RUN":
            output["reason"] = "Independent positive/negative development or heldout label counts are insufficient; descriptive diagnostics only"
        if evaluation["gate_candidate_eligible"]:
            payload = {"evaluation": evaluation, "counts": counts, "source_files": output["source_files"]}
            output["calibration_gate_candidate"] = {
                "thresholds": evaluation["selected_thresholds"], "calibration_id": calibration_id,
                "independent_labels": True, "question_disjoint": True, "artifact_hash": content_hash(payload),
                "artifact_hash_scope": "canonical evaluation/counts/source_files payload",
                "evidence_refs": [output["source_files"]["labels"], output["source_files"]["question_split"]],
                "activation_requires": "Separate explicit acceptance mode and audit that model/tokenizer/template/rubric/protocol match saved scores",
                "acceptance_enabled": False}
    except (NotRun, FileNotFoundError, KeyError, TypeError, json.JSONDecodeError) as exc:
        output["reason"] = str(exc)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("plan", "calibrate"))
    parser.add_argument("--thresholds", required=True)
    parser.add_argument("--max-fpr", required=True, type=float)
    parser.add_argument("--min-tpr", required=True, type=float)
    parser.add_argument("--confidence", required=True, type=float)
    parser.add_argument("--min-heldout-positive", required=True, type=int)
    parser.add_argument("--min-heldout-negative", required=True, type=int)
    parser.add_argument("--output", required=True)
    parser.add_argument("--pool-manifest")
    for field in ("candidates", "scores", "labels", "split", "evidence-root", "calibration-id"):
        parser.add_argument("--" + field)
    args = parser.parse_args()
    try:
        thresholds = [float(value) for value in args.thresholds.split(",")]
    except ValueError:
        parser.error("Thresholds must be explicit numeric grades")
    parameters = dict(thresholds=thresholds, max_fpr=args.max_fpr, min_tpr=args.min_tpr,
                      confidence=args.confidence, min_positive=args.min_heldout_positive,
                      min_negative=args.min_heldout_negative)
    if args.mode == "plan":
        if not args.pool_manifest:
            parser.error("plan requires --pool-manifest")
        try:
            result = make_plan(read_json(args.pool_manifest), **parameters)
        except (NotRun, FileNotFoundError, json.JSONDecodeError) as exc:
            result = {"status": "NOT_RUN", "reason": str(exc), "acceptance_enabled": False, "model_requests": 0}
    else:
        if not all((args.candidates, args.scores, args.labels, args.split, args.evidence_root, args.calibration_id)):
            parser.error("calibrate requires candidates/scores/labels/split/evidence-root/calibration-id")
        result = run_calibration(candidate_path=args.candidates, score_path=args.scores,
            label_path=args.labels, split_path=args.split, evidence_root=args.evidence_root,
            calibration_id=args.calibration_id, **parameters)
    write_new(args.output, result)
    print(canonical_json({key: result.get(key) for key in ("status", "reason", "acceptance_enabled", "model_requests")}))
    return 0 if result["status"] == "CALIBRATION_GATE_CANDIDATE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
