"""Operate only the two TP=1 replicas explicitly authorized for this task."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from urllib.request import urlopen

ROOT = Path('/root/autodl-tmp/CAUSE-verifier-20260909')
STATE = ROOT / 'dual_services_manifest.json'
spec = importlib.util.spec_from_file_location('base_control', ROOT / 'package/scripts/service_control.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def save(value):
    temporary = STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2))
    os.replace(temporary, STATE)


def health(port):
    try:
        with urlopen(f'http://127.0.0.1:{port}/health', timeout=2) as response:
            return response.status
    except Exception:
        return None


def main(action):
    require(json.loads((ROOT / 'task_identity.json').read_text())['instance'] in socket.gethostname(), 'Unexpected instance')
    if action == 'status':
        state = json.loads(STATE.read_text()) if STATE.exists() else {'services': []}
        print(json.dumps({'state': state, 'live': [
            {'gpu': item['gpu'], 'pid': item['pid'], 'identity': base.identity(item['pid']),
             'health': health(item['port'])} for item in state['services']]}))
        return
    if action == 'restore':
        state = json.loads(STATE.read_text())
        for item in state['services']:
            actual = base.identity(item['pid'])
            if actual and actual['state'] != 'Z':
                require(actual['argv'] == item['argv'] and actual['starttime'] == item['starttime'], 'Changed process identity')
                require(os.getpgid(item['pid']) == item['pid'], 'Unexpected process group')
                os.killpg(item['pid'], signal.SIGTERM)
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            alive = [item for item in state['services'] if (base.identity(item['pid']) or {}).get('state') not in (None, 'Z')]
            if not alive:
                break
            time.sleep(.5)
        else:
            raise RuntimeError('Graceful stop incomplete; no forced kill used')
        require(not base.active_services() and all(health(port) is None for port in (8000, 8001)), 'Stopped state not restored')
        state['status'] = 'RESTORED_INITIAL_STOPPED_STATE'
        state['restored_at'] = time.time()
        save(state)
        (ROOT / 'dual_rollback_verification.json').write_text(json.dumps(state, indent=2))
        print(state['status'])
        return
    require(action == 'start', 'Invalid action')
    require(not STATE.exists(), 'Existing launch requires inspection, never automatic restart')
    require(not base.active_services() and all(health(port) is None for port in (8000, 8001)), 'Service already active')
    gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=index,memory.total,memory.free', '--format=csv,noheader,nounits'], text=True)
    rows = {int(v[0]): [float(x) for x in v[1:]] for line in gpu.splitlines() if (v := line.split(','))}
    require(all(index in rows and rows[index][1] >= .85 * rows[index][0] for index in (0, 1)), 'Insufficient GPU headroom')
    manifest = json.loads((ROOT / 'original_service_manifest.json').read_text())
    spec = importlib.util.spec_from_file_location('audited_launch', manifest['launch_environment_source'])
    launch = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launch)
    require(launch.EXPECTED_ARGV == manifest['original_argv'], 'Audited launch arguments changed')
    records = Path('/root/autodl-tmp/qwen36_pns_adaptive_20260826/services_dual_tp1_v2_resume_20260826')
    state = {'status': 'LAUNCHING', 'initially_running': False, 'services': [], 'total_verifier_concurrency': 2}
    save(state)
    for index, port in ((0, 8000), (1, 8001)):
        original = json.loads((records / f'gpu{index}_port{port}/launch_record.json').read_text())
        argv = list(manifest['original_argv'])
        argv[argv.index('--port') + 1] = str(port)
        require(argv == original['argv'], 'Mismatch with actual historical per-GPU configuration')
        directory = ROOT / f'dual-service-gpu{index}'
        directory.mkdir(exist_ok=False)
        launch.SERVICE_DIR = directory
        env = launch.build_launch_env()
        env['CUDA_VISIBLE_DEVICES'] = str(index)
        with (directory / 'vllm.log').open('xb') as log:
            process = subprocess.Popen(argv, env=env, cwd=directory, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        actual = base.identity(process.pid)
        state['services'].append({'gpu': index, 'port': port, 'pid': process.pid,
                                 'starttime': actual['starttime'], 'argv': argv,
                                 'log_path': str(directory / 'vllm.log'), 'started_at': time.time(),
                                 'source_record': str(records / f'gpu{index}_port{port}/launch_record.json')})
        save(state)
    state['status'] = 'LAUNCHED_NOT_YET_HEALTH_VERIFIED'
    save(state)
    print(json.dumps(state))


if __name__ == '__main__':
    main(sys.argv[1])
