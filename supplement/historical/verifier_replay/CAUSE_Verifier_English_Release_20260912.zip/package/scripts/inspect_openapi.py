#!/usr/bin/env python3
"""Inspect structured_outputs.choice in an already saved OpenAPI schema; no HTTP."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.replay import file_sha256, write_frozen
from cause_verifier.recovery_evidence import inspect_openapi_choice


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--openapi", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = inspect_openapi_choice(json.loads(args.openapi.read_text(encoding="utf-8")))
    result.update(source_file=str(args.openapi.resolve()), source_sha256=file_sha256(args.openapi))
    write_frozen(args.output, result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
