#!/usr/bin/env python3
"""Pinned official compare through a local, journaled transport; toy diagnostics only."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.client import BudgetLimit, JournaledClient

OFFICIAL_COMMIT = "8db8a114355a9d7fdf9a8d1d5c87f6aeebd18770"
SOURCE_HASHES = {
    "__init__.py": "c9a57136629a77b78e315fe2eb0be55e624ebc495e653e7e1ccae5289500a17f",
    "fine_grained_reward.py": "3f5adc9d47ce995ce1cf7a2273bcf8ec382bbde1a6497e4e88f5bc819974450e",
    "pivot_tournament.py": "61352172aae1c086a4dff369474f3b8e2569278e92a53e80fbf03a0a3d9f3517",
    "prompts.py": "ef3f59f5c84546726b6cb427340a673bc6b1deaa77f9ae627b2a55e1eca986bf",
}
TOY_TASK = ("A fully specified finite causal model has U distributed Bernoulli(0.5), "
    "X=U, and Y=max(X,U). Determine P(Y=1 | do(X=0)), and explain whether "
    "conditioning on X=0 is equivalent in this model.")
TOY_A = ("Under do(X=0), replace X=U with X=0. U retains Bernoulli(0.5), hence "
    "Y=max(0,U)=U and the requested probability is 0.5. Observing X=0 instead "
    "restricts U=0, yielding Y=0. The two operations therefore differ.")
TOY_B = ("Because X=U, setting X=0 tells us U=0. Thus Y=max(0,0)=0 and "
    "P(Y=1 | do(X=0))=0. Conditioning and intervention are interchangeable here.")


def digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_sources(package_dir, manifest):
    declared = manifest.get("official_verifier_commit")
    if declared is None and isinstance(manifest.get("official_verifier"), dict):
        declared = manifest["official_verifier"].get("commit")
    if declared != OFFICIAL_COMMIT:
        raise ValueError("Runtime manifest does not declare the frozen official commit")
    package_dir = Path(package_dir).resolve()
    observed = {}
    for relative, expected in SOURCE_HASHES.items():
        actual = digest_file(package_dir / relative)
        observed[relative] = actual
        if actual != expected:
            raise ValueError("Installed official source mismatch: " + relative)
    checkout, git_head = package_dir.parent, None
    if (checkout / ".git").exists():
        process = subprocess.run(["git", "-C", str(checkout), "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=30, check=True)
        git_head = process.stdout.strip()
        if git_head != OFFICIAL_COMMIT:
            raise ValueError("Installed checkout HEAD differs from pinned commit")
    return {"status": "PASS", "commit": OFFICIAL_COMMIT, "manifest_commit": declared,
        "git_head": git_head, "package_path": str(package_dir), "source_sha256": observed,
        "source": "https://github.com/llm-as-a-verifier/llm-as-a-verifier/tree/" + OFFICIAL_COMMIT,
        "scope": "Exact compare, request/scoring, tournament and criteria-module hashes"}


TOKENIZER_HELPER = r'''
import hashlib,json,os,sys
os.environ['USE_TORCH']='0'
os.environ['USE_TF']='0'
os.environ['TRANSFORMERS_OFFLINE']='1'
os.environ['HF_HUB_OFFLINE']='1'
from transformers import AutoTokenizer
request=json.load(sys.stdin)
tok=AutoTokenizer.from_pretrained(request['model_path'],local_files_only=True,trust_remote_code=False)
p=request['payload']
kwargs=dict(p.get('chat_template_kwargs') or {})
continued=p.get('continue_final_message',False)
text=tok.apply_chat_template(p['messages'],tokenize=False,
    add_generation_prompt=p.get('add_generation_prompt',not continued),
    continue_final_message=continued,**kwargs)
ids=tok.encode(text,add_special_tokens=False)
print(json.dumps({'prompt_token_ids':ids,'prompt_tokens':len(ids),
    'serialized_prompt':text,'prompt_sha256':hashlib.sha256(text.encode()).hexdigest()},ensure_ascii=False))
'''


class LocalTemplateCounter:
    def __init__(self, python, model_path, max_model_len):
        # Preserve the venv launcher path. Resolving its POSIX symlink to a base
        # interpreter changes sys.prefix and silently drops the venv packages.
        self.python = os.path.abspath(os.path.expanduser(os.fspath(python)))
        self.model_path = str(Path(model_path).resolve())
        self.max_model_len = max_model_len
        self.diagnostics = []

    def __call__(self, payload):
        environment = dict(os.environ, USE_TORCH="0", USE_TF="0",
                           TRANSFORMERS_OFFLINE="1", HF_HUB_OFFLINE="1")
        result = subprocess.run([self.python, "-c", TOKENIZER_HELPER],
            input=json.dumps({"model_path": self.model_path, "payload": payload}, ensure_ascii=False),
            capture_output=True, text=True, encoding="utf-8", env=environment, timeout=90)
        self.diagnostics.append({"python_executable_argument": self.python,
            "model_path": self.model_path, "returncode": result.returncode,
            "stderr": redact_diagnostic(result.stderr),
            "stdout_on_failure": redact_diagnostic(result.stdout) if result.returncode else None})
        if result.returncode:
            raise ValueError("Offline local template helper failed; no model request sent")
        measured = json.loads(result.stdout)
        count = measured["prompt_tokens"]
        if not isinstance(count, int) or count < 1 or count + payload["max_tokens"] > self.max_model_len:
            raise ValueError("Official request exceeds verified context/output allowance")
        return measured


class OfficialProxy:
    """Duck-typed OpenAI client; the OpenAI SDK is used only for response objects."""
    def __init__(self, client, model, run_id, tokenizer, *, response_factory=None):
        self.client, self.model, self.run_id, self.tokenizer = client, model, run_id, tokenizer
        self.records, self.payload_audits, self.blocked_invocations = [], [], []
        self.failed, self.response_factory = False, response_factory
        self.first_error = None
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

    def create(self, **kwargs):
        if self.failed or len(self.records) >= 3:
            self.blocked_invocations.append({"reason": "Failure latch or three-POST cap; no HTTP"})
            raise RuntimeError("Official smoke transport stopped; no retry permitted")
        payload = dict(kwargs)
        extras = payload.pop("extra_body", {}) or {}
        if not isinstance(extras, dict) or any(key in payload for key in extras):
            self.failed = True
            raise ValueError("Ambiguous upstream extra_body")
        payload.update(extras)
        if payload.get("model") != self.model:
            self.failed = True
            raise ValueError("Upstream attempted a different model")
        is_prefill = payload.get("continue_final_message") is True
        requested_max = payload.get("max_tokens")
        if is_prefill:
            if requested_max != 1:
                self.failed = True
                raise ValueError("Official prefill must request one output token")
            stage = "official_score_read"
        else:
            if self.records or requested_max != 4096:
                self.failed = True
                raise ValueError("Unexpected official review sequence or changed source contract")
            payload["max_tokens"], stage = 2048, "official_review"
        try:
            measured = self.tokenizer(payload)
            index = len(self.records)
            audit = {"request_index": index, "stage": stage,
                "upstream_max_tokens": requested_max, "effective_max_tokens": payload["max_tokens"],
                "local_prompt_tokens": measured["prompt_tokens"],
                "prompt_sha256": measured["prompt_sha256"],
                "serialized_prompt": measured["serialized_prompt"],
                "structured_outputs": payload.get("structured_outputs"),
                "scope": "Official constrained/top-k diagnostic, never strict-main score"}
            self.payload_audits.append(audit)
            record = self.client.post("/v1/chat/completions", payload,
                request_id=f"{self.run_id}:official:{index}", stage=stage,
                qid="official-toy", candidate_id="toy-pair", prompt_tokens=measured["prompt_tokens"])
            self.records.append(record)
            audit["raw_response_path"] = record.raw_response_path
            if record.status != "OK":
                raise RuntimeError("Official HTTP failed; subsequent upstream retries blocked")
            usage = record.usage or {}
            if usage.get("prompt_tokens") != measured["prompt_tokens"]:
                raise ValueError("Server usage does not verify local official serialization")
            if not is_prefill and record.finish_reason != "stop":
                raise ValueError("Official review did not finish within frozen 2048-token cap")
            if is_prefill and (usage.get("completion_tokens") != 1 or record.finish_reason not in ("length", "stop")):
                raise ValueError("Official score read did not produce one complete position")
            if self.response_factory is None:
                from openai.types.chat import ChatCompletion
                return ChatCompletion.model_validate(record.response)
            return self.response_factory(record.response)
        except Exception as exc:
            self.failed = True
            if self.first_error is None:
                self.first_error = {"error_type": type(exc).__name__,
                    "message": redact_diagnostic(str(exc)),
                    "completed_transport_records": len(self.records),
                    "payload_audits_created": len(self.payload_audits),
                    "tokenizer_diagnostics": list(getattr(self.tokenizer, "diagnostics", []))}
            raise


def inspect_extraction(module, text, tokens, position_logprobs, tag):
    """Identify the actual upstream branch without changing its result."""
    valid = module.SCALE["valid_tokens"]
    alternatives = module._find_tag_logprobs(tokens, position_logprobs, tag)
    grades, surfaces = set(), []
    for token, lp in alternatives or []:
        stripped = token.strip()
        if stripped.startswith(">"):
            stripped = stripped[1:].strip()
        if stripped in valid:
            grades.add(valid[stripped])
            surfaces.append({"surface": token, "raw_grade": valid[stripped], "logprob": lp})
    if grades:
        source = "UPSTREAM_DISTRIBUTION_WITH_MAX_OVER_VARIANTS"
    else:
        name = tag.strip("<>")
        matches = list(re.finditer(rf"<{re.escape(name)}>\s*(.+?)\s*</{re.escape(name)}>",
                                   text or "", re.IGNORECASE))
        literal = matches[-1].group(1).strip() if matches else None
        source = "TEXT_DISCRETE_FALLBACK" if literal and literal.lower() in valid else "DEFAULT_0_5_FALLBACK"
    return {"tag": tag, "source": source, "recognized_grade_count": len(grades),
        "all_20_grades_observed": len(grades) == 20,
        "missing_raw_grades": sorted(set(range(1, 21)) - grades),
        "observed_label_surfaces": surfaces, "strict_main_result": False,
        "limits": "No token-ID completeness gate; upstream max aggregation and grammar retained"}


def redact_diagnostic(value):
    text = str(value or "")
    text = re.sub(r"(?i)(bearer\s+)[^\s\"']+", r"\1[REDACTED]", text)
    text = re.sub(r"\bsk-[A-Za-z0-9_-]{12,}\b", "[REDACTED_KEY]", text)
    text = re.sub(r"(?i)((?:api[_-]?key|access[_-]?token|password)\s*[=:]\s*)[^\s,;]+",
                  r"\1[REDACTED]", text)
    return text


def save_report(path, report):
    def json_safe(value):
        if isinstance(value, float) and not math.isfinite(value):
            return None
        if isinstance(value, dict):
            return {key: json_safe(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [json_safe(item) for item in value]
        return value
    temporary = Path(str(path) + ".tmp")
    temporary.write_text(json.dumps(json_safe(report), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def run(args):
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    report_file = output / "official_compare_smoke.json"
    if report_file.exists():
        raise ValueError("Existing official smoke result must not be overwritten")
    manifest_path = Path(args.runtime_manifest)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    model = manifest.get("served_model_id", manifest.get("model_id"))
    endpoint, max_len = manifest.get("endpoint"), manifest.get("max_model_len")
    if not model or not endpoint or not isinstance(max_len, int) or max_len <= 0:
        raise ValueError("Manifest requires served_model_id/model_id, endpoint and max_model_len")
    report = {"started_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Official compare on two synthetic causal candidates; no project efficacy evidence",
        "strict_main_result": False, "precise_scoring_validation_passed": False,
        "independent_evaluation_labels": None, "accuracy": None,
        "runtime_manifest": str(manifest_path.resolve()), "runtime_manifest_sha256": digest_file(manifest_path),
        "model_id": model, "endpoint": endpoint, "n_evaluations": 1, "max_workers": 1,
        "review_output_tokens_max": 2048, "score_read_output_tokens_max": 1,
        "http_post_hard_cap": 3, "source_provenance": [], "official_api_smoke_passed": False,
        "deviations": ["Transport caps review at 2048 instead of upstream 4096",
            "A failed request closes transport; upstream retries cannot send HTTP",
            "Temporary extraction wrapper records provenance without changing returned scores"],
        "official_behavior_retained": ["coding-agent role", "A..T and leading-space grammar choices",
            "top_logprobs=20", "max-over-variants", "text and 0.5 fallback observability"],
        "experimental_rollouts_generated": 0}
    proxy = None
    try:
        spec = importlib.util.find_spec("llm_verifier")
        if spec is None or not spec.origin:
            raise ValueError("Pinned llm-verifier package is not installed")
        report["source_check"] = verify_sources(Path(spec.origin).parent, manifest)
        if importlib.metadata.version("llm-verifier") != "0.2.0":
            raise ValueError("Installed package metadata version is not 0.2.0")
        official = importlib.import_module("llm_verifier")
        reward = importlib.import_module("llm_verifier.fine_grained_reward")
        if Path(official.__file__).resolve() != Path(spec.origin).resolve():
            raise ValueError("Imported official module differs from source-checked path")
        rubrics_path = Path(args.rubrics)
        rubrics = json.loads(rubrics_path.read_text(encoding="utf-8-sig"))
        criterion = next(item for item in rubrics["criteria"] if item["id"] == "derivation_validity")
        report["criterion"], report["rubrics_sha256"] = criterion, digest_file(rubrics_path)
        journal = Path(args.journal).resolve() if args.journal else output.parent / "official_smoke_journal.sqlite"
        limits = {"global": BudgetLimit(3, args.max_total_tokens, args.max_seconds),
            "stage:official_review": BudgetLimit(1, args.max_total_tokens, args.max_seconds),
            "stage:official_score_read": BudgetLimit(2, args.max_total_tokens, args.max_seconds),
            "qid:official-toy": BudgetLimit(3, args.max_total_tokens, args.max_seconds),
            "candidate:official-toy:toy-pair": BudgetLimit(3, args.max_total_tokens, args.max_seconds)}
        client = JournaledClient(endpoint, journal, output / "raw_http", allowed_endpoints=[endpoint],
            limits=limits, timeout=args.timeout,
            api_key=os.environ.get(args.api_key_env) if args.api_key_env else None)
        counter = LocalTemplateCounter(args.tokenizer_python, args.model_path, max_len)
        proxy = OfficialProxy(client, model, args.run_id, counter)
        original_extract = reward.extract_score
        def observed_extract(text, tokens, position_logprobs, tag):
            provenance = inspect_extraction(reward, text, tokens, position_logprobs, tag)
            value = original_extract(text, tokens, position_logprobs, tag)
            provenance["returned_score"] = value
            report["source_provenance"].append(provenance)
            return value
        reward.extract_score = observed_extract
        try:
            scores = official.compare(TOY_TASK, TOY_A, TOY_B,
                criteria={"derivation_validity": criterion["description"]},
                ground_truth_note="", client=proxy, model=model, max_workers=1, n_evaluations=1)
        finally:
            reward.extract_score = original_extract
        valid_floats = len(scores) == 2 and all(isinstance(v, (int, float))
            and math.isfinite(v) and 0 <= v <= 1 for v in scores)
        report["scores"] = list(scores) if valid_floats else None
        report["execution_status"] = "COMPLETED" if valid_floats else "INVALID_RETURN_VALUE"
        provenance_ok = len(report["source_provenance"]) == 2 and all(
            row["source"] == "UPSTREAM_DISTRIBUTION_WITH_MAX_OVER_VARIANTS"
            for row in report["source_provenance"])
        neutral = valid_floats and all(abs(v - .5) < 1e-12 for v in scores)
        report["all_0_5_detected"] = neutral
        report["official_api_smoke_passed"] = bool(valid_floats and provenance_ok and not neutral
            and len(proxy.records) == 3 and all(r.status == "OK" for r in proxy.records) and not proxy.failed)
        report["status"] = "PASS_OFFICIAL_API_DIAGNOSTIC" if report["official_api_smoke_passed"] else "FAIL_OR_FALLBACK_DIAGNOSTIC"
    except Exception as exc:
        report["execution_status"], report["status"] = "FAILED", "FAIL_CLOSED"
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if proxy is not None:
            report["first_error"] = proxy.first_error
            if proxy.first_error:
                report["primary_error"] = proxy.first_error
            report["tokenizer_helper_diagnostics"] = list(getattr(proxy.tokenizer, "diagnostics", []))
            report["raw_calls"] = [r.to_dict() for r in proxy.records]
            report["payload_audits"] = proxy.payload_audits
            report["blocked_upstream_invocations"] = proxy.blocked_invocations
            report["http_accounting"] = proxy.client.summary()
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        save_report(report_file, report)
    return 0 if report["official_api_smoke_passed"] else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-manifest", required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--tokenizer-python", default=sys.executable,
        help="Existing Transformers Python; helper disables torch and network downloads")
    parser.add_argument("--rubrics", default=str(Path(__file__).resolve().parents[1] / "rubrics.json"))
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--journal", help="Shared journal retains three-POST cap across official-smoke runs")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--max-total-tokens", type=int, default=32768)
    parser.add_argument("--max-seconds", type=float, default=900)
    parser.add_argument("--timeout", type=float, default=300)
    parser.add_argument("--api-key-env")
    args = parser.parse_args()
    if args.max_total_tokens < 1 or args.max_seconds <= 0 or args.timeout <= 0:
        parser.error("Positive budgets required")
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
