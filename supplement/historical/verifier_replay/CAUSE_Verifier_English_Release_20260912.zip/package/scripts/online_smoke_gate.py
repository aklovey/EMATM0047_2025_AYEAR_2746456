#!/usr/bin/env python3
"""Offline stop gate for this frozen protocol; never sends model requests."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.replay import write_frozen

EXPECTED_INPUT_SHA256 = "8bbf18b0fc286d0955cc9b20ed41eb214af16aaf4e091c08716c4529bb9eb9ea"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = args.source_input.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != EXPECTED_INPUT_SHA256:
        parser.error("Input differs from the audited original protocol; do not infer a new budget")
    rows = [json.loads(line) for line in data.decode("utf-8").splitlines() if line.strip()]
    if len(rows) != 56 or len({row["question_id"] for row in rows}) != 56:
        parser.error("Original frozen 56-question pool is required")
    safe_counts = [(row["question_id"], sum(s.get("answer_exposed_prefix") is False
                    for s in row["segments"])) for row in rows]
    if any(count <= 0 for _, count in safe_counts):
        parser.error("Unknown or empty legal-step set; no execution authorized")
    qid, steps = min(safe_counts, key=lambda pair: pair[1])
    lower_bound = steps * 2 * 2
    if lower_bound <= 32:
        parser.error("Observed minimum no longer proves this task's stop condition; inspect, never auto-execute")
    result = {"status": "NOT_RUN_PROTOCOL_MINIMUM_EXCEEDS_32",
              "source_input": str(args.source_input.resolve()), "source_sha256": digest,
              "questions_in_original_pool": len(rows), "total_safe_steps": sum(n for _, n in safe_counts),
              "smallest_question_id": qid, "smallest_question_safe_steps": steps,
              "original_keep_trials_per_step": 2, "original_delete_trials_per_step": 2,
              "minimum_new_rollouts_one_complete_question": lower_bound,
              "replacement_generation_or_rollout_extras_included": False,
              "maximum_authorized_questions": 2, "maximum_authorized_new_rollouts": 32,
              "new_model_http_requests": 0, "new_pns_rollouts": 0,
              "protocol_changed": False, "execution_entrypoint": False,
              "scope": "Source-hash-bound lower bound for original full-question fixed-M2 protocol; adaptive protocol has its own larger minimum."}
    write_frozen(args.output, result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
