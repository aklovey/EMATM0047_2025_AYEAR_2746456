#!/usr/bin/env python3
"""Two authorized TP1 services, one frozen replay pool and one shared budget journal.

Only this orchestration is parallel: each unchanged scorer remains concurrency=1,
K=1, three criteria, review=2048/read=1, no new rollouts or acceptance. Request IDs,
seeds, model parameters and the original run_id are never changed by sharding.
"""
from __future__ import annotations
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import threading
import time

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from cause_verifier.client import BudgetLimit, JournaledClient, _canonical_endpoint
from cause_verifier.core import CRITERIA, ScoreRecord, canonical_json, content_hash
from cause_verifier.replay import derive_paired_scores
from cause_verifier.scorer import (ScorerConfig, ScorerPreflightError, _capability,
    bind_operational_status, run_frozen_replay, verify_frozen_pool_manifest)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def freeze(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(canonical_json(value) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def assign_workers(candidates, manifest):
    order = manifest["qid_order"]
    if not isinstance(order, list) or len(order) != len(set(order)) or len(order) < 2:
        raise ScorerPreflightError("A unique frozen question order with at least two questions is required")
    groups = {group["question_id"]: group for group in manifest["groups"]}
    if len(groups) != len(manifest["groups"]) or set(order) != set(groups):
        raise ScorerPreflightError("Question order differs from the complete manifest decision groups")
    owner, task_owner = {}, {}
    for index, qid in enumerate(order):
        group = groups[qid]
        worker = index % 2
        if group["task_id"] in task_owner:
            raise ScorerPreflightError("Each frozen question must have exactly one target group")
        task_owner[group["task_id"]] = worker
        for cid in group["raw_sample_ids"]:
            if cid in owner:
                raise ScorerPreflightError("A candidate is assigned more than once")
            owner[cid] = worker
    if set(owner) != {row["candidate_id"] for row in candidates}:
        raise ScorerPreflightError("Worker assignments do not cover the original candidate pool")
    shards = [[row for row in candidates if owner[row["candidate_id"]] == worker] for worker in (0, 1)]
    if not all(shards):
        raise ScorerPreflightError("Both authorized workers must receive frozen questions")
    return shards, owner, task_owner


def full_pool_limits(candidates, operational, config, max_seconds):
    eligible = [row for row in candidates if operational[row["candidate_id"]]["status"] == "valid"
        and operational[row["candidate_id"]]["completed"] is True
        and operational[row["candidate_id"]]["finish_reason"] == "stop"]
    per_task = Counter(row["task_id"] for row in eligible)
    stage_requests = len(eligible) * len(CRITERIA)
    limits = {"global": BudgetLimit(config.max_requests, config.max_tokens, max_seconds),
        "stage:verifier_review": BudgetLimit(stage_requests, stage_requests * config.max_model_len, max_seconds),
        "stage:verifier_score_read": BudgetLimit(stage_requests, stage_requests * config.max_model_len, max_seconds)}
    for task_id, count in per_task.items():
        limits["qid:" + task_id] = BudgetLimit(count * 6, count * 6 * config.max_model_len, max_seconds)
    for row in eligible:
        limits["candidate:" + row["task_id"] + ":" + row["candidate_id"]] = BudgetLimit(6, 6 * config.max_model_len, max_seconds)
    return limits, eligible


class ScoreBarrier:
    """Freeze both workers' actual score payloads before either worker reads scores."""
    def __init__(self, output, config, unified_preflight, max_seconds):
        self.output, self.config = Path(output), config
        self.unified_preflight = unified_preflight
        self.condition = threading.Condition()
        self.ready = set()
        self.failure = None
        self.frozen = False
        self.deadline = time.monotonic() + max_seconds

    def _freeze_if_ready(self):
        if self.frozen or len(self.ready) != 2 or self.failure:
            return
        phases = [read_json(self.output / f"worker_{i}" / "score_preflight.json") for i in (0, 1)]
        requests = [request for phase in phases for request in phase["requests"]]
        identities = [request["request_id"] for request in requests]
        if len(identities) != len(set(identities)):
            raise ScorerPreflightError("Duplicate HTTP identities in combined score preflight")
        actual_score_reserve = sum(request["prompt_tokens"] + 1 for request in requests)
        review_reserve = self.unified_preflight["exact_review_reserved_tokens"]
        reviews = self.unified_preflight["planned_review_requests"]
        if review_reserve + actual_score_reserve > self.config.max_tokens or reviews + len(requests) > self.config.max_requests:
            raise ScorerPreflightError("Combined actual score preflight exceeds the unchanged global budget")
        freeze(self.output / "global_score_preflight.json", {
            "all_review_workers_terminal_before_any_score_read": True,
            "all_actual_score_payloads_frozen_before_any_score_read": True,
            "run_id": self.config.run_id, "actual_score_read_requests": len(requests),
            "exact_score_reserved_tokens": actual_score_reserve,
            "combined_reserved_token_bound": review_reserve + actual_score_reserve,
            "worker_preflights": phases, "new_rollout_requests": 0})
        self.frozen = True

    def before_score(self, worker):
        with self.condition:
            self.ready.add(worker)
            try:
                self._freeze_if_ready()
            except Exception as exc:
                self.failure = type(exc).__name__ + ": " + str(exc)
            self.condition.notify_all()
            while not self.frozen and not self.failure:
                remaining = self.deadline - time.monotonic()
                if remaining <= 0:
                    self.failure = "Global score-preflight barrier exceeded the frozen task time budget"
                    self.condition.notify_all()
                    break
                self.condition.wait(min(30, remaining))
            if self.failure:
                raise ScorerPreflightError(self.failure)

    def worker_terminal(self, worker, error=None):
        with self.condition:
            if error:
                self.failure = self.failure or error
            self.ready.add(worker)  # A worker with zero eligible reads still joins.
            try:
                self._freeze_if_ready()
            except Exception as exc:
                self.failure = self.failure or type(exc).__name__ + ": " + str(exc)
            self.condition.notify_all()


class CallMeter:
    def __init__(self, owners):
        self.owners = dict(owners)
        self.lock = threading.Lock()
        self.active = 0
        self.peak = 0
        self.worker_active = {0: 0, 1: 0}
        self.request_ids = set()

    def enter(self, worker, request_id, candidate_id):
        with self.lock:
            if self.owners.get(candidate_id) != worker:
                raise ScorerPreflightError("Candidate sent to a worker that does not own it")
            if request_id in self.request_ids:
                raise ScorerPreflightError("Duplicate logical HTTP identity; never resend")
            if self.active >= 2 or self.worker_active[worker] != 0:
                raise ScorerPreflightError("Total concurrency exceeds two or a worker exceeds one")
            self.request_ids.add(request_id)
            self.active += 1
            self.worker_active[worker] += 1
            self.peak = max(self.peak, self.active)

    def leave(self, worker):
        with self.lock:
            self.active -= 1
            self.worker_active[worker] -= 1


class MeteredClient:
    def __init__(self, client, worker, meter, barrier):
        self.client, self.worker, self.meter, self.barrier = client, worker, meter, barrier
        self.endpoint = client.endpoint

    def post(self, path, payload, **kwargs):
        if kwargs["stage"] not in {"verifier_review", "verifier_score_read"}:
            raise ScorerPreflightError("Parallel replay permits only review and score-read HTTP stages")
        if kwargs["stage"] == "verifier_score_read":
            self.barrier.before_score(self.worker)
        self.meter.enter(self.worker, kwargs["request_id"], kwargs["candidate_id"])
        try:
            return self.client.post(path, payload, **kwargs)
        finally:
            self.meter.leave(self.worker)


def _request_signature(entry):
    return (entry["request_id"], content_hash(entry["payload"]), entry["prompt_tokens"], entry["seed"])


def recover_worker_records(worker_dir, candidates, worker_result):
    """Read-only recovery; preserve valid complete records and fill every other slot.

    Prefer the complete JSON array written before JSONL. Read JSONL one line at
    a time, so an interrupted last line cannot discard earlier complete rows.
    Conflicting records are UNKNOWN; missing/corrupt records never cause retries.
    """
    worker_dir = Path(worker_dir)
    candidate_index = {row["candidate_id"]: row for row in candidates}
    expected = {(row["candidate_id"], criterion) for row in candidates for criterion in CRITERIA}
    selected, selected_sources, conflicts = {}, {}, set()
    audit = {"worker_directory": str(worker_dir), "worker_failure": worker_result.get("error"),
             "source_files": [], "issues": [], "preserved_terminal_slots": 0,
             "synthesized_unknown_slots": 0, "model_requests_during_recovery": 0}

    def issue(code, source, line=None, key=None, detail=None):
        safe_key = list(key) if key and all(isinstance(part, str) for part in key) else None
        audit["issues"].append({"code": code, "source": str(source), "line": line,
                                "candidate_criterion": safe_key, "detail": detail})

    def absorb(record, source, line=None):
        key = None
        try:
            if not isinstance(record, dict):
                raise ValueError("Terminal score row must be an object")
            key = record.get("candidate_id"), record.get("criterion")
            if key not in expected:
                raise ValueError("Terminal score row is outside the assigned candidate/criterion slots")
            if record.get("status") not in {"VALID", "INVALID"}:
                raise ValueError("Terminal score status is absent or unrecognized")
            if record["status"] == "VALID":
                if record.get("candidate_hash") != content_hash(candidate_index[key[0]]["rollout"]):
                    raise ValueError("Valid score is bound to another candidate full text")
                if derive_paired_scores(record).get("status") != "valid":
                    raise ValueError("Valid score lacks a complete consistent exact distribution")
            elif record.get("score") is not None or record.get("discrete_score") is not None:
                raise ValueError("Invalid score row must not carry a usable numeric score")
            signature = canonical_json(record)  # Reject nonportable/NaN record fields.
        except (ValueError, TypeError, KeyError) as exc:
            issue("corrupt_terminal_record", source, line, key, str(exc))
            return
        if key in conflicts:
            return
        if key in selected:
            if canonical_json(selected[key]) != signature:
                issue("conflicting_terminal_records", source, line, key,
                      "Complete artifact copies disagree; retain UNKNOWN instead of choosing one")
                conflicts.add(key)
                del selected[key]
                selected_sources.pop(key, None)
            else:
                selected_sources[key].append({"path": str(source), "line": line})
            return
        selected[key] = record
        selected_sources[key] = [{"path": str(source), "line": line}]

    for name in ("score_records.json", "score_records.jsonl"):
        source = worker_dir / name
        if not source.exists():
            continue
        try:
            raw = source.read_bytes()
        except OSError as exc:
            issue("unreadable_score_artifact", source, detail=type(exc).__name__)
            continue
        audit["source_files"].append({"path": str(source), "bytes": len(raw),
                                      "sha256": hashlib.sha256(raw).hexdigest()})
        if name.endswith(".jsonl"):
            for number, line in enumerate(raw.splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line.decode("utf-8"))
                except (ValueError, UnicodeError) as exc:
                    issue("broken_jsonl_record", source, number, detail=type(exc).__name__)
                    continue
                absorb(record, source, number)
        else:
            try:
                records = json.loads(raw.decode("utf-8"))
                if not isinstance(records, list):
                    raise ValueError("Expected a complete terminal-score JSON array")
            except (ValueError, UnicodeError) as exc:
                issue("broken_json_array", source, detail=type(exc).__name__)
                continue
            for number, record in enumerate(records, 1):
                absorb(record, source, number)
    audit["preserved_terminal_slots"] = len(selected)
    rows = []
    for candidate in candidates:
        for criterion in CRITERIA:
            key = candidate["candidate_id"], criterion
            if key not in selected:
                code = "parallel_worker_record_conflict" if key in conflicts else "parallel_worker_record_missing_or_corrupt"
                record = ScoreRecord("INVALID", error_code=code,
                    error_detail=worker_result.get("error") or "No trustworthy complete terminal score record was written",
                    candidate_id=key[0], candidate_hash=content_hash(candidate["rollout"]), criterion=criterion).to_dict()
                record["recovery_status"] = "UNKNOWN"
                rows.append(record)
                audit["synthesized_unknown_slots"] += 1
            else:
                rows.append(selected[key])
    audit["preserved_record_sources"] = [
        {"candidate_id": key[0], "criterion": key[1], "sources": sources}
        for key, sources in selected_sources.items()]
    audit["status"] = ("RECOVERED_WITH_UNKNOWN" if audit["synthesized_unknown_slots"]
                       else "RECOVERED_WITH_ARTIFACT_ERRORS" if audit["issues"] or audit["worker_failure"]
                       else "CLEAN")
    return rows, audit


def run_parallel(*, candidates, raw_rows, original_requests, manifest, rubrics, config,
                 tokenizers, endpoints, capabilities, local_snapshots, output_dir,
                 journal_path, artifact_dir, max_seconds, timeout=300, execute=False,
                 api_keys=(None, None), transports=(None, None)):
    """Generic testable engine; the CLI additionally enforces the full 42/10/246 contract."""
    config.validate()
    if len(tokenizers) != 2 or tokenizers[0] is tokenizers[1]:
        raise ScorerPreflightError("Two independent tokenizer objects are required")
    if len(endpoints) != 2 or len(set(map(_canonical_endpoint, endpoints))) != 2:
        raise ScorerPreflightError("Exactly two distinct explicit loopback endpoints are required")
    endpoints = [_canonical_endpoint(value) for value in endpoints]
    verify_frozen_pool_manifest(candidates, raw_rows, manifest)
    operational = bind_operational_status(candidates, raw_rows, original_requests)
    shards, owners, task_owners = assign_workers(candidates, manifest)
    limits, eligible = full_pool_limits(candidates, operational, config, max_seconds)
    if len(eligible) * 6 > config.max_requests:
        raise ScorerPreflightError("The full original pool exceeds the unchanged request cap")
    output = Path(output_dir)
    if output.exists() and any(output.iterdir()):
        raise ScorerPreflightError("Output must be new; a previous run must never be restarted or overwritten")
    output.mkdir(parents=True, exist_ok=True)
    if len(local_snapshots) != 2 or any(snapshot.get("status") != "PASS"
            or snapshot.get("model_revision") != config.model_revision for snapshot in local_snapshots):
        raise ScorerPreflightError("Both worker-local snapshots must match the original model identity")
    snapshot_ids = {item.get("model_local_snapshot_fingerprint") for item in local_snapshots}
    if len(snapshot_ids) != 1 or None in snapshot_ids:
        raise ScorerPreflightError("Workers have different or missing local snapshot fingerprints")
    unified = run_frozen_replay(candidates=candidates, rubrics=rubrics, client=None,
        tokenizer=tokenizers[0], capabilities={}, config=config, output_dir=output / "full_pool_preflight",
        operational_status=operational, preflight_only=True)["preflight"]
    unified_signatures = {_request_signature(entry) for entry in unified["requests"]}
    shard_signatures = set()
    shard_plans = []
    for worker in (0, 1):
        plan = run_frozen_replay(candidates=shards[worker], rubrics=rubrics, client=None,
            tokenizer=tokenizers[worker], capabilities={}, config=config,
            output_dir=output / f"worker_{worker}_preflight", operational_status=operational,
            preflight_only=True)["preflight"]
        signatures = {_request_signature(entry) for entry in plan["requests"]}
        if shard_signatures & signatures:
            raise ScorerPreflightError("Duplicate review identity across worker plans")
        shard_signatures.update(signatures)
        shard_plans.append(plan)
    if shard_signatures != unified_signatures:
        raise ScorerPreflightError("Worker tokenization, payloads or review seeds differ from the unified original plan")
    frozen_plan = {"run_id": config.run_id, "config": asdict(config), "candidate_count": len(candidates),
        "question_count": len(manifest["qid_order"]), "eligible_candidates": len(eligible),
        "assignment_rule": "Frozen qid_order index modulo two; original candidate order preserved within each worker",
        "candidate_owner": owners, "task_owner": task_owners, "endpoints": endpoints,
        "worker_candidate_counts": [len(shard) for shard in shards],
        "worker_concurrency": [1, 1], "total_concurrency_limit": 2,
        "full_pool_limits": {scope: asdict(limit) for scope, limit in limits.items()},
        "full_pool_preflight": unified, "worker_preflights": shard_plans,
        "local_snapshots": local_snapshots, "new_rollout_requests": 0, "acceptance_enabled": False,
        "request_ids_and_review_seeds_unchanged_by_partitioning": True}
    freeze(output / "parallel_plan.json", frozen_plan)
    if not execute:
        return {"status": "PREFLIGHT_ONLY", "model_requests": 0, "new_rollout_requests": 0,
                "candidate_count": len(candidates), "worker_candidate_counts": frozen_plan["worker_candidate_counts"],
                "planned_http_max": unified["planned_http_max"], "run_id": config.run_id,
                "total_concurrency_limit": 2, "global_limits": asdict(limits["global"])}
    # Construct clients sequentially to avoid concurrent SQLite schema migrations.
    # They receive the SAME COMPLETE limits, never shard-sized stage/qid budgets.
    clients = [JournaledClient(endpoints[i], journal_path, artifact_dir,
               allowed_endpoints=endpoints, limits=limits, timeout=timeout,
               api_key=api_keys[i], transport=transports[i]) for i in (0, 1)]
    if clients[0].summary()["reserved_request_identities"] != 0:
        raise ScorerPreflightError("The replay journal already contains identities; do not restart or silently change run_id")
    if clients[0].journal_path != clients[1].journal_path or clients[0].artifact_dir != clients[1].artifact_dir:
        raise ScorerPreflightError("Workers must share one identical journal and HTTP artifact directory")
    for i in (0, 1):
        _capability(capabilities[i], config, clients[i])
        if capabilities[i].get("model_local_snapshot_fingerprint") != local_snapshots[i]["model_local_snapshot_fingerprint"]:
            raise ScorerPreflightError("Endpoint capability evidence refers to another local snapshot")
    freeze(output / "endpoint_capability_bindings.json", [
        {"endpoint": endpoints[i], "capability_hash": content_hash(capabilities[i]),
         "snapshot": local_snapshots[i], "status": "PASS"} for i in (0, 1)])
    meter = CallMeter(owners)
    barrier = ScoreBarrier(output, config, unified, max_seconds)
    wrappers = [MeteredClient(clients[i], i, meter, barrier) for i in (0, 1)]

    def worker_run(worker):
        error = None
        try:
            return run_frozen_replay(candidates=shards[worker], rubrics=rubrics, client=wrappers[worker],
                tokenizer=tokenizers[worker], capabilities=capabilities[worker], config=config,
                output_dir=output / f"worker_{worker}", operational_status=operational)
        except Exception as exc:
            error = type(exc).__name__ + ": " + str(exc)
            return {"status": "WORKER_FAILED", "error": error, "verifications": [], "http_records": []}
        finally:
            barrier.worker_terminal(worker, error)

    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="cause-verifier") as executor:
        futures = [executor.submit(worker_run, i) for i in (0, 1)]
        results = [future.result() for future in futures]
    score_index, verification_index, recovery_audits = {}, {}, []
    for worker in (0, 1):
        score_rows, recovery = recover_worker_records(output / f"worker_{worker}", shards[worker], results[worker])
        recovery_audits.append(recovery)
        for row in score_rows:
            key = row.get("candidate_id"), row.get("criterion")
            if owners.get(key[0]) != worker or key[1] not in CRITERIA or key in score_index:
                raise ScorerPreflightError("Duplicate, unassigned or invalid candidate/criterion in worker output")
            score_index[key] = row
        for row in results[worker].get("verifications", []):
            if row["candidate_id"] in verification_index:
                raise ScorerPreflightError("Duplicate candidate verification")
            verification_index[row["candidate_id"]] = row
    expected = {(row["candidate_id"], criterion) for row in candidates for criterion in CRITERIA}
    if set(score_index) != expected or meter.peak > 2 or meter.active != 0:
        raise ScorerPreflightError("Merged coverage or concurrency invariant failed")
    merged = [score_index[row["candidate_id"], criterion] for row in candidates for criterion in CRITERIA]
    freeze(output / "worker_recovery_audit.json", recovery_audits)
    with (output / "score_records.jsonl").open("x", encoding="utf-8", newline="\n") as handle:
        for row in merged:
            handle.write(canonical_json(row) + "\n")
    freeze(output / "score_records.json", merged)
    with closing(sqlite3.connect(str(clients[0].journal_path))) as db:
        rows = db.execute("SELECT request_id,endpoint,stage,qid,candidate_id,reserved_tokens,actual_total_tokens FROM requests").fetchall()
    identities = [row[0] for row in rows]
    charged_tokens = sum(max(row[5], row[6] or 0) for row in rows)
    stage_counts = Counter(row[2] for row in rows)
    if (len(identities) != len(set(identities)) or len(rows) > config.max_requests
            or charged_tokens > config.max_tokens
            or any(count > limits["stage:" + stage].max_requests for stage, count in stage_counts.items())):
        raise ScorerPreflightError("Shared-journal request identity/global-cap invariant failed")
    task_for_candidate = {row["candidate_id"]: row["task_id"] for row in candidates}
    for request_id, endpoint, stage, task_id, cid, reserved, actual in rows:
        if owners.get(cid) is None or endpoints[owners[cid]] != endpoint or stage not in {"verifier_review", "verifier_score_read"}:
            raise ScorerPreflightError("Shared-journal candidate ownership or HTTP stage invariant failed")
        if task_id != task_for_candidate[cid]:
            raise ScorerPreflightError("Shared-journal request was charged to the wrong question")
        if not request_id.startswith(config.run_id + ":" + cid + ":"):
            raise ScorerPreflightError("A request changed the original run identity")
    summary = {"status": "FAILED" if barrier.failure or any(result.get("status") == "WORKER_FAILED" for result in results)
               or any(audit["status"] != "CLEAN" for audit in recovery_audits)
               else "COMPLETE_WITH_UNKNOWN" if any(row["status"] != "VALID" for row in merged) else "COMPLETE",
        "run_id": config.run_id, "candidate_count": len(candidates), "criterion_records": len(merged),
        "valid_score_records": sum(row["status"] == "VALID" for row in merged),
        "invalid_score_records": sum(row["status"] != "VALID" for row in merged),
        "merged_in_original_candidate_and_criterion_order": True,
        "candidate_ownership_unique": True, "http_identities_unique": True,
        "maximum_observed_client_call_concurrency": meter.peak, "total_concurrency_limit": 2,
        "worker_concurrency": [1, 1], "global_limits": asdict(limits["global"]),
        "charged_token_budget_total": charged_tokens,
        "stage_limits": {stage: asdict(limit) for stage, limit in limits.items() if stage.startswith("stage:")},
        "client_accounting": clients[0].summary(), "worker_results": results,
        "worker_recovery": recovery_audits,
        "barrier_error": barrier.failure, "new_rollout_requests": 0, "acceptance_enabled": False,
        "verifications": [verification_index.get(row["candidate_id"], {"candidate_id": row["candidate_id"],
            "verification": {"status": "unknown", "reason": "parallel worker failed"}, "acceptance_enabled": False})
            for row in candidates]}
    freeze(output / "parallel_summary.json", summary)
    return summary


def load_tokenizer_and_snapshot(model_path, config):
    from probe_service import verify_local_snapshot
    from transformers import AutoTokenizer
    model_path = Path(model_path).resolve(strict=True)
    prefix = "UNKNOWN_HUB_REVISION_LOCAL_SNAPSHOT_"
    if not config.model_revision.startswith(prefix):
        raise ScorerPreflightError("This run requires its previously audited local snapshot identity")
    snapshot = verify_local_snapshot({"model_revision": config.model_revision,
        "model_local_snapshot_fingerprint": config.model_revision[len(prefix):]}, model_path)
    if hashlib.sha256((model_path / "tokenizer.json").read_bytes()).hexdigest() != config.tokenizer_hash:
        raise ScorerPreflightError("Tokenizer bytes differ from the unchanged frozen config")
    tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True, trust_remote_code=False)
    if not isinstance(tokenizer.chat_template, str) or hashlib.sha256(tokenizer.chat_template.encode()).hexdigest() != config.template_hash:
        raise ScorerPreflightError("Chat template differs from the unchanged frozen config")
    return tokenizer, snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("candidates", "raw-rollouts", "original-requests", "manifest", "config", "tokenizer-path",
                 "endpoint-0", "endpoint-1", "journal", "http-artifacts", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--rubrics", default=str(PACKAGE / "rubrics.json"))
    parser.add_argument("--capabilities-0")
    parser.add_argument("--capabilities-1")
    parser.add_argument("--max-seconds", required=True, type=float)
    parser.add_argument("--timeout", type=float, default=300)
    parser.add_argument("--api-key-env")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    config = ScorerConfig(**read_json(args.config))
    candidates, raw_rows = read_jsonl(args.candidates), read_jsonl(args.raw_rollouts)
    manifest = read_json(args.manifest)
    # Exact authorized production contract; the task's budget is not multiplied by GPUs.
    if (len(candidates) != 42 or len(manifest.get("qid_order", [])) != 10
            or config.max_requests != 246 or config.max_tokens != 4030464
            or config.max_model_len != 16384 or not config.run_id.endswith("001")):
        parser.error("Require the original 42-candidate/10-question run ...001 with global 246 requests, 4030464 tokens and max_model_len=16384")
    original_requests = read_jsonl(args.original_requests)
    operational = bind_operational_status(candidates, raw_rows, original_requests)
    _, eligible = full_pool_limits(candidates, operational, config, args.max_seconds)
    if len(eligible) != 41:
        parser.error("Original pool must retain exactly 41 valid candidates and its one invalid candidate")
    if args.execute and not (args.capabilities_0 and args.capabilities_1):
        parser.error("--execute requires a separate completed capability report for each endpoint")
    pairs = [load_tokenizer_and_snapshot(args.tokenizer_path, config) for _ in (0, 1)]
    caps = [read_json(path) if path else {} for path in (args.capabilities_0, args.capabilities_1)]
    api_key = os.environ.get(args.api_key_env) if args.api_key_env else None
    if args.api_key_env and not api_key:
        parser.error("Explicit local service authentication environment variable is absent")
    result = run_parallel(candidates=candidates, raw_rows=raw_rows, original_requests=original_requests,
        manifest=manifest, rubrics=read_json(args.rubrics), config=config,
        tokenizers=[pair[0] for pair in pairs], local_snapshots=[pair[1] for pair in pairs],
        endpoints=[args.endpoint_0, args.endpoint_1], capabilities=caps,
        output_dir=args.output, journal_path=args.journal, artifact_dir=args.http_artifacts,
        max_seconds=args.max_seconds, timeout=args.timeout, execute=args.execute, api_keys=(api_key, api_key))
    print(canonical_json({key: value for key, value in result.items() if key not in {"worker_results", "verifications"}}))
    return 1 if result["status"] == "FAILED" else 0


if __name__ == "__main__":
    raise SystemExit(main())
