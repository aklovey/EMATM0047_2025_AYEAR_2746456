#!/usr/bin/env python3
"""Freeze a real ten-question candidate replay; no network or model requests."""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.core import content_hash
from cause_verifier.replay import (FROZEN_QIDS, coverage_curves, file_sha256,
    prepare_replay_records, read_jsonl, summarize_scores, write_frozen)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--pool", type=Path, required=True)
    parser.add_argument("--journal", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    inputs = list(read_jsonl(args.input))
    # Retain source order and count all source samples, without loading 128MB at once.
    pool = []
    source_items, source_observations = 0, 0
    for row in read_jsonl(args.pool):
        source_items += 1
        source_observations += len(row["observations"])
        if int(row["question_id"]) in FROZEN_QIDS:
            pool.append(row)
    data = prepare_replay_records(inputs, pool)
    journal = sqlite3.connect(args.journal.resolve().as_uri() + "?mode=ro", uri=True)
    journal.row_factory = sqlite3.Row
    raw_requests = []
    try:
        for sample in data["raw_rollouts"]:
            row = journal.execute("SELECT * FROM requests WHERE request_key=?",
                                  (sample["request_key"],)).fetchone()
            if row is None:
                raise ValueError("Original request missing: " + sample["request_key"])
            request = dict(row)
            if (request["qid"] != sample["question_id"] or request["branch"] != sample["condition"]
                    or request["step_index"] != sample["target_step"]
                    or request["rollout"] != sample["rollout_index"]):
                raise ValueError("Pool/request provenance mismatch")
            obs = sample["original_observation"]
            if request["complete_chain"] != obs["full_reasoning"] or request["final_content"] != obs["final_content"]:
                raise ValueError("Pool candidate does not match original raw journal")
            body = json.loads(request["request_json"])
            if body.get("prompt") is None or not isinstance(body["prompt"], str):
                raise ValueError("Expected frozen raw continuation body")
            # Authentication is never part of the export even if a future source adds it.
            exported = {key: value for key, value in request.items() if key != "headers_json"}
            raw_requests.append({"candidate_id": sample["candidate_id"],
                                 "original_request": exported})
    finally:
        journal.close()
    coverage = coverage_curves(data["raw_rollouts"], data["offline_labels"])
    manifest = {"schema_version": 1, "dataset_status": "FROZEN_REAL_CANDIDATE_REPLAY_NO_MODEL_CALLS",
        "selection_rule": data["selection_rule"], "qid_order": data["qids"],
        "source_full_pool_items": source_items, "source_full_pool_raw_observations": source_observations,
        "frozen_question_count": len(data["groups"]), "frozen_raw_rollout_count": len(data["raw_rollouts"]),
        "frozen_invalid_rollout_count": sum(r["status"] != "valid" for r in data["raw_rollouts"]),
        "source_files": [{"role": role, "path": str(path.resolve()), "sha256": file_sha256(path)}
                         for role, path in (("input", args.input), ("pool", args.pool), ("journal", args.journal))],
        "blind_payload_hash": content_hash(data["blind_candidates"]),
        "groups": data["groups"], "criteria": ["query_fidelity", "derivation_validity", "conclusion_support"],
        "verifier_review_repeats": 1, "discrete_baseline_extra_requests": 0,
        "model_requests_made_by_preparation": 0, "new_rollout_calls": 0,
        "sampling_unit": "original independent request slot; identical content is not deduplicated",
        "label_scope": "answer_equivalence_only; independent causal-path and criterion labels unknown",
        "deployment_scope": "offline_replay_only_not_online_PNS_smoke",
        "acceptance_mode": "shadow_only_no_new_acceptance", "calibration": "not_available"}
    for name in ("blind_candidates", "raw_rollouts", "offline_labels"):
        write_frozen(args.output / (name + ".jsonl"), data[name], jsonl=True)
    write_frozen(args.output / "original_requests.jsonl", raw_requests, jsonl=True)
    write_frozen(args.output / "manifest.json", manifest)
    write_frozen(args.output / "coverage_before_scoring.json", coverage)
    write_frozen(args.output / "statistics_before_scoring.json", summarize_scores(
        data["raw_rollouts"], [], offline_labels=data["offline_labels"]))
    print(json.dumps({"status": manifest["dataset_status"], "questions": len(data["groups"]),
                      "raw_rollouts": len(data["raw_rollouts"]), "invalid_rollouts": manifest["frozen_invalid_rollout_count"],
                      "output": str(args.output.resolve()), "new_model_requests": 0}))


if __name__ == "__main__":
    main()
