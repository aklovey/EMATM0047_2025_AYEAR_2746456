#!/usr/bin/env python3
"""Bounded capability probes; never generates experimental PNS rollouts.

Requires a local tokenizer export made with the installed Transformers template.
This prevents a custom Jinja approximation silently changing assistant prefill.
tokenizers.json independently checks every serialized prefix and A..T suffix.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.client import BudgetLimit, JournaledClient, logprob_items, phase_completion


LABELS = "ABCDEFGHIJKLMNOPQRST"


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text_hash(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def save_json(path, value):
    temporary = Path(str(path) + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def verify_local_snapshot(export, model_path):
    model_path = Path(model_path)
    config_names = ("config.json", "generation_config.json", "tokenizer.json",
                    "tokenizer_config.json", "chat_template.jinja", "model.safetensors.index.json")
    meta = {"config_hashes": {name: file_hash(model_path / name) for name in config_names},
            "shards": [{"name": shard.name, "bytes": shard.stat().st_size,
                        "mtime_ns": shard.stat().st_mtime_ns}
                       for shard in sorted(model_path.glob("*.safetensors"))]}
    if not meta["shards"]:
        raise ValueError("No local weight-shard metadata found")
    # Must match the audited exporter: default JSON separators and ensure_ascii=True.
    fingerprint = hashlib.sha256(json.dumps(meta, sort_keys=True).encode()).hexdigest()
    if export.get("model_local_snapshot_fingerprint") != fingerprint:
        raise ValueError("Current local model snapshot differs from the offline export")
    identity = "UNKNOWN_HUB_REVISION_LOCAL_SNAPSHOT_" + fingerprint
    if export.get("model_revision") != identity:
        raise ValueError("Export model identity does not match the verified local snapshot")
    return {"status": "PASS", "model_revision": identity,
            "model_local_snapshot_fingerprint": fingerprint, "meta": meta,
            "hub_revision": None, "hub_revision_verified": False,
            "basis": "Config file SHA256 plus shard names/sizes/mtime_ns; weight contents are not fully hashed. Cache identity is restricted to this task's service lifecycle."}


def prepare_tokenizer(export, model_path):
    from tokenizers import Tokenizer
    tokenizer_file = Path(model_path) / "tokenizer.json"
    tokenizer = Tokenizer.from_file(str(tokenizer_file))
    digest = file_hash(tokenizer_file)
    declared = export.get("tokenizer_sha256")
    if declared and digest.lower() != declared.lower():
        raise ValueError("Local tokenizer hash differs from offline export")
    fixture = export.get("score_probe")
    if not isinstance(fixture, dict):
        raise ValueError("Missing authoritative score_probe fixture")
    prefix = fixture["serialized_prompt"]
    ids = tokenizer.encode(prefix, add_special_tokens=False).ids
    if fixture.get("prompt_token_ids") != ids:
        raise ValueError("Offline Transformers prefix IDs differ from tokenizers.json")
    if (fixture.get("add_generation_prompt") is not False
            or fixture.get("continue_final_message") is not True):
        raise ValueError("Export must explicitly attest prefill rendering options")
    declared_labels = fixture.get("label_tokens")
    labels, seen = {}, set()
    for label in LABELS:
        appended = tokenizer.encode(prefix + label, add_special_tokens=False).ids
        if appended[:-1] != ids or len(appended) != len(ids) + 1:
            raise ValueError(f"Label {label} does not preserve the complete prefix as one new token")
        tid = appended[-1]
        if tid in seen:
            raise ValueError("Score labels do not have distinct token IDs")
        seen.add(tid)
        labels[label] = [{"token_id": tid, "text": label, "token_count": 1}]
        if declared_labels is not None and declared_labels.get(label) != labels[label]:
            raise ValueError("Exported label map differs from independent tokenization")
    template_file = Path(model_path) / "chat_template.jinja"
    config_file = Path(model_path) / "tokenizer_config.json"
    if template_file.exists():
        template_text = template_file.read_text(encoding="utf-8")
    else:
        template_text = json.loads(config_file.read_text(encoding="utf-8"))["chat_template"]
        if not isinstance(template_text, str):
            raise ValueError("A named/multiple template export must provide an explicit template file")
    template_digest = text_hash(template_text)
    expected_template = export.get("chat_template_sha256")
    if expected_template and expected_template.lower() != template_digest.lower():
        raise ValueError("Local chat template differs from offline export")
    snapshot = verify_local_snapshot(export, model_path)
    return tokenizer, labels, {"tokenizer_sha256": digest,
        "chat_template_sha256": template_digest,
        "local_model_snapshot": snapshot,
        "single_token_labels": {"status": "PASS", "label_tokens": labels,
            "prompt_hash": text_hash(prefix), "prompt_token_ids": ids,
            "evidence": "Each encode(prefix+label) exactly equals encode(prefix)+one unique ID",
            "tokenization_verified": True}}


def fixture_ids(tokenizer, fixture):
    ids = tokenizer.encode(fixture["serialized_prompt"], add_special_tokens=False).ids
    if fixture.get("prompt_token_ids") != ids:
        raise ValueError("Fixture does not match the local exact tokenization")
    return ids


def assess_distribution(record, protocol, requested_ids, expected_prompt_tokens):
    result = {"status": "FAIL", "request_id": record.request_id,
        "evidence_refs": [record.raw_response_path] if record.raw_response_path else [],
        "http_record": record.to_dict(), "position_verified": False,
        "distribution_complete": False}
    if record.status != "OK":
        result["error"] = record.error or record.status
        return result
    try:
        observed = logprob_items(record.response, protocol=protocol)
        actual_ids = {item["token_id"] for item in observed}
        missing = sorted(set(requested_ids) - actual_ids)
        result.update(observed_logprobs=observed, missing_token_ids=missing,
            extra_token_ids=sorted(actual_ids - set(requested_ids)))
        usage = record.usage or {}
        prompt_matches = usage.get("prompt_tokens") == expected_prompt_tokens
        one_output = usage.get("completion_tokens") == 1
        position = prompt_matches and one_output and record.finish_reason in ("length", "stop")
        result.update(distribution_complete=not missing,
            position_verified=position, prompt_tokens_match=prompt_matches,
            one_generated_token=one_output, observed_score_position=0,
            phase_status=phase_completion("score_read", record.finish_reason,
                                          distribution_complete=not missing and position))
        if missing or not position:
            result["error"] = "Missing target IDs or unverified exact generated position/usage"
        else:
            result["status"] = "PASS"
    except (ValueError, KeyError, TypeError) as exc:
        result["error"] = str(exc)
    return result


def compare_distributions(first, second, requested_ids, *, logprob_atol, score_atol):
    result = {"status": "FAIL", "logprob_absolute_tolerance": logprob_atol,
              "score_absolute_tolerance": score_atol}
    if first.get("status") != "PASS" or second.get("status") != "PASS":
        result["error"] = "Both reference distributions must independently pass"
        return result
    aa = {x["token_id"]: x["logprob"] for x in first["observed_logprobs"]}
    bb = {x["token_id"]: x["logprob"] for x in second["observed_logprobs"]}
    diffs = [0. if aa[tid] == bb[tid] else abs(aa[tid] - bb[tid]) for tid in requested_ids]
    max_delta = max(diffs)
    def expectation(mapping):
        lps = [mapping[tid] for tid in requested_ids]
        peak = max(lps)
        if not math.isfinite(peak):
            raise ValueError("All labels have zero probability")
        masses = [math.exp(lp - peak) for lp in lps]
        return sum(p * (19-i)/19 for i, p in enumerate(masses)) / sum(masses)
    try:
        first_score, second_score = expectation(aa), expectation(bb)
        score_delta = abs(first_score - second_score)
        result.update(max_label_logprob_delta=max_delta if math.isfinite(max_delta) else None,
            first_score=first_score, second_score=second_score, score_delta=score_delta,
            status="PASS" if max_delta <= logprob_atol and score_delta <= score_atol else "FAIL")
    except ValueError as exc:
        result["error"] = str(exc)
    return result


def schema_properties(openapi, name):
    return openapi.get("components", {}).get("schemas", {}).get(name, {}).get("properties", {})


def run(args):
    export_path = Path(args.tokenizer_probe)
    export = json.loads(export_path.read_text(encoding="utf-8-sig"))
    audit_path = Path(args.service_audit)
    audit = json.loads(audit_path.read_text(encoding="utf-8-sig"))
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    result_path = output / "capabilities.json"
    if result_path.exists():
        raise ValueError("Use the same journal to inspect old identities, or a new explicitly named output directory; never overwrite a probe run")
    tokenizer, label_tokens, token_report = prepare_tokenizer(export, args.model_path)
    score_fixture = export["score_probe"]
    score_ids = fixture_ids(tokenizer, score_fixture)
    requested_ids = [label_tokens[label][0]["token_id"] for label in LABELS]
    model = args.model
    if export.get("model_id", model) != model:
        raise ValueError("Model ID differs from offline export")
    limits = {"global": BudgetLimit(20, args.max_total_tokens, args.max_seconds),
        "stage:score_read": BudgetLimit(8, args.max_total_tokens, args.max_seconds),
        "stage:capability": BudgetLimit(6, 0, args.max_seconds),
        "stage:ordinary_chat": BudgetLimit(2, args.max_total_tokens, args.max_seconds),
        "stage:pns_raw_capability": BudgetLimit(2, args.max_total_tokens, args.max_seconds),
        "qid:probe": BudgetLimit(20, args.max_total_tokens, args.max_seconds),
        "candidate:probe:score": BudgetLimit(8, args.max_total_tokens, args.max_seconds)}
    # One task-level journal retains the 20-request ceiling across probe output runs.
    journal_path = Path(args.journal).resolve() if args.journal else output.parent / "probe_http_journal.sqlite"
    client = JournaledClient(args.endpoint, journal_path, output / "raw_http",
        allowed_endpoints=[args.endpoint], limits=limits, timeout=args.timeout,
        api_key=os.environ.get(args.api_key_env) if args.api_key_env else None)
    report = {"schema_version": 1, "started_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "Capability probes only; zero experimental PNS rollouts",
        "model_id": model, "model_path": str(Path(args.model_path).resolve()),
        "model_revision": token_report["local_model_snapshot"]["model_revision"],
        "model_local_snapshot_fingerprint": token_report["local_model_snapshot"]["model_local_snapshot_fingerprint"],
        "model_revision_basis": token_report["local_model_snapshot"]["basis"],
        "hub_revision": None,
        "endpoint": args.endpoint, "tokenizer": token_report,
        "journal_path": str(journal_path),
        "offline_export_path": str(export_path.resolve()), "offline_export_sha256": file_hash(export_path),
        "service_audit_path": str(audit_path.resolve()), "service_audit_sha256": file_hash(audit_path),
        "http_hard_cap": 20, "max_total_tokens": args.max_total_tokens,
        "max_seconds": args.max_seconds, "logprob_atol": args.logprob_atol,
        "score_atol": args.score_atol, "capabilities": {}, "requests": []}
    def checkpoint():
        report["http_summary"] = client.summary()
        save_json(result_path, report)
    def get(label, path):
        record = client.get(path, request_id=f"{args.run_id}:{label}")
        report["requests"].append(record.to_dict())
        checkpoint()
        return record
    def post(label, path, payload, ids, stage="score_read", candidate="score"):
        if not 1 <= payload["max_tokens"] <= 64:
            raise ValueError("Every model probe is capped at 64 tokens")
        if stage in ("score_read", "pns_raw_capability") and payload["max_tokens"] != 1:
            raise ValueError("Score/PNS capability reads are exactly one output token")
        record = client.post(path, payload, request_id=f"{args.run_id}:{label}", stage=stage,
            qid="probe", candidate_id=candidate, prompt_tokens=len(ids))
        report["requests"].append(record.to_dict())
        checkpoint()
        return record
    try:
        health = get("health", "/health")
        models = get("models", "/v1/models")
        schema = get("openapi", "/openapi.json")
        observed_models = [item.get("id") for item in (models.response or {}).get("data", [])]
        report["capabilities"]["service_identity"] = {"status": "PASS" if
            health.status == "OK" and models.status == "OK" and model in observed_models else "FAIL",
            "served_models": observed_models}
        if report["capabilities"]["service_identity"]["status"] != "PASS":
            raise ValueError("Service health or served model identity not verified")
        chat_fields = schema_properties(schema.response or {}, "ChatCompletionRequest")
        completion_fields = schema_properties(schema.response or {}, "CompletionRequest")
        required = {"logprob_token_ids", "logprobs", "return_tokens_as_token_ids"}
        report["capabilities"]["request_schema"] = {
            "status": "PASS" if schema.status == "OK" and required <= set(chat_fields)
                and required <= set(completion_fields) else "FAIL",
            "chat_field_presence": {name: name in chat_fields for name in sorted(required)},
            "completion_field_presence": {name: name in completion_fields for name in sorted(required)}}
        if report["capabilities"]["request_schema"]["status"] != "PASS":
            raise ValueError("Real OpenAPI schema does not confirm required token-ID fields")
        base = {"model": model, "prompt": score_ids, "max_tokens": 1, "logprobs": len(requested_ids),
            "logprob_token_ids": requested_ids, "return_tokens_as_token_ids": True,
            "temperature": 1.0, "top_p": 1.0, "top_k": -1,
            "presence_penalty": 0.0, "frequency_penalty": 0.0, "repetition_penalty": 1.0,
            "seed": args.seed, "stream": False}
        raw1 = post("raw_reference", "/v1/completions", base, score_ids)
        raw_check = assess_distribution(raw1, "completion", requested_ids, len(score_ids))
        report["capabilities"]["raw_reference"] = raw_check
        changed = dict(base, temperature=0.7, top_p=0.6, top_k=5)
        raw2 = post("raw_sampling_variant", "/v1/completions", changed, score_ids)
        varied_check = assess_distribution(raw2, "completion", requested_ids, len(score_ids))
        stability = compare_distributions(raw_check, varied_check, requested_ids,
            logprob_atol=args.logprob_atol, score_atol=args.score_atol)
        stability["reference"] = raw1.request_id
        stability["variant"] = varied_check
        report["capabilities"]["raw_sampling_invariance"] = stability
        # Score-reading requests have no grammar, whitelist, logit bias or review regeneration.
        chat = {key: value for key, value in base.items() if key not in ("prompt", "logprobs")}
        chat.update(messages=score_fixture["messages"], logprobs=True,
            top_logprobs=len(requested_ids), add_generation_prompt=False, continue_final_message=True,
            chat_template_kwargs=score_fixture.get("chat_template_kwargs", {}))
        chat_record = post("chat_prefill", "/v1/chat/completions", chat, score_ids)
        chat_check = assess_distribution(chat_record, "chat", requested_ids, len(score_ids))
        equivalence = compare_distributions(raw_check, chat_check, requested_ids,
            logprob_atol=args.logprob_atol, score_atol=args.score_atol)
        equivalence["chat"] = chat_check
        equivalence["raw_reference"] = raw1.request_id
        report["capabilities"]["chat_prefill_raw_equivalence"] = equivalence
        raw_mode = (audit.get("logprobs_mode") == "raw_logprobs"
                    and audit.get("logprobs_mode_verified") is True
                    and bool(audit.get("evidence_refs")))
        exact = {"status": "PASS" if raw_check["status"] == "PASS"
            and stability["status"] == "PASS" and raw_mode else "FAIL",
            "logprobs_mode": audit.get("logprobs_mode"), "mode_evidence_verified": raw_mode,
            "request_fields": {"logprobs": len(requested_ids), "logprob_token_ids": [],
                "return_tokens_as_token_ids": True},
            "token_id_key_format": "token_id:{id}", "response_parser": "completion_token_id_keys_v1",
            "prompt_token_ids_supported": raw_check["status"] == "PASS",
            "score_position": 0, "position_verified": raw_check.get("position_verified", False),
            "tokenization_verified": True, "distribution_complete": raw_check.get("distribution_complete", False),
            "evidence_refs": [raw1.raw_response_path, raw2.raw_response_path, str(audit_path.resolve())]}
        report["capabilities"]["exact_raw_completion"] = exact
        ordinary = export.get("ordinary_probe")
        if ordinary:
            ordinary_ids = fixture_ids(tokenizer, ordinary)
            payload = {"model": model, "messages": ordinary["messages"], "max_tokens": 32,
                "temperature": 1., "top_p": .95, "top_k": 20, "seed": args.seed,
                "chat_template_kwargs": ordinary.get("chat_template_kwargs", {}), "stream": False}
            ordinary_record = post("ordinary_chat", "/v1/chat/completions", payload,
                ordinary_ids, stage="ordinary_chat", candidate="ordinary")
            choice = ((ordinary_record.response or {}).get("choices") or [{}])[0]
            message = choice.get("message") or {}
            has_text = any(message.get(key) for key in ("content", "reasoning", "reasoning_content"))
            report["capabilities"]["ordinary_chat"] = {"status": "PASS" if
                ordinary_record.status == "OK" and has_text and
                (ordinary_record.usage or {}).get("prompt_tokens") == len(ordinary_ids) else "FAIL",
                "phase_status": phase_completion("review", ordinary_record.finish_reason),
                "finish_reason": ordinary_record.finish_reason,
                "evidence_refs": [ordinary_record.raw_response_path],
                "scope": "text generation capability; no full rollout completion claim"}
        else:
            report["capabilities"]["ordinary_chat"] = {"status": "NOT_RUN", "reason": "No exact ordinary-chat template fixture"}
        pns = export.get("pns_probe")
        if pns and pns.get("source_ref"):
            pns_ids = fixture_ids(tokenizer, pns)
            payload = {"model": model, "prompt": pns_ids, "max_tokens": 1,
                "temperature": 1., "top_p": .95, "top_k": 20, "seed": args.seed,
                "logprobs": 1, "return_tokens_as_token_ids": True, "stream": False}
            pns_record = post("pns_raw_prefix", "/v1/completions", payload,
                pns_ids, stage="pns_raw_capability", candidate="pns-prefix")
            try:
                observed = logprob_items(pns_record.response or {}, protocol="completion")
                passed = (pns_record.status == "OK" and bool(observed)
                    and (pns_record.usage or {}).get("prompt_tokens") == len(pns_ids)
                    and (pns_record.usage or {}).get("completion_tokens") == 1)
            except ValueError:
                observed, passed = [], False
            report["capabilities"]["pns_raw_continuation"] = {
                "status": "PASS" if passed else "FAIL", "source_ref": pns["source_ref"],
                "prompt_hash": text_hash(pns["serialized_prompt"]), "prompt_token_count": len(pns_ids),
                "observed_logprobs": observed, "evidence_refs": [pns_record.raw_response_path],
                "scope": "Preserves the exact original RAW prefix and generates one next token",
                "experimental_rollouts": 0, "full_rollout_behavior_regression": "NOT_RUN",
                "finish_reason": pns_record.finish_reason}
        else:
            report["capabilities"]["pns_raw_continuation"] = {"status": "NOT_RUN",
                "reason": "No source-backed original PNS RAW prefix fixture; no guessed template used"}
        required_capabilities = ("exact_raw_completion", "chat_prefill_raw_equivalence",
                                 "ordinary_chat", "pns_raw_continuation")
        report["required_capabilities"] = list(required_capabilities)
        report["status"] = "PASS" if all(report["capabilities"][name]["status"] == "PASS"
            for name in required_capabilities) else ("PARTIAL" if exact["status"] == "PASS" else "FAIL")
        report["completed_at"] = datetime.now(timezone.utc).isoformat()
        checkpoint()
        return 0 if report["status"] == "PASS" else 2
    except Exception as exc:
        report["status"] = "FAIL"
        report["error"] = f"{type(exc).__name__}: {exc}"
        checkpoint()
        return 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--endpoint", default="http://127.0.0.1:8000")
    parser.add_argument("--model", default="Qwen/Qwen3.6-35B-A3B")
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--tokenizer-probe", required=True)
    parser.add_argument("--service-audit", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--journal", help="Shared task-level probe journal; defaults to output-dir's parent/probe_http_journal.sqlite")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--max-total-tokens", type=int, default=32768)
    parser.add_argument("--max-seconds", type=float, default=600)
    parser.add_argument("--timeout", type=float, default=60)
    parser.add_argument("--logprob-atol", type=float, default=0.002)
    parser.add_argument("--score-atol", type=float, default=0.0001)
    parser.add_argument("--api-key-env", help="Optional explicit authorization variable; never persisted")
    args = parser.parse_args()
    if args.max_total_tokens < 1 or args.max_seconds <= 0 or args.logprob_atol < 0 or args.score_atol < 0:
        parser.error("Positive budgets and nonnegative frozen tolerances required")
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
