#!/usr/bin/env python3
"""Preflight by default; --execute scores frozen candidates against local vLLM.

No candidate generation or acceptance mode is exposed. All model/task identities
and budgets come from an explicit frozen config; no model download or cloud route.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
from collections import Counter

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cause_verifier.client import BudgetLimit, JournaledClient
from cause_verifier.core import canonical_json
from cause_verifier.scorer import (ScorerConfig, bind_operational_status, run_frozen_replay,
                                   verify_frozen_pool_manifest)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates", required=True)
    parser.add_argument("--raw-rollouts", required=True)
    parser.add_argument("--original-requests", required=True)
    parser.add_argument("--manifest", required=True, help="Frozen replay manifest with blind payload hash and decision groups")
    parser.add_argument("--config", required=True, help="Frozen ScorerConfig JSON")
    parser.add_argument("--rubrics", default=str(Path(__file__).resolve().parents[1] / "rubrics.json"))
    parser.add_argument("--tokenizer-path", required=True, help="Existing local model/tokenizer directory")
    parser.add_argument("--capabilities", help="Live probe capabilities JSON, required with --execute")
    parser.add_argument("--output", required=True, help="New output directory, never a prior run")
    parser.add_argument("--endpoint", help="Explicit loopback origin; required with --execute")
    parser.add_argument("--journal", help="Shared budget/request SQLite journal; required with --execute")
    parser.add_argument("--http-artifacts", help="Shared immutable HTTP artifact directory; required with --execute")
    parser.add_argument("--max-seconds", type=float, default=3600)
    parser.add_argument("--timeout", type=float, default=300)
    parser.add_argument("--api-key-env", help="Explicit existing LOCAL service auth env name, if needed")
    parser.add_argument("--execute", action="store_true", help="Execute the frozen review/read plan; no new rollouts")
    args = parser.parse_args()
    if args.execute and not all((args.capabilities, args.endpoint, args.journal, args.http_artifacts)):
        parser.error("--execute requires capabilities, endpoint, journal and http-artifacts")
    config = ScorerConfig(**read_json(args.config))
    config.validate()
    tokenizer_path = Path(args.tokenizer_path).resolve(strict=True)
    tokenizer_file = tokenizer_path / "tokenizer.json"
    if hashlib.sha256(tokenizer_file.read_bytes()).hexdigest() != config.tokenizer_hash:
        parser.error("Local tokenizer.json does not match the frozen tokenizer hash")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(tokenizer_path), local_files_only=True, trust_remote_code=False)
    template = tokenizer.chat_template
    if not isinstance(template, str) or hashlib.sha256(template.encode("utf-8")).hexdigest() != config.template_hash:
        parser.error("Live local chat template does not match the frozen template hash")
    candidates = read_jsonl(args.candidates)
    raw_rows = read_jsonl(args.raw_rollouts)
    verify_frozen_pool_manifest(candidates, raw_rows, read_json(args.manifest))
    operational = bind_operational_status(candidates, raw_rows, read_jsonl(args.original_requests))
    caps = read_json(args.capabilities) if args.capabilities else {}
    client = None
    if args.execute:
        api_key = None
        if args.api_key_env:
            api_key = os.environ.get(args.api_key_env)
            if not api_key:
                parser.error("Explicit local service authentication environment variable is absent")
        eligible = [row for row in candidates if operational[row["candidate_id"]]["status"] == "valid"
                    and operational[row["candidate_id"]]["completed"] is True
                    and operational[row["candidate_id"]]["finish_reason"] == "stop"]
        per_task = Counter(row["task_id"] for row in eligible)
        limits = {"global": BudgetLimit(config.max_requests, config.max_tokens, args.max_seconds),
                  "stage:verifier_review": BudgetLimit(len(eligible) * 3, len(eligible) * 3 * config.max_model_len, args.max_seconds),
                  "stage:verifier_score_read": BudgetLimit(len(eligible) * 3, len(eligible) * 3 * config.max_model_len, args.max_seconds)}
        for task_id, count in per_task.items():
            limits["qid:" + task_id] = BudgetLimit(count * 6, count * 6 * config.max_model_len, args.max_seconds)
        for row in eligible:
            limits["candidate:" + row["task_id"] + ":" + row["candidate_id"]] = BudgetLimit(6, 6 * config.max_model_len, args.max_seconds)
        client = JournaledClient(args.endpoint, args.journal, args.http_artifacts,
                    allowed_endpoints=[args.endpoint], limits=limits,
                    timeout=args.timeout, api_key=api_key)
    result = run_frozen_replay(candidates=candidates, rubrics=read_json(args.rubrics), client=client,
        tokenizer=tokenizer, capabilities=caps, config=config, output_dir=args.output,
        operational_status=operational, preflight_only=not args.execute)
    compact = {key: value for key, value in result.items() if key not in ("preflight", "http_records", "verifications")}
    if not args.execute:
        plan = result["preflight"]
        compact.update(planned_http_max=plan["planned_http_max"],
                       combined_reserved_tokens_upper_bound=plan["combined_reserved_tokens_upper_bound"],
                       exact_review_reserved_tokens=plan["exact_review_reserved_tokens"])
    if client is not None:
        compact["client_accounting"] = client.summary()
    print(canonical_json(compact))


if __name__ == "__main__":
    main()
