"""Start the audited local service; restore the observed initial stopped state.

No vLLM upgrade, global process termination, or experiment resumption is performed.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
from urllib.request import urlopen


def identity(pid):
    try:
        path = Path('/proc') / str(pid)
        stat = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        return {'argv': [v.decode() for v in (path / 'cmdline').read_bytes().split(b'\0') if v],
                'starttime': stat[19], 'state': stat[0]}
    except (FileNotFoundError, ProcessLookupError):
        return None


def active_services():
    found = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        ident = identity(int(path.name))
        if not ident or ident['state'] == 'Z':
            continue
        args = ident['argv']
        if ('serve' in args and any('vllm' in s for s in args)) or any(
            s.endswith(('run_qwen_pns_adaptive.py', 'batch56_runner.py')) for s in args
        ):
            found.append(int(path.name))
    return found


def health():
    try:
        with urlopen('http://127.0.0.1:8000/health', timeout=3) as response:
            return response.status
    except Exception:
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['start', 'status', 'restore'])
    parser.add_argument('--root', required=True, type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    task = json.loads((root / 'task_identity.json').read_text())
    if task['instance'] not in socket.gethostname():
        raise RuntimeError('Refusing to operate on another instance')
    manifest = json.loads((root / 'original_service_manifest.json').read_text())
    state_path = root / 'service_process.json'
    if args.action == 'status':
        state = json.loads(state_path.read_text()) if state_path.exists() else {}
        ident = identity(state['pid']) if 'pid' in state else None
        print(json.dumps({'record': state, 'identity': ident, 'health': health()}))
        return
    if args.action == 'restore':
        if manifest['initially_running']:
            raise RuntimeError('This task rollback supports its audited initially-stopped state only')
        if state_path.exists():
            state = json.loads(state_path.read_text())
            pid = state['pid']
            actual = identity(pid)
            if actual and actual['state'] != 'Z':
                if actual['argv'] != state['argv'] or actual['starttime'] != state['starttime']:
                    raise RuntimeError('PID reused or service identity changed; not signaling')
                if os.getpgid(pid) != pid:
                    raise RuntimeError('Task service is no longer its own process group')
                os.killpg(pid, signal.SIGTERM)
                deadline = time.monotonic() + 45
                while time.monotonic() < deadline:
                    actual = identity(pid)
                    if not actual or actual['state'] == 'Z':
                        break
                    time.sleep(0.5)
                else:
                    raise RuntimeError('Graceful service stop not complete; no forced kill performed')
        if health() is not None or active_services():
            raise RuntimeError('Initial stopped service state not restored')
        result = {'status': 'RESTORED_INITIAL_STOPPED_STATE', 'verified_utc': time.time(),
                  'inference_environment_modified': False}
        (root / 'rollback_verification.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result))
        return
    if active_services() or health() is not None:
        raise RuntimeError('A service or experiment is active; refusing to launch')
    if state_path.exists():
        raise RuntimeError('An existing launch record needs an explicit reviewed new run directory')
    gpu = subprocess.run(['nvidia-smi', '--query-gpu=index,name,memory.total,memory.free,uuid',
                          '--format=csv,noheader,nounits'], text=True, capture_output=True, check=True)
    (root / 'gpu_before_service.csv').write_text(gpu.stdout)
    gpu0 = [s.strip() for s in gpu.stdout.splitlines()[0].split(',')]
    if gpu0[0] != '0' or float(gpu0[3]) < float(gpu0[2]) * .85:
        raise RuntimeError('GPU 0 does not have the audited service memory headroom')
    source = Path(manifest['launch_environment_source'])
    spec = importlib.util.spec_from_file_location('audited_original_launch', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    argv = manifest['original_argv']
    if module.EXPECTED_ARGV != argv:
        raise RuntimeError('Audited source and saved launch arguments differ')
    service_dir = root / 'service'
    service_dir.mkdir(exist_ok=False)
    module.SERVICE_DIR = service_dir
    env = module.build_launch_env()
    env['CUDA_VISIBLE_DEVICES'] = '0'
    with (service_dir / 'vllm.log').open('xb') as log:
        process = subprocess.Popen(argv, cwd=service_dir, env=env, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    actual = identity(process.pid)
    state = {'pid': process.pid, 'argv': argv, 'starttime': actual['starttime'],
             'started_utc': time.time(), 'log_path': str(service_dir / 'vllm.log'),
             'status': 'LAUNCHED_NOT_YET_HEALTH_VERIFIED'}
    state_path.write_text(json.dumps(state, indent=2))
    print(json.dumps(state))


if __name__ == '__main__':
    main()
