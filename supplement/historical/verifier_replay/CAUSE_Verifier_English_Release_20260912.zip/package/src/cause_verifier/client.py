"""Local-only, journaled HTTP requests with durable identities and no retries.

Only stdlib imports. A failed or interrupted identity is never sent again.
Budgets count every reserved HTTP attempt, including failures and GET probes.
Token budgets conservatively reserve exact prompt tokens plus output allowance.
"""
from __future__ import annotations

import dataclasses
from contextlib import closing
import hashlib
import ipaddress
import json
import math
import os
from pathlib import Path
import sqlite3
import time
from typing import Any, Mapping
import urllib.error
import urllib.parse
import urllib.request


class ClientError(RuntimeError):
    pass


class DuplicateRequestError(ClientError):
    pass


class BudgetExceeded(ClientError):
    pass


@dataclasses.dataclass(frozen=True)
class BudgetLimit:
    max_requests: int
    max_tokens: int
    max_seconds: float

    def __post_init__(self):
        if (isinstance(self.max_requests, bool) or not isinstance(self.max_requests, int)
                or self.max_requests < 0 or isinstance(self.max_tokens, bool)
                or not isinstance(self.max_tokens, int) or self.max_tokens < 0
                or not math.isfinite(self.max_seconds) or self.max_seconds <= 0):
            raise ValueError("Budgets must have nonnegative counts and positive finite time")


@dataclasses.dataclass
class HTTPRecord:
    request_id: str
    status: str
    http_status: int | None = None
    response: dict[str, Any] | None = None
    raw_response_path: str | None = None
    request_path: str | None = None
    usage: dict[str, Any] | None = None
    elapsed_seconds: float = 0.0
    error: str | None = None
    finish_reason: str | None = None
    request_sha256: str | None = None
    raw_response_sha256: str | None = None
    reserved_tokens: int = 0
    actual_total_tokens: int | None = None
    transport_attempted: bool = False
    response_received: bool = False
    response_complete: bool = False

    def to_dict(self):
        return dataclasses.asdict(self)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _canonical_endpoint(value: str) -> str:
    parsed = urllib.parse.urlsplit(value)
    if (parsed.scheme not in ("http", "https") or not parsed.hostname
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path not in ("", "/")):
        raise ValueError("Endpoint must be an explicit local origin without credentials or path")
    host = parsed.hostname.lower()
    if host != "localhost":
        try:
            if not ipaddress.ip_address(host).is_loopback:
                raise ValueError("Only loopback model endpoints are permitted")
        except ValueError as exc:
            raise ValueError("Only literal loopback IPs or localhost are permitted") from exc
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    host = f"[{host}]" if ":" in host else host
    return f"{parsed.scheme}://{host}:{port}"


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def _write_new(path: Path, data: bytes):
    # Existing artifacts for an identity must never be overwritten.
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def _usage(body: Mapping[str, Any] | None) -> tuple[dict | None, int | None]:
    value = body.get("usage") if body else None
    if not isinstance(value, dict):
        return None, None
    total = value.get("total_tokens")
    if isinstance(total, bool) or not isinstance(total, int) or total < 0:
        prompt, completion = value.get("prompt_tokens"), value.get("completion_tokens")
        total = (prompt + completion if all(isinstance(v, int) and not isinstance(v, bool)
                    and v >= 0 for v in (prompt, completion)) else None)
    return value, total


def phase_completion(stage: str, finish_reason: str | None,
                     *, distribution_complete: bool = False) -> str:
    """Length is expected only at a complete, separately validated score position."""
    if stage == "score_read" and distribution_complete and finish_reason in ("length", "stop"):
        return "COMPLETE_SCORE_READ"
    if finish_reason == "length":
        return "TRUNCATED"
    if finish_reason == "stop":
        return "COMPLETE"
    return "UNKNOWN"


class JournaledClient:
    def __init__(self, endpoint: str, journal_path: str | Path,
                 artifact_dir: str | Path, *,
                 allowed_endpoints=("http://127.0.0.1:8000",),
                 limits: Mapping[str, BudgetLimit], timeout: float = 60,
                 api_key: str | None = None, transport=None):
        self.endpoint = _canonical_endpoint(endpoint)
        if self.endpoint not in {_canonical_endpoint(item) for item in allowed_endpoints}:
            raise ValueError("Endpoint is not on the explicit allowlist")
        if "global" not in limits:
            raise ValueError("An explicit global budget is required")
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be positive and finite")
        self.limits = dict(limits)
        self.timeout = timeout
        self.api_key = api_key
        self.journal_path = Path(journal_path).resolve()
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        self.artifact_dir = Path(artifact_dir).resolve()
        self.artifact_dir.mkdir(parents=True, exist_ok=True)
        # ProxyHandler({}) avoids ambient proxy credentials and proxy routing.
        self._transport = transport or urllib.request.build_opener(
            urllib.request.ProxyHandler({}), _NoRedirect()).open
        with closing(self._connect()) as db, db:
            db.executescript("""
              CREATE TABLE IF NOT EXISTS requests (
                request_id TEXT PRIMARY KEY, method TEXT NOT NULL, endpoint TEXT NOT NULL,
                path TEXT NOT NULL, stage TEXT NOT NULL, qid TEXT NOT NULL,
                candidate_id TEXT NOT NULL, request_sha256 TEXT NOT NULL,
                reserved_at REAL NOT NULL, finished_at REAL, status TEXT NOT NULL,
                prompt_tokens_estimate INTEGER NOT NULL, max_output_tokens INTEGER NOT NULL,
                reserved_tokens INTEGER NOT NULL, actual_total_tokens INTEGER,
                http_status INTEGER, finish_reason TEXT, usage_json TEXT,
                request_file TEXT, response_file TEXT, error TEXT,
                elapsed_seconds REAL, response_sha256 TEXT);
              CREATE TABLE IF NOT EXISTS request_scopes (
                request_id TEXT NOT NULL, scope TEXT NOT NULL,
                PRIMARY KEY (request_id,scope));
              CREATE INDEX IF NOT EXISTS scope_lookup ON request_scopes(scope);
            """)
            columns = {row[1] for row in db.execute("PRAGMA table_info(requests)")}
            for name in ("transport_attempted_at", "response_received_at", "response_complete_at"):
                if name not in columns:
                    db.execute(f"ALTER TABLE requests ADD COLUMN {name} REAL")

    def _connect(self):
        db = sqlite3.connect(str(self.journal_path), timeout=30)
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=FULL")
        return db

    def _scopes(self, stage, qid, candidate_id):
        return ("global", f"stage:{stage}", f"qid:{qid}",
                f"candidate:{qid}:{candidate_id}")

    def _reserve(self, identity, method, path, stage, qid, candidate_id,
                 digest, prompt_tokens, max_output_tokens, request_file, response_file):
        now = time.time()
        scopes = self._scopes(stage, qid, candidate_id)
        token_reserve = prompt_tokens + max_output_tokens
        timeout = self.timeout
        db = self._connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            if db.execute("SELECT 1 FROM requests WHERE request_id=?", (identity,)).fetchone():
                raise DuplicateRequestError(f"Request identity already reserved; never resend: {identity}")
            for scope in scopes:
                limit = self.limits.get(scope)
                if limit is None:
                    continue
                count, tokens, first = db.execute("""
                    SELECT COUNT(*), COALESCE(SUM(MAX(r.reserved_tokens,
                      COALESCE(r.actual_total_tokens,0))),0), MIN(r.reserved_at)
                    FROM requests r JOIN request_scopes s USING(request_id)
                    WHERE s.scope=?""", (scope,)).fetchone()
                elapsed = max(0.0, now - first) if first is not None else 0.0
                if count + 1 > limit.max_requests:
                    raise BudgetExceeded(f"HTTP request budget exhausted for {scope}")
                if tokens + token_reserve > limit.max_tokens:
                    raise BudgetExceeded(f"Token reservation budget exhausted for {scope}")
                remaining = limit.max_seconds - elapsed
                if remaining <= 0:
                    raise BudgetExceeded(f"Elapsed-time budget exhausted for {scope}")
                timeout = min(timeout, remaining)
            db.execute("""INSERT INTO requests
                (request_id,method,endpoint,path,stage,qid,candidate_id,request_sha256,
                 reserved_at,status,prompt_tokens_estimate,max_output_tokens,reserved_tokens,
                 request_file,response_file) VALUES (?,?,?,?,?,?,?,?,?,'RESERVED',?,?,?,?,?)""",
                (identity, method, self.endpoint, path, stage, qid, candidate_id, digest,
                 now, prompt_tokens, max_output_tokens, token_reserve,
                 str(request_file), str(response_file)))
            db.executemany("INSERT INTO request_scopes VALUES (?,?)",
                           [(identity, scope) for scope in scopes])
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()
        return timeout, token_reserve

    def _finish(self, record):
        with closing(self._connect()) as db, db:
            db.execute("""UPDATE requests SET finished_at=?, status=?,actual_total_tokens=?,
                http_status=?,finish_reason=?,usage_json=?,error=?,elapsed_seconds=?,
                response_sha256=? WHERE request_id=?""",
                (time.time(), record.status, record.actual_total_tokens, record.http_status,
                 record.finish_reason, json.dumps(record.usage) if record.usage is not None else None,
                 record.error, record.elapsed_seconds, record.raw_response_sha256, record.request_id))

    def _mark_transport(self, identity, column):
        if column not in ("transport_attempted_at", "response_received_at", "response_complete_at"):
            raise ValueError("Invalid transport event")
        with closing(self._connect()) as db, db:
            db.execute(f"UPDATE requests SET {column}=? WHERE request_id=?", (time.time(), identity))

    def post(self, path, payload, *, request_id, stage, qid, candidate_id, prompt_tokens):
        return self.request("POST", path, payload, request_id=request_id, stage=stage,
                            qid=qid, candidate_id=candidate_id, prompt_tokens=prompt_tokens)

    def get(self, path, *, request_id, stage="capability", qid="probe",
            candidate_id="metadata", prompt_tokens=0):
        return self.request("GET", path, None, request_id=request_id, stage=stage,
                            qid=qid, candidate_id=candidate_id, prompt_tokens=prompt_tokens)

    def request(self, method, path, payload, *, request_id, stage, qid, candidate_id,
                prompt_tokens):
        if method not in ("GET", "POST"):
            raise ValueError("Only explicit GET/POST requests are supported")
        if (not isinstance(path, str) or not path.startswith("/") or path.startswith("//")
                or urllib.parse.urlsplit(path).scheme or "?" in path or "#" in path
                or any(part == ".." for part in path.split("/"))):
            raise ValueError("Invalid endpoint-relative request path")
        if not all(isinstance(v, str) and v for v in (request_id, stage, qid, candidate_id)):
            raise ValueError("Explicit nonempty identity, stage, qid and candidate_id required")
        if isinstance(prompt_tokens, bool) or not isinstance(prompt_tokens, int) or prompt_tokens < 0:
            raise ValueError("Exact nonnegative prompt-token reservation required")
        if method == "POST":
            if not isinstance(payload, dict):
                raise ValueError("POST payload must be a JSON object")
            if payload.get("stream"):
                raise ValueError("Streaming is not supported by the audit client")
            if "max_tokens" in payload and "max_completion_tokens" in payload:
                raise ValueError("Use one output-token cap field, never both")
            if path == "/v1/completions":
                prompt = payload.get("prompt")
                single_ids = (isinstance(prompt, list) and bool(prompt) and
                    all(isinstance(tid, int) and not isinstance(tid, bool) and tid >= 0 for tid in prompt))
                if not isinstance(prompt, str) and not single_ids:
                    raise ValueError("Completion prompt must be one string or one list of integer IDs; batches are forbidden")
            maximum = payload.get("max_tokens", payload.get("max_completion_tokens"))
            if (isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < 1):
                raise ValueError("POST must specify a finite positive output-token cap")
            if any(isinstance(payload.get(key, 1), bool) or payload.get(key, 1) != 1
                   for key in ("n", "best_of")):
                raise ValueError("Only n=1 and best_of=1 are budgeted")
            body = _json_bytes(payload)
        else:
            if payload is not None:
                raise ValueError("GET must not have a payload")
            maximum, body = 0, b""
        envelope = {"method": method, "endpoint": self.endpoint, "path": path,
                    "payload": payload, "stage": stage, "qid": qid,
                    "candidate_id": candidate_id, "prompt_tokens": prompt_tokens}
        envelope_bytes = _json_bytes(envelope)
        digest = hashlib.sha256(envelope_bytes).hexdigest()
        stem = hashlib.sha256(request_id.encode()).hexdigest()
        request_file = self.artifact_dir / f"{stem}.request.json"
        response_file = self.artifact_dir / f"{stem}.response.bin"
        timeout, token_reserve = self._reserve(request_id, method, path, stage, qid,
            candidate_id, digest, prompt_tokens, maximum, request_file, response_file)
        record = HTTPRecord(request_id, "RESERVED", request_path=str(request_file),
                            request_sha256=digest, reserved_tokens=token_reserve)
        start = time.monotonic()
        try:
            _write_new(request_file, envelope_bytes)
            headers = {"Content-Type": "application/json", "Accept": "application/json"}
            if self.api_key:
                headers["Authorization"] = "Bearer " + self.api_key
            request = urllib.request.Request(self.endpoint + path,
                data=body if method == "POST" else None, headers=headers, method=method)
            # A process can crash between this durable marker and the actual call.
            # Without a response this is an UNKNOWN network outcome, not proof of POST.
            self._mark_transport(request_id, "transport_attempted_at")
            record.transport_attempted = True
            try:
                with self._transport(request, timeout=timeout) as response:
                    record.http_status = response.status
                    self._mark_transport(request_id, "response_received_at")
                    record.response_received = True
                    raw = response.read()
            except urllib.error.HTTPError as exc:
                record.http_status = exc.code
                self._mark_transport(request_id, "response_received_at")
                record.response_received = True
                raw = exc.read()
            _write_new(response_file, raw)
            self._mark_transport(request_id, "response_complete_at")
            record.response_complete = True
            record.raw_response_path = str(response_file)
            record.raw_response_sha256 = hashlib.sha256(raw).hexdigest()
            if not 200 <= record.http_status < 300:
                record.status = "HTTP_ERROR"
                record.error = f"HTTP {record.http_status}; no retry"
            else:
                record.status = "OK"
            try:
                parsed = json.loads(raw.decode("utf-8")) if raw else {}
                if not isinstance(parsed, dict):
                    raise ValueError("Expected a JSON object")
                record.response = parsed
            except (ValueError, UnicodeError) as exc:
                if record.status == "OK":
                    record.status = "INVALID_RESPONSE"
                record.error = f"{record.error or ''} JSON decode: {type(exc).__name__}".strip()
            record.usage, record.actual_total_tokens = _usage(record.response)
            if record.response:
                choices = record.response.get("choices")
                if isinstance(choices, list) and choices and isinstance(choices[0], dict):
                    record.finish_reason = choices[0].get("finish_reason")
            if record.actual_total_tokens is not None and record.actual_total_tokens > token_reserve:
                record.status = "TOKEN_RESERVATION_OVERRUN"
                record.error = "Actual usage exceeded declared prompt plus output reservation"
        except Exception as exc:
            # Never serialize raw exception text: it may contain authentication data.
            record.status = "TRANSPORT_ERROR" if record.transport_attempted else "RECORDING_ERROR"
            record.error = f"{type(exc).__name__}; identity remains consumed; no retry"
        finally:
            record.elapsed_seconds = time.monotonic() - start
            if record.elapsed_seconds > timeout and record.status == "OK":
                record.status = "TIME_BUDGET_EXCEEDED"
                record.error = "Response arrived after the available time allowance"
            self._finish(record)
        return record

    def summary(self):
        with closing(self._connect()) as db, db:
            db.row_factory = sqlite3.Row
            rows = [dict(row) for row in db.execute("""SELECT request_id,method,path,stage,qid,
                candidate_id,status,reserved_tokens,actual_total_tokens,http_status,
                finish_reason,elapsed_seconds,transport_attempted_at,response_received_at,
                response_complete_at FROM requests ORDER BY reserved_at""")]
        attempted = sum(row["transport_attempted_at"] is not None for row in rows)
        received = sum(row["response_received_at"] is not None for row in rows)
        unknown = sum(row["transport_attempted_at"] is not None and row["response_received_at"] is None for row in rows)
        return {"reserved_request_identities": len(rows),
                "transport_dispatches_marked": attempted,
                "confirmed_http_responses": received,
                "complete_responses_saved": sum(row["response_complete_at"] is not None for row in rows),
                "network_outcome_unknown": unknown,
                "reserved_not_dispatched": len(rows) - attempted,
                "actual_http_count": received if unknown == 0 else None,
                "accounting_note": "Dispatch markers precede transport; missing responses leave a crash/error uncertainty window. Reserved identities are a budget upper bound, not actual HTTP calls.",
                "time_budget_enforcement": "No dispatch after scope deadline; bounded socket timeout; late responses rejected. A trickling response is not forcibly killed at an exact wall-clock deadline.",
                "reserved_tokens": sum(row["reserved_tokens"] for row in rows),
                "observed_total_tokens": sum(row["actual_total_tokens"] or 0 for row in rows),
                "usage_unknown_requests": sum(row["actual_total_tokens"] is None for row in rows),
                "requests": rows}


def logprob_items(body: Mapping[str, Any], *, protocol: str) -> list[dict[str, Any]]:
    """Read the first generated position, requiring returned token-ID strings.

    Completeness and score-position validation are deliberately separate gates.
    Extra sampled IDs remain in this list for the downstream audit record.
    """
    choices = body.get("choices")
    if not isinstance(choices, list) or len(choices) != 1:
        raise ValueError("Expected exactly one choice")
    logprobs = choices[0].get("logprobs")
    if not isinstance(logprobs, dict):
        raise ValueError("Missing logprobs")
    if protocol == "chat":
        positions = logprobs.get("content")
        if not isinstance(positions, list) or len(positions) != 1:
            raise ValueError("Expected exactly one generated logprob position")
        entries = list(positions[0].get("top_logprobs") or [])
        if positions[0].get("token") is not None:
            entries.append({"token": positions[0]["token"], "logprob": positions[0]["logprob"]})
    elif protocol == "completion":
        positions = logprobs.get("top_logprobs")
        if not isinstance(positions, list) or len(positions) != 1 or not isinstance(positions[0], dict):
            raise ValueError("Expected exactly one generated logprob position")
        entries = [{"token": token, "logprob": lp} for token, lp in positions[0].items()]
        tokens, sampled_lp = logprobs.get("tokens"), logprobs.get("token_logprobs")
        if isinstance(tokens, list) and len(tokens) == 1 and isinstance(sampled_lp, list):
            entries.append({"token": tokens[0], "logprob": sampled_lp[0]})
    else:
        raise ValueError("protocol must be chat or completion")
    unique = {}
    for entry in entries:
        token = entry.get("token")
        if not isinstance(token, str) or not token.startswith("token_id:"):
            raise ValueError("Explicit token_id: format is required")
        raw_id = token[len("token_id:"):]
        if not raw_id.isdigit():
            raise ValueError("Invalid token ID")
        tid, lp = int(raw_id), entry.get("logprob")
        if isinstance(lp, bool) or not isinstance(lp, (int, float)) or math.isnan(lp) or lp > 1e-6:
            raise ValueError("Invalid raw logprob")
        if tid in unique and unique[tid]["logprob"] != lp:
            raise ValueError("Conflicting duplicate token ID logprobs")
        unique[tid] = {"token_id": tid, "logprob": lp, "text": token}
    return list(unique.values())
