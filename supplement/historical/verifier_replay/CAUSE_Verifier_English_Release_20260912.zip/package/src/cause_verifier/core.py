"""Fail-closed CAUSE verifier protocol; no HTTP, model calls, or optional dependencies.

Scores are conditional expectations over A..T, not calibrated P(correct).
The caller must verify tokenization and the precise next-token position against
the live tokenizer/service. Transport adapters must not invent missing token IDs.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Iterable, Mapping, Sequence

LABELS = tuple("ABCDEFGHIJKLMNOPQRST")
LABEL_VALUES = {label: (19 - i) / 19 for i, label in enumerate(LABELS)}
CRITERIA = ("query_fidelity", "derivation_validity", "conclusion_support")
TRISTATES = frozenset(("pass", "fail", "unknown"))


def _jsonable(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonable(asdict(value))
    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise ValueError("JSON object keys must be strings")
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        if value == -math.inf:
            return "-Infinity"  # Explicit JSON-safe zero-probability log event.
        raise ValueError("Non-finite JSON value")
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    raise TypeError("Unsupported value for canonical JSON: " + type(value).__name__)


def canonical_json(value: Any) -> str:
    return json.dumps(_jsonable(value), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def content_hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TokenVariant:
    token_id: int
    text: str
    token_count: int = 1


@dataclass(frozen=True)
class TokenLogprob:
    token_id: int
    logprob: float
    text: str | None = None


@dataclass
class ScoreRecord:
    status: str
    error_code: str | None = None
    error_detail: str | None = None
    score: float | None = None
    discrete_score: float | None = None
    argmax_label: str | None = None
    score_mass: float | None = None
    log_score_mass: float | None = None
    labels: dict[str, dict[str, Any]] = field(default_factory=dict)
    missing_labels: list[str] = field(default_factory=list)
    missing_token_ids: list[int] = field(default_factory=list)
    token_logprobs: list[dict[str, Any]] = field(default_factory=list)
    prompt_hash: str | None = None
    score_position: int | None = None
    review_seed: int | None = None
    finish_reason: str | None = None
    stage: str = "score_read"
    source: str = "raw_logprobs"
    logprobs_mode: str = "raw_logprobs"
    usage: dict[str, Any] | None = None
    evidence_refs: list[Any] = field(default_factory=list)
    cache_key: str | None = None
    review_id: str | None = None
    read_id: str | None = None
    candidate_id: str | None = None
    candidate_hash: str | None = None
    criterion: str | None = None
    score_semantics: str = "conditional_expected_grade_not_probability_correct"

    def to_dict(self) -> dict[str, Any]:
        return _jsonable(asdict(self))


class ProtocolError(ValueError):
    def __init__(self, code: str, detail: str):
        self.code = code
        super().__init__(detail)


def stage_status(stage: str, finish_reason: str | None, *, completed: bool = True) -> str:
    """Single-token reads may end with length; unfinished reviews/rollouts cannot."""
    if stage not in ("score_read", "review", "rollout"):
        return "invalid_stage"
    if finish_reason not in ("stop", "length"):
        return "invalid_finish_reason"
    if not completed:
        return "incomplete_" + stage
    if stage != "score_read" and finish_reason == "length":
        return "truncated_" + stage
    return "valid"


def _token_id(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ProtocolError("invalid_token_id", "Token IDs must be nonnegative integers")
    return value


def _label_map(label_tokens: Mapping[str, Sequence[TokenVariant | Mapping[str, Any]]]):
    if set(label_tokens) != set(LABELS):
        raise ProtocolError("invalid_label_set", "Exactly all 20 labels A..T are required")
    by_label: dict[str, list[int]] = {}
    owners: dict[int, str] = {}
    texts: dict[int, str] = {}
    for label in LABELS:
        variants = label_tokens[label]
        if not variants:
            raise ProtocolError("unreachable_label", "No token variant for " + label)
        by_label[label] = []
        for item in variants:
            variant = item if isinstance(item, TokenVariant) else TokenVariant(**item)
            token_id = _token_id(variant.token_id)
            if variant.token_count != 1 or isinstance(variant.token_count, bool):
                raise ProtocolError("multi_token_label", "Only single-next-token events are supported")
            if not isinstance(variant.text, str) or not variant.text.strip():
                raise ProtocolError("blank_label_token", "Whitespace alone is not a grade")
            if variant.text.strip() != label:
                raise ProtocolError("label_text_mismatch", "Token text does not represent its grade")
            if token_id in owners and owners[token_id] != label:
                raise ProtocolError("cross_label_token_conflict", "One token ID cannot represent two grades")
            if token_id in texts and texts[token_id] != variant.text:
                raise ProtocolError("inconsistent_token_text", "One token ID has inconsistent decoded text")
            if token_id not in owners:
                by_label[label].append(token_id)
                owners[token_id], texts[token_id] = label, variant.text
    return by_label, owners, texts


def _logsumexp(values: Iterable[float]) -> float:
    values = tuple(values)
    largest = max(values)
    if largest == -math.inf:
        return -math.inf
    return largest + math.log(math.fsum(math.exp(item - largest) for item in values))


def score_distribution(
    label_tokens: Mapping[str, Sequence[TokenVariant | Mapping[str, Any]]],
    observed_logprobs: Sequence[TokenLogprob | Mapping[str, Any]] | None,
    *, prompt_hash: str | None, score_position: int | None,
    position_verified: bool = False, tokenization_verified: bool = False,
    observed_score_position: int | None = None, stage: str = "score_read",
    finish_reason: str | None = "length", completed: bool = True,
    source: str = "raw_logprobs", logprobs_mode: str = "raw_logprobs",
    distribution_complete: bool = True, review_seed: int | None = None,
    usage: Mapping[str, Any] | None = None, evidence_refs: Sequence[Any] = (),
    review_id: str | None = None, read_id: str | None = None,
    candidate_id: str | None = None, candidate_hash: str | None = None, criterion: str | None = None,
    probability_tolerance: float = 1e-6,
) -> ScoreRecord:
    """Return VALID only for the verified, complete raw grade-token distribution.

    Duplicate IDs are deduplicated, same-grade variants are SUMMED, and different
    grades may never own the same ID. Extra raw vocabulary tokens are allowed but
    never enter the grade expectation. Missing *any variant* invalidates the read.
    A genuine complete uniform distribution has a valid score of 0.5.
    """
    record = ScoreRecord(status="INVALID", prompt_hash=prompt_hash,
                         score_position=score_position, stage=stage,
                         finish_reason=finish_reason, source=source,
                         logprobs_mode=logprobs_mode, review_seed=review_seed,
                         usage=dict(usage) if usage is not None else None,
                         evidence_refs=list(evidence_refs), review_id=review_id,
                         read_id=read_id, candidate_id=candidate_id, candidate_hash=candidate_hash, criterion=criterion)
    try:
        if source != "raw_logprobs" or logprobs_mode != "raw_logprobs":
            raise ProtocolError("non_raw_or_fallback_source", "Text, fallback, processed or approximate scores are not exact main results")
        phase = stage_status(stage, finish_reason, completed=completed)
        if phase != "valid":
            raise ProtocolError(phase, "Request did not finish successfully in its phase")
        if stage != "score_read":
            raise ProtocolError("not_score_read", "Extract distributions only from the separate fixed-position read")
        if not isinstance(prompt_hash, str) or not prompt_hash:
            raise ProtocolError("missing_prompt_hash", "Frozen score prompt hash is required")
        if (isinstance(score_position, bool) or not isinstance(score_position, int)
                or score_position < 0 or not position_verified):
            raise ProtocolError("unverified_score_position", "The exact scoring position must be independently located")
        if observed_score_position is not None and observed_score_position != score_position:
            raise ProtocolError("wrong_score_position", "Logprobs belong to a different token position")
        if not tokenization_verified:
            raise ProtocolError("unverified_tokenization", "Verify single-token reachability under the actual fixed prefix")
        if not isinstance(probability_tolerance, (float, int)) or not math.isfinite(probability_tolerance) or not 0 <= probability_tolerance <= 1e-3:
            raise ProtocolError("invalid_probability_tolerance", "Probability tolerance must be predeclared and at most 1e-3")
        by_label, owners, texts = _label_map(label_tokens)
        if not observed_logprobs:
            raise ProtocolError("missing_logprobs", "No token logprobs returned")
        observed: dict[int, float] = {}
        for item in observed_logprobs:
            event = item if isinstance(item, TokenLogprob) else TokenLogprob(**item)
            token_id = _token_id(event.token_id)
            if isinstance(event.logprob, bool) or not isinstance(event.logprob, (int, float)):
                raise ProtocolError("invalid_logprob", "Logprob must be a number")
            lp = float(event.logprob)
            if math.isnan(lp) or lp == math.inf or lp > 0:
                raise ProtocolError("invalid_logprob", "Logprob must be <= 0, allowing -Infinity for zero probability")
            if event.text is not None:
                if not isinstance(event.text, str) or (token_id in owners and not event.text.strip()):
                    raise ProtocolError("blank_score_token", "Score token is blank or malformed")
                if token_id in texts and event.text != texts[token_id]:
                    raise ProtocolError("observed_token_text_mismatch", "Observed score token text differs from verified tokenizer")
            if token_id in observed and observed[token_id] != lp:
                raise ProtocolError("conflicting_duplicate_logprob", "Repeated token ID has different logprobs")
            observed[token_id] = lp
        record.token_logprobs = [{"token_id": token_id, "logprob": lp,
                                 "label": owners.get(token_id)}
                                for token_id, lp in sorted(observed.items())]
        record.missing_token_ids = sorted(set(owners) - set(observed))
        record.missing_labels = [label for label in LABELS
                                 if any(tid not in observed for tid in by_label[label])]
        if record.missing_token_ids or not distribution_complete:
            raise ProtocolError("incomplete_distribution", "Every unique grade token ID must be returned; top-k count is insufficient")
        if _logsumexp(observed.values()) > math.log1p(probability_tolerance):
            raise ProtocolError("probability_mass_exceeds_one", "Returned raw token events are not a probability distribution")
        label_lps = {label: _logsumexp(observed[tid] for tid in by_label[label])
                     for label in LABELS}
        log_mass = _logsumexp(label_lps.values())
        if log_mass == -math.inf:
            raise ProtocolError("zero_score_mass", "All grade tokens have zero probability")
        record.log_score_mass, record.score_mass = log_mass, math.exp(log_mass)
        for label in LABELS:
            lp = label_lps[label]
            record.labels[label] = {"token_ids": by_label[label], "logprob": lp,
                                    "probability": math.exp(lp),
                                    "conditional_probability": math.exp(lp - log_mass),
                                    "value": LABEL_VALUES[label]}
        record.score = math.fsum(record.labels[label]["conditional_probability"] * LABEL_VALUES[label]
                                 for label in LABELS)
        record.argmax_label = max(LABELS, key=lambda label: label_lps[label])
        record.discrete_score = LABEL_VALUES[record.argmax_label]
        record.status = "VALID"
    except ProtocolError as exc:
        record.error_code, record.error_detail = exc.code, str(exc)
    except (TypeError, ValueError, KeyError, OverflowError) as exc:
        record.error_code, record.error_detail = "malformed_score_data", str(exc)
    return record


CACHE_REQUIRED_FIELDS = (
    "model_id", "model_revision", "tokenizer_hash", "template_hash", "task",
    "candidate", "evidence", "criteria_version", "criterion", "scoring_mode",
    "review_seed", "sampling_parameters", "score_prompt_hash", "label_map_hash",
)


def build_cache_key(context: Mapping[str, Any]) -> str:
    """Hash all supplied fields, including required model/prompt/protocol identities.

    Use a locally derived immutable weight/file-manifest hash if a model has no
    revision ID. Unknown/missing model revisions cannot identify cache entries.
    """
    missing = [key for key in CACHE_REQUIRED_FIELDS if key not in context]
    if missing:
        raise ValueError("Cache identity missing fields: " + ", ".join(missing))
    identity_fields = ("model_id", "model_revision", "tokenizer_hash", "template_hash",
                       "criteria_version", "criterion", "scoring_mode", "score_prompt_hash", "label_map_hash")
    if any(not isinstance(context[key], str) or not context[key].strip()
           or context[key].lower() in ("unknown", "none", "null") for key in identity_fields):
        raise ValueError("Cache identity contains unknown or empty identity fields")
    if not isinstance(context["sampling_parameters"], Mapping):
        raise ValueError("sampling_parameters must include the actual review/read configurations")
    if isinstance(context["review_seed"], bool) or not isinstance(context["review_seed"], int):
        raise ValueError("review_seed must be the frozen integer seed")
    return "cause-verifier-v1:" + content_hash(dict(context))


def score_rollout(task: Any, rollout: Any, rubric: Mapping[str, Any],
                  evidence: Sequence[Any], config: Mapping[str, Any]) -> ScoreRecord:
    """Offline adapter: consume config['score_read'], with no implicit network IO.

    score_read contains score_distribution kwargs, including label_tokens and
    observed_logprobs. Optional cache_context supplies immutable environment
    identities; task/candidate/evidence/criterion are forcibly bound to arguments.
    """
    read = dict(config.get("score_read") or {})
    read["evidence_refs"] = list(evidence)
    read["criterion"] = rubric.get("id")
    read["candidate_hash"] = content_hash(rollout)
    if rubric.get("id") not in CRITERIA:
        return ScoreRecord("INVALID", error_code="invalid_criterion", error_detail="A causal criterion is required")
    read.setdefault("label_tokens", {})
    read.setdefault("observed_logprobs", None)
    read.setdefault("prompt_hash", None)
    read.setdefault("score_position", None)
    try:
        record = score_distribution(**read)
        if config.get("cache_context") is not None:
            identity = dict(config["cache_context"])
            identity.update(task=task, candidate=rollout, evidence=list(evidence),
                            criterion=rubric["id"], criteria_version=rubric["version"],
                            score_prompt_hash=record.prompt_hash,
                            label_map_hash=content_hash(read["label_tokens"]),
                            review_seed=read.get("review_seed"))
            record.cache_key = build_cache_key(identity)
        return record
    except (TypeError, ValueError, KeyError) as exc:
        return ScoreRecord("INVALID", error_code="malformed_adapter_config", error_detail=str(exc))


@dataclass(frozen=True)
class HardCheck:
    name: str
    status: str
    evidence_refs: tuple[Any, ...] = ()
    detail: str = ""

    def __post_init__(self):
        if self.status not in TRISTATES:
            raise ValueError("Hard-check status must be pass/fail/unknown")
        if self.status in ("pass", "fail") and not self.evidence_refs:
            raise ValueError("Definitive hard checks require independently collected evidence references")


@dataclass
class VerificationRecord:
    hard_checks: list[HardCheck]
    criterion_scores: dict[str, ScoreRecord]
    status: str
    evidence_refs: list[Any]
    reason: str
    candidate_id: str | None = None
    candidate_hash: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return _jsonable(asdict(self))


def verify_rollout(criterion_scores: Mapping[str, ScoreRecord],
                   hard_checks: Sequence[HardCheck] = (), *,
                   task_information_sufficient: bool = False,
                   rollout_finish_reason: str | None = "stop",
                   rollout_completed: bool = True,
                   evidence_refs: Sequence[Any] = ()) -> VerificationRecord:
    """A hard counterexample dominates model scores. Never average criteria.

    'pass' means checks and interface passed, not objective truth or acceptance;
    quality thresholds remain a separately calibrated candidate-selection gate.
    """
    scores, checks = dict(criterion_scores), list(hard_checks)
    candidate_ids = {item.candidate_id for item in scores.values()}
    candidate_hashes = {item.candidate_hash for item in scores.values()}
    binding_valid = (len(candidate_ids) == 1 and None not in candidate_ids and "" not in candidate_ids
                     and len(candidate_hashes) == 1 and None not in candidate_hashes
                     and all(isinstance(value, str) and len(value) == 64
                             and all(char in "0123456789abcdef" for char in value)
                             for value in candidate_hashes)
                     and all(item.criterion == key for key, item in scores.items()))
    refs = list(evidence_refs)
    for check in checks:
        refs.extend(check.evidence_refs)
    if any(check.status == "fail" for check in checks):
        status, reason = "fail", "Executable/independent hard counterexample"
    elif stage_status("rollout", rollout_finish_reason, completed=rollout_completed) != "valid":
        status, reason = "unknown", "Rollout incomplete, truncated, or invalid"
    elif not task_information_sufficient:
        status, reason = "unknown", "Insufficient original-task information; no assumptions invented"
    elif set(scores) != set(CRITERIA) or any(item.status != "VALID" for item in scores.values()):
        status, reason = "unknown", "Missing or invalid criterion distribution"
    elif not binding_valid:
        status, reason = "unknown", "Criterion scores are not bound to one identical candidate and its full-text hash"
    elif not checks or any(check.status == "unknown" for check in checks):
        status, reason = "unknown", "Hard checks absent or unresolved"
    else:
        status, reason = "pass", "Required interfaces and independent hard checks passed; quality uncalibrated here"
    return VerificationRecord(checks, scores, status, refs, reason,
                              next(iter(candidate_ids)) if binding_valid else None,
                              next(iter(candidate_hashes)) if binding_valid else None)


@dataclass(frozen=True)
class CalibrationGate:
    thresholds: Mapping[str, float]
    calibration_id: str
    independent_labels: bool
    question_disjoint: bool
    artifact_hash: str
    evidence_refs: tuple[Any, ...]

    def validate(self):
        if not (self.calibration_id and self.artifact_hash and self.evidence_refs
                and self.independent_labels and self.question_disjoint):
            raise ValueError("Acceptance requires independently labeled calibration, disjoint by question, and an auditable artifact")
        if set(self.thresholds) != set(CRITERIA):
            raise ValueError("Separate calibrated thresholds required for all three criteria")
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
               or not 0 <= v <= 1 for v in self.thresholds.values()):
            raise ValueError("Invalid calibrated criterion threshold")


@dataclass
class Candidate:
    candidate_id: str
    rollout: Any
    verification: VerificationRecord
    objective_value: float


@dataclass
class SelectionDecision:
    mode: str
    selected_id: str
    selected_rollout: Any
    recommended_id: str | None
    accepted: bool
    status: str
    reason: str
    eligible_ids: list[str] = field(default_factory=list)
    rejected: dict[str, str] = field(default_factory=dict)
    calibration_id: str | None = None

    def to_dict(self):
        return _jsonable(asdict(self))


def choose_candidate(parent_id: str, parent_rollout: Any, candidates: Sequence[Candidate],
                     *, mode: str = "shadow", calibration: CalibrationGate | None = None,
                     maximize_objective: bool = True, budget_exhausted: bool = False,
                     exception: str | None = None) -> SelectionDecision:
    """Preserve the exact parent unless explicitly enabled calibrated acceptance.

    Quality gates are applied criterion by criterion before the caller's existing
    optimization objective; there is no hidden shortest-chain objective. Uncalibrated
    shadow runs record scores but cannot label any candidate acceptance-qualified.
    """
    result = SelectionDecision(mode, parent_id, parent_rollout, None, False, "retained_parent", "")
    if mode not in ("shadow", "acceptance"):
        result.reason = "Invalid selection mode"
        return result
    if budget_exhausted or exception:
        result.reason = "Budget exhausted" if budget_exhausted else "Exception: " + str(exception)
        return result
    if calibration is None:
        result.reason = "Independent calibration unavailable; acceptance remains disabled"
        return result
    try:
        calibration.validate()
    except ValueError as exc:
        result.reason = str(exc)
        return result
    result.calibration_id = calibration.calibration_id
    if len({item.candidate_id for item in candidates}) != len(candidates):
        result.reason = "Duplicate candidate IDs are ambiguous"
        return result
    eligible = []
    for candidate in candidates:
        why = None
        verification = candidate.verification
        if candidate.candidate_id == parent_id:
            why = "Parent is not an intervention candidate"
        elif (verification.candidate_id != candidate.candidate_id
              or verification.candidate_hash != content_hash(candidate.rollout)
              or any(score.candidate_id != candidate.candidate_id
                     or score.candidate_hash != content_hash(candidate.rollout)
                     or score.criterion != key
                     for key, score in verification.criterion_scores.items())):
            why = "Candidate ID, full-text hash or criterion binding differs from the scored trajectory"
        elif verification.status != "pass":
            why = "Hard checks or interface unresolved/failed"
        elif (isinstance(candidate.objective_value, bool)
              or not isinstance(candidate.objective_value, (int, float))
              or not math.isfinite(candidate.objective_value)):
            why = "Invalid optimization objective"
        elif set(verification.criterion_scores) != set(CRITERIA):
            why = "Missing criteria"
        elif any(score.status != "VALID" or score.score is None or not math.isfinite(score.score)
                 or score.score < calibration.thresholds[criterion]
                 for criterion, score in verification.criterion_scores.items()):
            why = "At least one separate criterion quality gate failed"
        if why:
            result.rejected[candidate.candidate_id] = why
        else:
            eligible.append(candidate)
    result.eligible_ids = [item.candidate_id for item in eligible]
    if not eligible:
        result.reason = "No candidate passed all quality gates"
        return result
    # Stable input order breaks objective ties; criterion scores are not averaged.
    winner = (max if maximize_objective else min)(eligible, key=lambda item: item.objective_value)
    result.recommended_id = winner.candidate_id
    if mode == "shadow":
        result.reason = "Shadow recommendation recorded; existing decision remains unchanged"
    else:
        result.selected_id, result.selected_rollout = winner.candidate_id, winner.rollout
        result.accepted, result.status = True, "accepted"
        result.reason = "All calibrated quality gates passed, then existing objective ranked candidates"
    return result


def build_pairwise_orders(candidate_a_id: str, candidate_b_id: str) -> list[dict[str, str]]:
    if not candidate_a_id or not candidate_b_id or candidate_a_id == candidate_b_id:
        raise ValueError("Pairwise candidates require distinct nonempty IDs")
    return [{"order": "AB", "A": candidate_a_id, "B": candidate_b_id},
            {"order": "BA", "A": candidate_b_id, "B": candidate_a_id}]


def remap_pairwise_result(order: Mapping[str, str], slot_results: Mapping[str, Any]) -> dict[str, Any]:
    if order.get("order") not in ("AB", "BA") or set(slot_results) != {"A", "B"}:
        raise ValueError("Explicit AB/BA order and both slot results are required")
    if not order.get("A") or not order.get("B") or order["A"] == order["B"]:
        raise ValueError("Ambiguous candidate identities")
    return {"order": order["order"], "slot_to_candidate": {"A": order["A"], "B": order["B"]},
            "candidate_results": {order["A"]: slot_results["A"], order["B"]: slot_results["B"]}}


def count_independent_reviews(records: Sequence[ScoreRecord]) -> int:
    """Rereads of one frozen review never create additional K votes."""
    keys = set()
    for record in records:
        if not record.review_id or record.review_seed is None or not record.candidate_id or not record.criterion:
            raise ValueError("Independent-review counting requires review ID, seed, candidate ID and criterion")
        keys.add((record.candidate_id, record.criterion, record.review_id, record.review_seed))
    return len(keys)


def check_raw_score_stability(records: Sequence[ScoreRecord], *, tolerance: float) -> dict[str, Any]:
    """Diagnose reread stability; never turns rereads into independent evidence."""
    if not records or not math.isfinite(tolerance) or tolerance < 0:
        raise ValueError("Nonempty reads and a predeclared nonnegative tolerance required")
    if any(record.status != "VALID" or record.logprobs_mode != "raw_logprobs" for record in records):
        return {"status": "unknown", "reason": "Invalid/non-raw read", "independent_votes": 0}
    if len({record.prompt_hash for record in records}) != 1:
        return {"status": "unknown", "reason": "Score prefixes differ", "independent_votes": 0}
    spread = max(record.score for record in records) - min(record.score for record in records)
    return {"status": "pass" if spread <= tolerance else "fail", "score_spread": spread,
            "tolerance": tolerance, "independent_votes": 0,
            "reason": "Numerical reread diagnostic only"}


class RolloutLedger:
    """In-memory count helper. Caller persists EVERY raw row, including failures.

    Sampling identity is never content deduplication. Cache hits are validation
    reuse, not additional model rollouts or independent reviews.
    """
    def __init__(self):
        self.rows: list[dict[str, Any]] = []
        self._sample_ids: set[str] = set()

    def append(self, row: Mapping[str, Any]):
        required = {"sample_id", "decision_group_id", "condition", "rollout", "status", "cache_hit"}
        if not required <= set(row):
            raise ValueError("Raw rollout row lacks required accounting fields")
        if row["sample_id"] in self._sample_ids:
            raise ValueError("Duplicate sample identity; repeated content must use its actual distinct sample ID")
        if not isinstance(row["cache_hit"], bool):
            raise ValueError("cache_hit must be boolean")
        self._sample_ids.add(row["sample_id"])
        self.rows.append(dict(row))

    def counts(self) -> list[dict[str, Any]]:
        groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for row in self.rows:
            groups.setdefault((row["decision_group_id"], row["condition"]), []).append(row)
        return [{"decision_group_id": group, "condition": condition,
                 "raw_rollouts": len(rows), "unique_contents": len({content_hash(row["rollout"]) for row in rows}),
                 "validation_cache_hits": sum(row["cache_hit"] for row in rows),
                 "statuses": dict(Counter(row["status"] for row in rows))}
                for (group, condition), rows in groups.items()]
