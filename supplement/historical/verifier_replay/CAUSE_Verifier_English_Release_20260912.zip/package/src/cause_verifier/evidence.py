"""Trusted fixed toy SCM enumeration, never an evaluator for arbitrary tasks."""
from datetime import datetime, timezone
from fractions import Fraction
from uuid import uuid4

from .core import content_hash


def run_toy_confounding_check():
    inputs = {"checker": "fixed_binary_confounding_v1", "U": "Bernoulli(1/2)",
              "X": "U", "Y": "max(X,U)", "observational_condition": {"X": 0},
              "intervention": {"X": 0}, "event": {"Y": 1}}
    observational_mass = Fraction(0)
    observational_event_mass = Fraction(0)
    interventional_event_mass = Fraction(0)
    worlds = []
    for u in (0, 1):
        weight = Fraction(1, 2)
        x = u
        factual_y = max(x, u)
        intervention_y = max(0, u)
        if x == 0:
            observational_mass += weight
            observational_event_mass += weight * int(factual_y == 1)
        interventional_event_mass += weight * int(intervention_y == 1)
        worlds.append({"U": u, "weight": str(weight), "X": x,
                       "Y": factual_y, "Y_do_X0": intervention_y})
    observation = observational_event_mass / observational_mass
    result = {"worlds": worlds, "P_Y1_given_X0": str(observation),
              "P_Y1_do_X0": str(interventional_event_mass),
              "observational_equals_interventional": observation == interventional_event_mass}
    return {"tool_run_id": "toy-scm-" + str(uuid4()),
            "run_at_utc": datetime.now(timezone.utc).isoformat(),
            "input_hash": content_hash(inputs), "result_hash": content_hash(result),
            "inputs": inputs, "result": result,
            "status": "pass" if observation == 0 and interventional_event_mass == Fraction(1, 2) else "fail",
            "scope": "synthetic_fixed_tool_test_not_original_project_question_evidence",
            "checks_object": "The supplied toy SCM only; never inferred as a source task SCM"}
