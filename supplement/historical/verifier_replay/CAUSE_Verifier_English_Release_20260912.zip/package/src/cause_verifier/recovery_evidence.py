"""Post-hoc trusted format/provenance checks and conservative recovery records.

This sidecar may read parent/target/condition metadata. It must never be passed
to the blinded reviewer. Text overlap is not evidence of semantic recovery.
No candidate code, model, network, or hidden SCM is executed or inferred.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict
import json
import re
from typing import Any, Mapping, Sequence

from .core import HardCheck, content_hash

RECOVERY_CLASSES = (
    "target_operation_not_reconstructed",
    "same_semantic_operation_reconstructed",
    "legal_alternative_derivation",
    "failed_or_unknown",
)
KNOWN_CONDITIONS = frozenset(("keep", "delete", "replace"))


def check_replacement_generator(item: Mapping[str, Any], target: Mapping[str, Any],
                                generator: Mapping[str, Any] | None,
                                frozen_prefix: str) -> dict[str, Any]:
    if generator is None:
        return {"status": "unknown", "reason": "No original replacement-generator request was supplied"}
    try:
        body = json.loads(generator["request_json"])
        messages = body["messages"]
        allowed_fields = {"model", "messages", "chat_template_kwargs", "max_tokens", "temperature", "top_p", "top_k",
                          "min_p", "repetition_penalty", "presence_penalty", "frequency_penalty", "seed", "n", "stream",
                          "ignore_eos", "include_stop_str_in_output", "return_token_ids"}
        expected = {"task": "Generate exactly one alternative local reasoning step. Do not solve the whole problem and do not state a final yes/no answer.",
                    "question_messages": [{"role": m["role"], "content": m["content"]} for m in item["messages"]],
                    "prior_reasoning_prefix": item["parent_reasoning"][:target["char_start"]],
                    "original_step": target["text"], "output_contract": "Return only the replacement step text."}
        boundary_ok = (not set(body) - allowed_fields and len(messages) == 2
            and messages[0] == {"role": "system", "content": "You rewrite one local reasoning step using only the supplied question, prior prefix, and original step."}
            and set(messages[1]) == {"role", "content"} and messages[1]["role"] == "user"
            and json.loads(messages[1]["content"], object_pairs_hook=_no_duplicate_object) == expected)
        identity_ok = (generator["qid"] == item["question_id"] and generator["step_index"] == target["step_index"]
                       and generator["branch"] == "replacement_generate" and generator["rollout"] == 0)
        completed = (generator["state"] == "completed" and generator.get("valid") in (True, 1)
                     and generator.get("finish_reason") == "stop")
        replacement = generator.get("replacement_text")
        delimiter_match = re.search(r"(\r?\n[ \t]*\r?\n)$", target["text"])
        delimiter = delimiter_match.group(1) if delimiter_match else "\n\n"
        prefix_matches = (isinstance(replacement, str) and bool(replacement.strip())
            and frozen_prefix == item["parent_reasoning"][:target["char_start"]] + replacement.rstrip() + delimiter)
        passed = boundary_ok and identity_ok and completed and prefix_matches
        return {"status": "pass" if passed else "fail", "generator_request_key": generator.get("request_key"),
            "allowed_question_prior_prefix_original_step_only": boundary_ok, "original_generator_identity_matches": identity_ok,
            "original_generator_completed": completed, "frozen_prefix_matches_generator_output": prefix_matches,
            "reason": "Original generator input contains exactly the permitted question/prior-prefix/target fields, and its one saved output reconstructs the frozen REPLACE prefix" if passed
                      else "Original replacement generation does not match the fixed identity, allowed input boundary, completed state or frozen output"}
    except (ValueError, TypeError, KeyError, IndexError):
        return {"status": "fail", "reason": "Original replacement-generator evidence is malformed"}


def _evidence(run_id: str, candidate_id: str, checker: str, inputs: Any,
              result: Mapping[str, Any], checked_object: str) -> dict[str, Any]:
    tool_id = run_id + ":" + candidate_id + ":" + checker
    return {"tool_run_id": tool_id, "checker": checker, "checker_version": "recovery-evidence-v1",
            "input_hash": content_hash(inputs), "result_hash": content_hash(dict(result)),
            "checked_object": checked_object, "checks_object": checked_object,
            "input": inputs, "result": dict(result), "allowed_online": False,
            "scope": "independent_posthoc_sidecar_never_blind_review_prompt"}


def _no_duplicate_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("duplicate_json_key")
        value[key] = item
    return value


def check_answer_format(messages: Sequence[Mapping[str, Any]], final_content: Any) -> dict[str, Any]:
    """Check only the explicit frozen yes/no JSON shape, never answer truth."""
    system = "\n".join(str(m.get("content", "")) for m in messages if m.get("role") == "system")
    if '{"answer":"yes"}' not in system or '{"answer":"no"}' not in system:
        return {"status": "unknown", "reason": "The frozen task does not explicitly declare the supported yes/no JSON schema"}
    if not isinstance(final_content, str) or not final_content.strip():
        return {"status": "fail", "reason": "Missing textual final answer under the frozen JSON contract"}
    try:
        parsed = json.loads(final_content, object_pairs_hook=_no_duplicate_object)
    except (ValueError, TypeError):
        return {"status": "fail", "reason": "Final content is not one unambiguous JSON object"}
    if not isinstance(parsed, dict) or set(parsed) != {"answer"} or parsed["answer"] not in ("yes", "no"):
        return {"status": "fail", "reason": "Final content violates the original exact answer-key yes/no schema"}
    return {"status": "pass", "reason": "Original answer JSON format is valid; answer correctness was not checked"}


def check_rollout_completion(request: Mapping[str, Any]) -> dict[str, Any]:
    state, finish = request.get("state"), request.get("finish_reason")
    basis = {"observed_state": state, "observed_finish_reason": finish,
             "observed_invalid_reason": request.get("invalid_reason"),
             "observed_failure_class": request.get("failure_class")}
    if finish == "length":
        return {**basis, "status": "fail", "failure_kind": "truncated_rollout",
                "reason": "Original PNS rollout ended with length; it was not a one-token verifier score read"}
    if state in ("transport_failed", "serialization_invalid", "scientific_invalid"):
        return {**basis, "status": "fail", "failure_kind": state,
                "reason": "An original terminal failure is recorded; this is not proof of a semantic recovery mechanism"}
    if state == "completed" and request.get("valid") in (True, 1) and finish == "stop":
        return {**basis, "status": "pass", "failure_kind": None,
                "reason": "Original request completed and was marked structurally valid; causal correctness is not inferred"}
    return {**basis, "status": "unknown", "failure_kind": "unresolved_original_request",
            "reason": "Original request completion is not independently established by its state/finish fields"}


def _check_segments(parent: str, segments: Sequence[Mapping[str, Any]]) -> bool:
    position = 0
    exposed = False
    for expected, segment in enumerate(segments, 1):
        start, end = segment.get("char_start"), segment.get("char_end")
        if (segment.get("step_index") != expected or start != position
                or not isinstance(end, int) or isinstance(end, bool) or end <= start
                or parent[start:end] != segment.get("text")):
            return False
        current = segment.get("answer_exposed_prefix")
        if not isinstance(current, bool) or (exposed and not current):
            return False
        exposed = exposed or current
        position = end
    return bool(segments) and position == len(parent)


def audit_recovery_evidence(inputs: Sequence[Mapping[str, Any]], raw_rows: Sequence[Mapping[str, Any]],
                            original_rows: Sequence[Mapping[str, Any]], *, run_id: str,
                            replacement_generators: Sequence[Mapping[str, Any]] = ()) -> dict[str, Any]:
    if not isinstance(run_id, str) or not run_id.strip():
        raise ValueError("An explicit sidecar tool run ID is required")
    by_qid = {int(row["question_id"]): row for row in inputs}
    requests = {row["candidate_id"]: row["original_request"] for row in original_rows}
    if len(by_qid) != len(inputs) or len(requests) != len(original_rows):
        raise ValueError("Duplicate immutable input or request identities")
    if len({row["candidate_id"] for row in raw_rows}) != len(raw_rows):
        raise ValueError("Duplicate raw sample identities; do not deduplicate actual samples")
    generators = {(int(row["qid"]), int(row["step_index"])): row for row in replacement_generators}
    if len(generators) != len(replacement_generators):
        raise ValueError("More than one original replacement generator for a frozen decision group")
    replace_groups = defaultdict(list)
    for row in raw_rows:
        if row["condition"] == "replace":
            replace_groups[row["decision_group_id"]].append(row)
    records, evidence = [], []
    for raw in raw_rows:
        cid, qid = raw["candidate_id"], int(raw["question_id"])
        if cid not in requests or qid not in by_qid:
            raise ValueError("Missing original source for candidate " + cid)
        item, request = by_qid[qid], requests[cid]
        obs = raw["original_observation"]
        condition = raw["condition"]
        parent = item["parent_reasoning"]
        segments = item["segments"]
        target = next((s for s in segments if s["step_index"] == raw["target_step"]), None)
        if target is None:
            raise ValueError("Frozen target missing for " + cid)
        checks, candidate_evidence = [], []

        def record_check(name, input_value, result, checked_object):
            collected = _evidence(run_id, cid, name, input_value, result, checked_object)
            candidate_evidence.append(collected)
            checks.append(asdict(HardCheck(name, result["status"], (collected["tool_run_id"],), result["reason"])))
            return result

        completion = record_check("original_rollout_completion", {
            key: request.get(key) for key in ("state", "valid", "finish_reason", "invalid_reason", "failure_class")},
            check_rollout_completion(request), "Original PNS suffix request completion only")
        format_result = record_check("original_answer_format", {"messages": item["messages"],
            "final_content": request.get("final_content")},
            check_answer_format(item["messages"], request.get("final_content")),
            "Original final answer JSON schema only; no answer/oracle correctness check")
        identity_ok = (request.get("request_key") == raw["request_key"]
            and request.get("qid") == qid and request.get("step_index") == raw["target_step"]
            and request.get("branch") == condition and request.get("rollout") == raw["rollout_index"])
        texts_match = (request.get("complete_chain") == obs.get("full_reasoning")
                       and request.get("reasoning_suffix") == obs.get("reasoning_suffix")
                       and request.get("final_content") == obs.get("final_content"))
        try:
            request_body = json.loads(request["request_json"])
        except (ValueError, TypeError, KeyError):
            request_body = {}
        prefix = obs.get("prefix")
        serialized_ok = (isinstance(prefix, str) and request_body.get("prompt") == item["base_serialized_prompt"] + prefix)
        full, suffix = obs.get("full_reasoning"), obs.get("reasoning_suffix")
        reconstruction = (isinstance(prefix, str) and isinstance(suffix, str) and isinstance(full, str)
                          and full == prefix + suffix)
        if not identity_ok or not texts_match or not serialized_ok:
            provenance = {"status": "fail", "reason": "Raw sample identity, original text or serialized prefix does not match frozen sources"}
        elif suffix is None or full is None:
            provenance = {"status": "unknown", "reason": "Original failed request has no complete suffix/chain; no reconstruction is invented"}
        else:
            provenance = {"status": "pass" if reconstruction else "fail",
                          "reason": "Frozen prefix plus original suffix exactly reconstructs the candidate" if reconstruction
                          else "Candidate differs from its frozen prefix plus original suffix"}
        provenance.update(request_identity_matches=identity_ok, original_texts_match=texts_match,
                          serialized_prompt_matches=serialized_ok, full_chain_reconstructs=reconstruction)
        record_check("frozen_prefix_provenance", {"base_serialized_prompt": item["base_serialized_prompt"],
            "prefix": prefix, "suffix": suffix, "full_chain": full, "request_key": request.get("request_key"),
            "request_body": request_body, "source_identity": {k: request.get(k) for k in ("qid", "step_index", "branch", "rollout")}},
            provenance, "Frozen original continuation prompt, request identity and exact candidate reconstruction")
        segment_ok = _check_segments(parent, segments)
        legal_target = segment_ok and target.get("answer_exposed_prefix") is False
        replacement_tail = None
        if condition not in KNOWN_CONDITIONS:
            legality = {"status": "unknown", "reason": "Unsupported original condition; no WRONG experiment or legality rule is invented"}
        elif not legal_target or not isinstance(prefix, str):
            legality = {"status": "fail", "reason": "Target is exposed, malformed or not an exact original segment"}
        elif condition == "keep":
            ok = prefix == parent[:target["char_end"]]
            legality = {"status": "pass" if ok else "fail", "reason": "KEEP must retain exactly the prefix through the original target end"}
        elif condition == "delete":
            ok = prefix == parent[:target["char_start"]]
            legality = {"status": "pass" if ok else "fail", "reason": "DELETE must end exactly at the original target start"}
        else:
            base = parent[:target["char_start"]]
            replacement_tail = prefix[len(base):] if prefix.startswith(base) else None
            peers = replace_groups[raw["decision_group_id"]]
            shared = bool(peers) and all(p["original_observation"].get("prefix") == prefix for p in peers)
            complete_reuse = len(peers) == 2 and sorted(p["rollout_index"] for p in peers) == [1, 2]
            if replacement_tail is None or not replacement_tail.strip() or not shared:
                legality = {"status": "fail", "reason": "REPLACE changes the earlier prefix, has empty replacement, or does not reuse one frozen prefix"}
            else:
                generator = generators.get((qid, target["step_index"]))
                generator_result = check_replacement_generator(item, target, generator, prefix)
                generator_basis = {key: generator.get(key) for key in ("request_key", "qid", "step_index", "branch", "rollout",
                    "state", "valid", "finish_reason", "replacement_text", "request_json")} if generator else None
                record_check("replacement_generator_boundary", {"generator": generator_basis,
                    "original_question_messages": item["messages"], "parent_prior_prefix": parent[:target["char_start"]],
                    "target_text": target["text"], "frozen_prefix": prefix}, generator_result,
                    "One original replacement generation, allowed input boundary and exact frozen output reuse")
                legality = {"status": generator_result["status"], "reason": generator_result["reason"],
                            "slot_shape_status": "pass", "frozen_reuse_status": "pass" if complete_reuse else "unknown",
                            "replacement_generation_information_boundary": generator_result["status"]}
                if not complete_reuse and legality["status"] != "fail":
                    legality.update(status="unknown", reason="The complete original pair of REPLACE trials was not supplied; frozen cross-trial reuse remains unknown")
        legality.update(condition=condition, target_step=target["step_index"],
                        original_segments_reconstruct=segment_ok, target_is_before_answer_exposure=legal_target,
                        intentional_wrong_injection="not_declared_by_original_KEEP_DELETE_REPLACE_protocol")
        record_check("intervention_slot_legality", {"parent": parent, "target": dict(target),
            "condition": condition, "frozen_prefix": prefix, "replacement_tail": replacement_tail},
            legality, "Allowed edit slot and frozen-prefix reuse only; mathematical wrongness is independent of slot legality")
        literal = isinstance(suffix, str) and bool(target["text"].strip()) and target["text"].strip() in suffix
        if condition == "keep":
            recovery_reason = "KEEP retains the target; deletion/error recovery is not applicable to this control"
        elif completion["status"] != "pass":
            recovery_reason = "Original rollout failed or is incomplete; semantic recovery cannot be assessed: " + completion["reason"]
        elif literal:
            recovery_reason = "Target text reappears literally, but text overlap does not establish the same semantic operation"
        else:
            recovery_reason = "No exact target-text reappearance; absence of literal text does not prove absence of semantic reconstruction or a legal alternative"
        recovery = {"class": "failed_or_unknown", "status": "unknown",
            "not_applicable": condition == "keep", "reason": recovery_reason,
            "target_text_literal_reappears_in_suffix": literal,
            "semantic_operation_identity": "unknown", "legal_alternative_derivation": "unknown",
            "arithmetic_validity": "unknown", "scm_semantic_validity": "unknown",
            "unknown_basis": "No independently established operation certificate, original-task executable SCM, or verified arithmetic derivation was supplied"}
        recovery_ev = _evidence(run_id, cid, "recovery_mechanism", {"target_text": target["text"],
            "condition": condition, "original_suffix": suffix, "completion": completion}, recovery,
            "Post-intervention recovery mechanism; literal overlap is a diagnostic only")
        candidate_evidence.append(recovery_ev)
        records.append({"candidate_id": cid, "task_id": raw["task_id"], "question_id": qid,
            "decision_group_id": raw["decision_group_id"], "condition": condition,
            "target_step": raw["target_step"], "rollout_index": raw["rollout_index"],
            "candidate_hash": raw["candidate_hash"], "recovery": recovery,
            "hard_checks": checks, "evidence_refs": [e["tool_run_id"] for e in candidate_evidence],
            "scope": "posthoc_sidecar_not_blind_review_prompt", "acceptance_actions": 0})
        evidence.extend(candidate_evidence)
    summary = {"raw_candidates": len(raw_rows), "sidecar_records": len(records),
        "condition_counts": dict(Counter(row["condition"] for row in raw_rows)),
        "recovery_class_counts": dict(Counter(row["recovery"]["class"] for row in records)),
        "recovery_not_applicable_keep": sum(row["recovery"]["not_applicable"] for row in records),
        "recovery_applicable_unknown": sum(not row["recovery"]["not_applicable"] for row in records),
        "hard_check_status_counts": {name: dict(Counter(check["status"] for row in records for check in row["hard_checks"] if check["name"] == name))
            for name in ("original_rollout_completion", "original_answer_format", "frozen_prefix_provenance", "intervention_slot_legality", "replacement_generator_boundary")},
        "original_replacement_generators_read": len(generators),
        "semantic_recovery_claims": 0, "model_calls": 0, "new_rollouts": 0,
        "oracle_labels_used": False, "candidate_code_executed": False,
        "blind_prompt_changed": False, "recovery_classes": list(RECOVERY_CLASSES)}
    return {"records": records, "evidence": evidence, "summary": summary}


def inspect_openapi_choice(document: Mapping[str, Any]) -> dict[str, Any]:
    """Inspect a saved real schema only; schema support is not runtime success."""
    schema = document.get("response", document)
    if not isinstance(schema, Mapping) or not isinstance(schema.get("openapi"), str):
        raise ValueError("Input is not an observed OpenAPI document or HTTPRecord.response")

    def properties(node, seen=frozenset()):
        result = dict(node.get("properties", {})) if isinstance(node, Mapping) else {}
        unresolved = []
        if not isinstance(node, Mapping):
            return result, unresolved
        ref = node.get("$ref")
        if ref:
            if not isinstance(ref, str) or not ref.startswith("#/") or ref in seen:
                unresolved.append(str(ref))
            else:
                resolved = schema
                try:
                    for part in ref[2:].split("/"):
                        resolved = resolved[part.replace("~1", "/").replace("~0", "~")]
                    nested, missing = properties(resolved, seen | {ref})
                    result.update(nested)
                    unresolved.extend(missing)
                except (KeyError, TypeError):
                    unresolved.append(ref)
        for key in ("allOf", "anyOf", "oneOf"):
            for child in node.get(key, []):
                nested, missing = properties(child, seen)
                result.update(nested)
                unresolved.extend(missing)
        return result, unresolved

    records = []
    schemas = schema.get("components", {}).get("schemas", {})
    for name in ("ChatCompletionRequest", "CompletionRequest"):
        if name not in schemas:
            records.append({"request_schema": name, "schema_advertised_choice_support": "unknown", "reason": "Request schema absent"})
            continue
        fields, missing = properties(schemas[name])
        if "structured_outputs" not in fields:
            records.append({"request_schema": name, "schema_advertised_choice_support": "unknown" if missing else False,
                            "reason": "Request schema references unresolved" if missing else "structured_outputs field absent",
                            "unresolved_refs": missing})
            continue
        params, refs = properties(fields["structured_outputs"])
        records.append({"request_schema": name,
            "schema_advertised_choice_support": True if "choice" in params else ("unknown" if refs else False),
            "structured_outputs_present": True, "choice_schema": params.get("choice"),
            "unresolved_refs": missing + refs, "runtime_choice_execution": "NOT_RUN"})
    return {"observed_openapi_version": schema["openapi"], "schema_hash": content_hash(schema),
        "request_schemas": records, "necessity": "strict scoring does not require it",
        "strict_scoring_uses_choice": False, "model_calls": 0,
        "probability_note": "A grammar can alter probabilities before raw softmax; no constrained distribution is promoted to an unconstrained main score"}
