"""Frozen replay extraction and same-distribution diagnostic statistics.

This module never calls a model, changes acceptance, or infers path validity from
answer equality. Metadata/old labels are separated from blind scoring payloads.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .core import CRITERIA, LABELS, LABEL_VALUES, canonical_json, content_hash

FROZEN_QIDS = (29590, 29980, 4171, 4274, 4255, 19407, 18188, 24894, 1428, 8752)
SELECTION_RULE = "predeclared_five_types_two_qids_each__earliest_legal_step__all_existing_condition_trials"
CONDITIONS = ("keep", "delete", "replace")


def read_jsonl(path: str | Path) -> Iterable[dict[str, Any]]:
    with Path(path).open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_frozen(path: str | Path, value: Any, *, jsonl: bool = False) -> None:
    """Create immutable artifacts, accepting an identical no-op rerun only."""
    path = Path(path)
    text = ("".join(canonical_json(row) + "\n" for row in value) if jsonl
            else json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    data = text.encode("utf-8")
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError("Refusing to overwrite changed frozen artifact: " + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(data)


def allowed_task(item: Mapping[str, Any]) -> dict[str, Any]:
    messages = item.get("messages")
    if not isinstance(messages, list) or not messages:
        raise ValueError("Original task messages missing")
    clean = []
    for message in messages:
        if not isinstance(message, Mapping) or set(message) != {"role", "content"}:
            raise ValueError("Original message must contain only role/content")
        if message["role"] not in ("system", "user") or not isinstance(message["content"], str):
            raise ValueError("Unexpected role or nontext original task")
        clean.append({"role": message["role"], "content": message["content"]})
    if not any(m["role"] == "user" and m["content"].strip() for m in clean):
        raise ValueError("Original user question missing")
    return {"messages": clean}


def prepare_replay_records(inputs: Sequence[Mapping[str, Any]],
                           pool: Sequence[Mapping[str, Any]], *,
                           qids: Sequence[int] = FROZEN_QIDS) -> dict[str, Any]:
    if len(qids) != len(set(qids)) or not qids:
        raise ValueError("Unique predeclared qids required")
    indexed = {int(row["question_id"]): row for row in inputs}
    results = {int(row["question_id"]): row for row in pool}
    if len(indexed) != len(inputs) or len(results) != len(pool):
        raise ValueError("Duplicate source question IDs")
    blind, raw, labels, groups = [], [], [], []
    sample_ids = set()
    for qid in qids:
        item, result = indexed[qid], results[qid]
        task = allowed_task(item)
        task_id = "task_" + content_hash(task)[:20]
        legal = [s for s in item["segments"] if s.get("answer_exposed_prefix") is False]
        if not legal:
            raise ValueError("No original legal step; do not substitute a question")
        segment = min(legal, key=lambda s: s["step_index"])
        step = int(segment["step_index"])
        parent = item["parent_reasoning"]
        start, end = segment["char_start"], segment["char_end"]
        if not (0 <= start < end <= len(parent)) or parent[start:end] != segment["text"]:
            raise ValueError("Frozen target no longer reconstructs original parent")
        observations = [o for o in result["observations"] if int(o["step_index"]) == step]
        if not observations:
            raise ValueError("Earliest legal group missing; do not select by outcomes")
        counts = Counter(o["intervention"] for o in observations)
        if counts.get("keep") != 2 or counts.get("delete") != 2:
            raise ValueError("Frozen fixed-M2 KEEP/DELETE group incomplete")
        if set(counts) - set(CONDITIONS) or counts.get("replace", 2) != 2:
            raise ValueError("Unexpected condition or incomplete REPLACE group")
        group_id = "group_" + content_hash({"task_id": task_id, "parent": parent,
                                           "step": step, "segment": segment})[:20]
        group_samples = []
        for condition in CONDITIONS:
            branch = sorted((o for o in observations if o["intervention"] == condition),
                            key=lambda o: (o["trial"], o["request_key"]))
            if branch and [o["trial"] for o in branch] != [1, 2]:
                raise ValueError("Fixed condition must retain original trial 1 and 2")
            for obs in branch:
                if condition == "keep" and obs["prefix"] != parent[:end]:
                    raise ValueError("KEEP prefix differs from frozen target")
                if condition == "delete" and obs["prefix"] != parent[:start]:
                    raise ValueError("DELETE prefix differs from frozen target")
                if obs["full_reasoning"] is not None and obs["reasoning_suffix"] is not None:
                    if obs["full_reasoning"] != obs["prefix"] + obs["reasoning_suffix"]:
                        raise ValueError("Candidate full chain violates continuation provenance")
                candidate_id = "candidate_" + content_hash({"group_id": group_id,
                    "request_key": obs["request_key"]})[:24]
                if candidate_id in sample_ids:
                    raise ValueError("Duplicate sample identity")
                sample_ids.add(candidate_id)
                group_samples.append(candidate_id)
                rollout = {"reasoning": obs["full_reasoning"], "final_content": obs["final_content"]}
                blind.append({"candidate_id": candidate_id, "task_id": task_id,
                              "task": task, "rollout": rollout})
                raw.append({"sample_id": candidate_id, "candidate_id": candidate_id,
                    "task_id": task_id, "decision_group_id": group_id,
                    "question_id": qid, "query_type": item["query_type"], "target_step": step,
                    "condition": condition, "rollout_index": obs["trial"],
                    "request_key": obs["request_key"], "status": "valid" if obs["observation_valid"] else "invalid",
                    "candidate_hash": content_hash(rollout), "original_observation": dict(obs)})
                labels.append({"candidate_id": candidate_id, "task_id": task_id,
                    "answer_only_correct": obs["answer_correct"] if obs["observation_valid"] else None,
                    "original_answer_correct_flag": obs["answer_correct"],
                    "original_observation_valid": obs["observation_valid"],
                    "label_scope": "offline_answer_equivalence_only_not_causal_trajectory_truth",
                    "independent_full_trajectory_valid": None,
                    "independent_criterion_labels": {criterion: "unknown" for criterion in CRITERIA},
                    "recovery_mechanism": "unknown", "original_error": obs.get("error")})
        groups.append({"decision_group_id": group_id, "task_id": task_id, "question_id": qid,
            "query_type": item["query_type"], "target_step": step,
            "target_char_start": start, "target_char_end": end,
            "parent_reasoning_hash": content_hash(parent), "raw_sample_ids": group_samples,
            "condition_counts": dict(counts), "raw_rollouts": len(observations),
            "invalid_rollouts": sum(not o["observation_valid"] for o in observations)})
    return {"blind_candidates": blind, "raw_rollouts": raw, "offline_labels": labels,
            "groups": groups, "selection_rule": SELECTION_RULE,
            "qids": list(qids), "new_rollout_calls": 0}


def derive_paired_scores(record: Mapping[str, Any], *, tolerance: float = 1e-9) -> dict[str, Any]:
    """Derive argmax and expectation from the SAME complete recorded distribution."""
    if record.get("status") != "VALID":
        return {"status": "unknown", "reason": record.get("error_code", "invalid_score")}
    if record.get("source") != "raw_logprobs" or record.get("logprobs_mode") != "raw_logprobs":
        raise ValueError("Only exact raw score records belong in paired main diagnostics")
    labels = record.get("labels") or {}
    if set(labels) != set(LABELS):
        raise ValueError("All 20 labels required")
    probabilities = {}
    for label in LABELS:
        value = labels[label]["conditional_probability"]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("Invalid conditional grade probability")
        if not math.isclose(labels[label]["value"], LABEL_VALUES[label], abs_tol=tolerance):
            raise ValueError("Grade direction mismatch")
        probabilities[label] = value
    if not math.isclose(math.fsum(probabilities.values()), 1, abs_tol=tolerance):
        raise ValueError("Conditional distribution not normalized")
    argmax = max(LABELS, key=lambda label: probabilities[label])
    expectation = math.fsum(probabilities[label] * LABEL_VALUES[label] for label in LABELS)
    discrete = LABEL_VALUES[argmax]
    if record.get("score") is not None and not math.isclose(record["score"], expectation, abs_tol=tolerance):
        raise ValueError("Stored expectation differs from recorded distribution")
    if record.get("discrete_score") is not None and not math.isclose(record["discrete_score"], discrete, abs_tol=tolerance):
        raise ValueError("Stored discrete score differs from recorded distribution")
    return {"status": "valid", "expectation": expectation, "discrete": discrete,
            "argmax_label": argmax, "distribution_hash": content_hash(labels),
            "prompt_hash": record.get("prompt_hash"), "review_id": record.get("review_id"),
            "review_seed": record.get("review_seed")}


def _ranking(rows: Sequence[tuple[str, float]], *, tolerance: float) -> dict[str, Any]:
    pairs = list(itertools.combinations(rows, 2))
    ties = sum(abs(a[1] - b[1]) <= tolerance for a, b in pairs)
    if not rows:
        return {"selected_id": None, "status": "unknown", "pair_count": 0,
                "tied_pairs": 0, "pairwise_tie_rate": None, "top_tied_count": 0}
    top = max(value for _, value in rows)
    tied = sorted(cid for cid, value in rows if abs(value - top) <= tolerance)
    return {"selected_id": tied[0], "status": "diagnostic_only_not_acceptance",
            "top_score": top, "top_tied_count": len(tied), "top_tied_ids": tied,
            "pair_count": len(pairs), "tied_pairs": ties,
            "pairwise_tie_rate": ties / len(pairs) if pairs else None,
            "tie_break": "lexicographic_opaque_candidate_id"}


def summarize_scores(raw_rollouts: Sequence[Mapping[str, Any]],
                     score_records: Sequence[Mapping[str, Any]], *,
                     offline_labels: Sequence[Mapping[str, Any]] = (),
                     tie_tolerance: float = 1e-10) -> dict[str, Any]:
    if not math.isfinite(tie_tolerance) or tie_tolerance < 0:
        raise ValueError("Predeclared nonnegative tie tolerance required")
    samples = {r["candidate_id"]: r for r in raw_rollouts}
    if len(samples) != len(raw_rollouts):
        raise ValueError("Duplicate raw sample IDs")
    labels = {r["candidate_id"]: r for r in offline_labels}
    grouped = defaultdict(list)
    seen = set()
    actual_reviews = defaultdict(dict)
    for score in score_records:
        cid, criterion = score.get("candidate_id"), score.get("criterion")
        if cid not in samples or criterion not in CRITERIA:
            raise ValueError("Score is outside frozen replay or has invalid criterion")
        repeat = score.get("review_repeat", 0)
        if isinstance(repeat, bool) or not isinstance(repeat, int) or repeat < 0:
            raise ValueError("Explicit nonnegative review repeat required")
        identity = (cid, criterion, repeat)
        if identity in seen:
            raise ValueError("Repeated score read cannot become another independent vote")
        seen.add(identity)
        if score.get("status") == "VALID":
            frozen_hash = samples[cid].get("candidate_hash")
            if frozen_hash is not None and score.get("candidate_hash") != frozen_hash:
                raise ValueError("Score candidate hash differs from the frozen replay text")
            histories = actual_reviews[(cid, criterion)]
            review_id, review_seed = score.get("review_id"), score.get("review_seed")
            if histories:
                if (not isinstance(review_id, str) or not review_id
                        or isinstance(review_seed, bool) or not isinstance(review_seed, int)):
                    raise ValueError("Repeated-review statistics require an actual review ID and seed")
                for prior_id, prior_seed in histories.values():
                    if not prior_id or prior_seed is None or review_id == prior_id or review_seed == prior_seed:
                        raise ValueError("A reread or reused review seed cannot become a new independent repeat")
            histories[repeat] = (review_id, review_seed)
        pair = derive_paired_scores(score)
        # A complete grade read cannot make an invalid original rollout valid.
        if samples[cid]["status"] != "valid":
            pair = {"status": "unknown", "reason": "original_rollout_invalid"}
        grouped[(samples[cid]["decision_group_id"], criterion, repeat)].append((cid, pair))
    known_groups = sorted({r["decision_group_id"] for r in raw_rollouts})
    repeats = sorted({key[2] for key in grouped}) or [0]
    comparisons = []
    for group, criterion, repeat in itertools.product(known_groups, CRITERIA, repeats):
        expected = [cid for cid, r in samples.items() if r["decision_group_id"] == group]
        present = grouped.get((group, criterion, repeat), [])
        valid = [(cid, pair) for cid, pair in present if pair["status"] == "valid"]
        discrete = _ranking([(cid, pair["discrete"]) for cid, pair in valid], tolerance=tie_tolerance)
        continuous = _ranking([(cid, pair["expectation"]) for cid, pair in valid], tolerance=tie_tolerance)
        comparisons.append({"decision_group_id": group, "criterion": criterion,
            "review_repeat": repeat, "raw_sample_count": len(expected),
            "score_records_received": len(present), "valid_scored_samples": len(valid),
            "unknown_or_missing_samples": len(expected) - len(valid),
            "discrete": discrete, "continuous": continuous,
            "selection_changed": discrete["selected_id"] != continuous["selected_id"] if valid else None,
            "selected_answer_only_correct": {"discrete": labels.get(discrete["selected_id"], {}).get("answer_only_correct"),
                "continuous": labels.get(continuous["selected_id"], {}).get("answer_only_correct")},
            "selected_joint_criterion_correctness": "unknown",
            "paired_distributions": [{"candidate_id": cid, **pair} for cid, pair in valid]})
    totals = {}
    for criterion in CRITERIA:
        rows = [r for r in comparisons if r["criterion"] == criterion]
        totals[criterion] = {}
        for method in ("discrete", "continuous"):
            pairs = sum(r[method]["pair_count"] for r in rows)
            ties = sum(r[method]["tied_pairs"] for r in rows)
            totals[criterion][method] = {"pair_count": pairs, "tied_pairs": ties,
                "pairwise_tie_rate": ties / pairs if pairs else None}
    return {"status": "interface_diagnostics_only", "tie_tolerance": tie_tolerance,
            "comparisons": comparisons, "per_criterion_totals": totals,
            "raw_sample_count": len(raw_rollouts),
            "original_invalid_rollouts": sum(r["status"] != "valid" for r in raw_rollouts),
            "score_record_status_counts": dict(Counter(str(r.get("status", "missing")) for r in score_records)),
            "score_error_counts": dict(Counter(str(r.get("error_code") or "unspecified")
                for r in score_records if r.get("status") != "VALID")),
            "unknown_recovery_labels": sum(labels.get(cid, {}).get("recovery_mechanism", "unknown") == "unknown"
                                           for cid in samples),
            "false_accepts": "unknown", "correct_rejects": "unknown",
            "tpr": "unknown", "fpr": "unknown", "joint_correctness": "unknown",
            "reason": "No calibrated acceptance or independent full trajectory labels; answer labels are separate",
            "new_rollout_calls": 0}


def coverage_curves(raw_rollouts: Sequence[Mapping[str, Any]],
                    offline_labels: Sequence[Mapping[str, Any]], *,
                    requested_m: Sequence[int] = (1, 2, 4, 8, 16, 32)) -> dict[str, Any]:
    labels = {row["candidate_id"]: row for row in offline_labels}
    groups = defaultdict(list)
    seen = set()
    for row in raw_rollouts:
        if row["candidate_id"] in seen:
            raise ValueError("Duplicate sample cannot inflate M")
        seen.add(row["candidate_id"])
        groups[(row["decision_group_id"], row["condition"])].append(row)
    points, unavailable = [], []
    for (group, condition), samples in sorted(groups.items()):
        samples.sort(key=lambda row: row["rollout_index"])
        if len({row["rollout_index"] for row in samples}) != len(samples):
            raise ValueError("Duplicate original rollout index")
        for m in requested_m:
            if isinstance(m, bool) or not isinstance(m, int) or m < 1:
                raise ValueError("M must be a positive integer")
            if len(samples) < m:
                unavailable.append({"decision_group_id": group, "condition": condition,
                                    "M": m, "reason": "insufficient_real_rollouts"})
                continue
            selected = samples[:m]
            answer = [labels.get(row["candidate_id"], {}).get("answer_only_correct") for row in selected]
            answer_coverage = (True if any(v is True for v in answer) else
                               False if all(v is False for v in answer) else None)
            points.append({"decision_group_id": group, "condition": condition, "M": m,
                "raw_sample_ids": [r["candidate_id"] for r in selected], "raw_sample_count": m,
                "invalid_samples": sum(r["status"] != "valid" for r in selected),
                "answer_only_coverage_at_m": answer_coverage,
                "oracle_valid_at_m": "unknown", "selected_valid_at_m": "unknown",
                "oracle_improvement_at_m": "unknown",
                "scope": "one_frozen_parent_target_condition__original_trial_order"})
    return {"points": points, "unavailable_points": unavailable,
            "label_limitation": "Answer equality is not independent causal-path validity; no full-validity curve inferred",
            "resampling_or_duplication": False}
