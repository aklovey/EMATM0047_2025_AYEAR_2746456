"""PNS shadow hook which preserves the existing callback's return object exactly."""
from __future__ import annotations

from typing import Any, Callable, Sequence

from .core import CalibrationGate, Candidate, choose_candidate


def shadow_hook(existing_callback: Callable[..., Any], *, parent_id: str, parent_rollout: Any,
                candidates: Sequence[Candidate], record: Callable[[dict[str, Any]], None],
                calibration: CalibrationGate | None = None,
                maximize_objective: bool = True) -> Callable[..., Any]:
    """Record a recommendation after the unchanged existing PNS decision.

    Scoring or logging failure cannot replace an existing decision. The hook never
    changes prompts, intervention conditions, rollout budgets or sampling counts.
    ``record`` should be a local append-only logger; it must not send messages.
    """
    def wrapped(*args, **kwargs):
        original_result = existing_callback(*args, **kwargs)
        try:
            decision = choose_candidate(parent_id, parent_rollout, candidates, mode="shadow",
                                        calibration=calibration, maximize_objective=maximize_objective)
            record({"event": "verifier_shadow", "decision": decision.to_dict(),
                    "existing_decision_preserved": True, "new_model_requests": 0})
        except Exception as exc:
            try:
                record({"event": "verifier_shadow_error", "error_type": type(exc).__name__,
                        "existing_decision_preserved": True, "new_model_requests": 0})
            except Exception:
                pass  # The existing callback's decision still cannot be replaced.
        return original_result
    return wrapped


def acceptance_decision(*, parent_id: str, parent_rollout: Any, candidates: Sequence[Candidate],
                        explicit_mode: str, calibration: CalibrationGate | None,
                        maximize_objective: bool = True):
    """Separate explicit acceptance entry point; the replay CLI never invokes it."""
    if explicit_mode != "acceptance":
        return choose_candidate(parent_id, parent_rollout, candidates, mode="shadow",
                                calibration=calibration, maximize_objective=maximize_objective)
    return choose_candidate(parent_id, parent_rollout, candidates, mode="acceptance",
                            calibration=calibration, maximize_objective=maximize_objective)
