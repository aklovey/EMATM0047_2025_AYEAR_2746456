"""Actual temporary SQLite overlap tests; fake HTTP transports only."""
import copy
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import importlib.util
import io
import json
import math
from pathlib import Path
import sys
import tempfile
import threading
import unittest

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "src"))
sys.path.insert(0, str(PACKAGE / "scripts"))
import boost_replay as boost
from cause_verifier.client import BudgetExceeded, BudgetLimit, JournaledClient
from cause_verifier.core import content_hash
spec = importlib.util.spec_from_file_location("boost_test_helpers", PACKAGE / "tests" / "test_parallel_replay.py")
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


class Response(io.BytesIO):
    status = 200


class Backend:
    def __init__(self, barrier=None, entered=None, release=None, status=200):
        self.barrier, self.entered, self.release, self.status = barrier, entered, release, status
        self.lock = threading.Lock()
        self.calls = self.active = self.peak = 0

    def __call__(self, request, timeout):
        with self.lock:
            self.calls += 1
            self.active += 1
            self.peak = max(self.peak, self.active)
        try:
            if self.entered:
                self.entered.set()
            if self.release:
                self.release.wait(timeout=5)
            if self.barrier:
                self.barrier.wait(timeout=5)
            response = Response(b'{"choices":[],"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}')
            response.status = self.status
            return response
        finally:
            with self.lock:
                self.active -= 1


def make_client(root, backend, endpoint="http://127.0.0.1:8000", max_requests=20):
    return JournaledClient(endpoint, root / "journal.sqlite", root / "http",
        allowed_endpoints=["http://127.0.0.1:8000", "http://127.0.0.1:8001"],
        limits={"global": BudgetLimit(max_requests, max_requests * 2, 30)}, transport=backend)


def call(client, identity="same", candidate="c", payload=None):
    return client.post("/v1/completions", payload or {"model": "mock", "prompt": [1], "max_tokens": 1},
        request_id=identity, stage="verifier_review", qid="q", candidate_id=candidate, prompt_tokens=1)


def aware(delegate, owners=None, gpu=0, **kwargs):
    return boost.ReplayAwareClient(delegate, gpu=gpu, owners=owners or {"c": 0},
        audit=kwargs.pop("audit", boost.Audit()), slots=kwargs.pop("slots", boost.ExtraSlots()),
        poll_seconds=.005, wait_seconds=kwargs.pop("wait_seconds", 5), **kwargs)


class BoostTests(unittest.TestCase):
    def test_original_inflight_is_waited_then_reused_with_no_new_post_or_k(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            entered, release = threading.Event(), threading.Event()
            backend = Backend(entered=entered, release=release)
            original, delegate = make_client(root, backend), make_client(root, backend)
            wrapper = aware(delegate)
            with ThreadPoolExecutor(max_workers=2) as executor:
                old = executor.submit(call, original)
                self.assertTrue(entered.wait(timeout=5))
                cached = executor.submit(call, wrapper)
                self.assertEqual(backend.calls, 1)
                release.set()
                first, reused = old.result(), cached.result()
            self.assertEqual(first.status, "OK")
            self.assertEqual(reused.status, "OK")
            self.assertTrue(reused.replay_cache_hit)
            self.assertEqual(reused.independent_review_increment, 0)
            self.assertFalse(reused.new_transport_dispatch_marked)
            self.assertEqual(backend.calls, 1)
            self.assertEqual(original.summary()["reserved_request_identities"], 1)

    def test_atomic_duplicate_race_returns_same_one_post_result(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            backend, before_reserve, audit = Backend(), threading.Barrier(2), boost.Audit()
            clients = [make_client(root, backend) for _ in range(2)]
            for client in clients:
                post = client.post
                def racing(*args, original=post, **kwargs):
                    before_reserve.wait(timeout=5)
                    return original(*args, **kwargs)
                client.post = racing
            wrappers = [aware(client, audit=audit) for client in clients]
            with ThreadPoolExecutor(max_workers=2) as executor:
                results = list(executor.map(call, wrappers))
            self.assertEqual([result.status for result in results], ["OK", "OK"])
            self.assertEqual(backend.calls, 1)
            self.assertIn("atomic_race_lost_reuse", [event["action"] for event in audit.events])

    def test_terminal_failure_never_retries_or_changes_existing_row(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            backend = Backend(status=500)
            delegate = make_client(root, backend)
            self.assertEqual(call(delegate).status, "HTTP_ERROR")
            before = boost.one_row(delegate.journal_path, "same")
            wrapper = aware(delegate)
            for _ in range(3):
                self.assertEqual(call(wrapper).status, "HTTP_ERROR")
            self.assertEqual(backend.calls, 1)
            self.assertEqual(before, boost.one_row(delegate.journal_path, "same"))

    def test_changed_payload_and_corrupt_response_are_never_resent(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root, backend = Path(directory), Backend()
            delegate = make_client(root, backend)
            original = call(delegate)
            wrapper = aware(delegate)
            with self.assertRaises(boost.PayloadMismatch):
                call(wrapper, payload={"model": "other-model", "prompt": [1], "max_tokens": 1})
            Path(original.raw_response_path).write_bytes(b'{"changed":true}')
            self.assertEqual(call(wrapper).status, "REPLAY_ARTIFACT_UNKNOWN")
            self.assertEqual(backend.calls, 1)

    def test_active_wait_timeout_stays_unknown_without_mutating_or_resending_identity(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            entered, release = threading.Event(), threading.Event()
            backend = Backend(entered=entered, release=release)
            delegate = make_client(root, backend)
            with ThreadPoolExecutor(max_workers=1) as executor:
                old = executor.submit(call, delegate)
                self.assertTrue(entered.wait(timeout=5))
                before = boost.one_row(delegate.journal_path, "same")
                unknown = call(aware(make_client(root, backend), wait_seconds=.01))
                self.assertEqual(unknown.status, "REPLAY_ACTIVE_OR_RESERVED_UNKNOWN")
                self.assertEqual(before, boost.one_row(delegate.journal_path, "same"))
                release.set()
                old.result()
            self.assertEqual(backend.calls, 1)

    def test_live_shared_sqlite_identity_prioritizes_waiting_over_complete_or_no_new_work(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            entered, release = threading.Event(), threading.Event()
            backend = Backend(entered=entered, release=release)
            delegate = make_client(root, backend)
            with ThreadPoolExecutor(max_workers=1) as executor:
                original = executor.submit(call, delegate)
                self.assertTrue(entered.wait(timeout=5))
                observed = boost.journal_rows(delegate.journal_path)
                for new_dispatches, invalid_scores in ((0, 1), (1, 1), (0, 0), (1, 0)):
                    state = boost.completion_state(observed, new_dispatches=new_dispatches, invalid_scores=invalid_scores)
                    self.assertEqual(state["status"], "WAITING_FOR_SHARED_JOURNAL")
                    self.assertEqual(state["pending_shared_request_ids"], ["same"])
                    self.assertFalse(state["authoritative_snapshot_is_final"])
                    self.assertEqual(state["result_scope"], "CURRENT_SHARED_JOURNAL_SNAPSHOT")
                self.assertEqual(backend.calls, 1)
                release.set()
                original.result()
            terminal = boost.completion_state(boost.journal_rows(delegate.journal_path), new_dispatches=0, invalid_scores=0)
            self.assertEqual(terminal["status"], "NO_NEW_WORK")
            self.assertTrue(terminal["all_registered_requests_terminal"])

    def test_unregistered_legitimate_read_or_authoritative_failure_is_not_no_new_work(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root, backend = Path(directory), Backend()
            delegate = make_client(root, backend)
            self.assertEqual(call(delegate).status, "OK")
            rows = boost.journal_rows(delegate.journal_path)
            incomplete = boost.completion_state(rows, new_dispatches=0, invalid_scores=1,
                required_request_ids={"same", "eligible-score-not-registered"})
            self.assertEqual(incomplete["status"], "INCOMPLETE_SHARED_WORK")
            self.assertEqual(incomplete["missing_legitimate_request_ids"], ["eligible-score-not-registered"])
            self.assertFalse(incomplete["authoritative_snapshot_is_final"])
            failed = boost.completion_state(rows, new_dispatches=0, invalid_scores=1,
                required_request_ids={"same"}, reconstruction_errors=["authoritative worker failed"])
            self.assertEqual(failed["status"], "RECONSTRUCTION_INCOMPLETE")
            self.assertFalse(failed["authoritative_snapshot_is_final"])
            self.assertEqual(backend.calls, 1)

    def test_six_extra_plus_two_original_overlap_peak_eight_and_shared_budget_still_stops(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            backend = Backend(barrier=threading.Barrier(8))
            endpoints = ["http://127.0.0.1:8000", "http://127.0.0.1:8001"]
            original = [make_client(root, backend, endpoint, 8) for endpoint in endpoints]
            extra = [make_client(root, backend, endpoints[i // 3], 8) for i in range(6)]
            owners = {"new" + str(i): i // 3 for i in range(6)}
            slots = boost.ExtraSlots()
            wrappers = [aware(client, owners, i // 3, slots=slots) for i, client in enumerate(extra)]
            with ThreadPoolExecutor(max_workers=8) as executor:
                futures = [executor.submit(call, client, "old" + str(i), "old" + str(i)) for i, client in enumerate(original)]
                futures += [executor.submit(call, client, "new" + str(i), "new" + str(i)) for i, client in enumerate(wrappers)]
                self.assertTrue(all(future.result().status == "OK" for future in futures))
            self.assertEqual(backend.peak, 8)
            self.assertEqual(slots.peak, 6)
            self.assertEqual(slots.gpu_peak, [3, 3])
            self.assertEqual(original[0].summary()["reserved_request_identities"], 8)
            with self.assertRaises(BudgetExceeded):
                call(original[0], "over-budget", "over-budget")
            self.assertEqual(backend.calls, 8)

    def test_cache_only_missing_id_never_creates_placeholder_and_single_booster_lock(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root, backend = Path(directory), Backend()
            delegate = make_client(root, backend)
            result = call(aware(delegate, allow_new=False))
            self.assertEqual(result.status, "REPLAY_NOT_REGISTERED_NO_NEW_WORK")
            self.assertEqual(delegate.summary()["reserved_request_identities"], 0)
            self.assertEqual(backend.calls, 0)
            with boost.single_booster(delegate.journal_path):
                with self.assertRaises(OSError):
                    with boost.single_booster(delegate.journal_path):
                        pass

    def test_ordering_audit_does_not_claim_old_coordinator_global_barrier(self):
        rows = [{"request_id": "r", "stage": "verifier_review", "transport_attempted_at": 1.,
                 "finished_at": 5., "response_complete_at": 5., "response_received_at": 5.},
                {"request_id": "s", "stage": "verifier_score_read", "transport_attempted_at": 3.,
                 "finished_at": 4., "response_complete_at": 4., "response_received_at": 4.}]
        audit = boost.ordering_audit(rows, {"r"})
        self.assertTrue(audit["runtime_ordering_change_observed"])
        self.assertFalse(audit["global_phase_barrier_claimed"])
        self.assertEqual(audit["journal_client_interval_peak"], 2)

    def test_finished_run_with_truncated_review_never_fills_unused_budget_and_returns_no_new_work(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            args = helpers.fixture()
            candidates, raw, requests, groups = [], [], [], []
            for i in range(6):
                qid = 101 + i
                task = {"messages": [{"role": "user", "content": "Synthetic completed question " + str(qid)}]}
                tid, cid = "task_" + content_hash(task)[:20], "candidate-" + str(qid)
                rollout = {"reasoning": "Synthetic recorded chain " + str(qid), "final_content": "No."}
                candidates.append({"candidate_id": cid, "task_id": tid, "task": task, "rollout": rollout})
                raw.append({"candidate_id": cid, "task_id": tid, "question_id": qid, "decision_group_id": "g" + str(qid),
                            "candidate_hash": content_hash(rollout), "status": "valid"})
                requests.append({"candidate_id": cid, "original_request": {"state": "completed", "valid": 1,
                    "finish_reason": "stop", "complete_chain": rollout["reasoning"], "final_content": rollout["final_content"]}})
                groups.append({"task_id": tid, "question_id": qid, "decision_group_id": "g" + str(qid), "raw_sample_ids": [cid]})
            args.update(candidates=candidates, raw_rows=raw, original_requests=requests,
                manifest={"qid_order": [101 + i for i in range(6)], "groups": groups,
                          "frozen_raw_rollout_count": 6, "blind_payload_hash": content_hash(candidates)},
                config=replace(args["config"], max_requests=36, max_tokens=360000))
            calls = []
            def fake(request, timeout):
                payload = json.loads(request.data)
                calls.append(request.full_url)
                if "messages" in payload:
                    tokens = len(helpers.ToyTokenizer().apply_chat_template(payload["messages"], add_generation_prompt=True))
                    review_input = json.loads(payload["messages"][1]["content"])
                    truncated = (review_input["candidate"]["reasoning"].endswith("101")
                                 and review_input["criterion"]["id"] == "query_fidelity")
                    body = {"choices": [{"index": 0, "message": {"content": "Saved synthetic review."},
                                        "finish_reason": "length" if truncated else "stop"}],
                            "usage": {"prompt_tokens": tokens, "completion_tokens": 8, "total_tokens": tokens + 8}}
                else:
                    tokens = len(payload["prompt"])
                    body = {"choices": [{"index": 0, "text": "A", "finish_reason": "length",
                        "logprobs": {"tokens": ["token_id:65"], "top_logprobs": [
                            {"token_id:" + str(tid): math.log(.04) for tid in payload["logprob_token_ids"]}]}}],
                        "usage": {"prompt_tokens": tokens, "completion_tokens": 1, "total_tokens": tokens + 1}}
                return Response(json.dumps(body).encode())
            original = helpers.parallel.run_parallel(**args, output_dir=root / "original",
                journal_path=root / "journal.sqlite", artifact_dir=root / "http",
                execute=True, transports=(fake, fake))
            self.assertEqual(original["valid_score_records"], 17)
            self.assertEqual(len(calls), 35)  # One read is deliberately ineligible after review length.
            # Emulate the old coordinator's local race-loss placeholder. The
            # authoritative journal remains complete; the booster never edits it.
            old_local = root / "original" / "score_records.jsonl"
            old_local.write_text('{"status":"INVALID","error_code":"old_local_duplicate"}\n', encoding="utf-8")
            before = old_local.read_bytes()
            def forbidden_network(request, timeout):
                raise AssertionError("Completed batch must never POST again")
            result = boost.run_boost(candidates=candidates, raw_rows=raw, original_requests=requests,
                manifest=args["manifest"], rubrics=args["rubrics"], config=args["config"],
                original_run=root / "original", tokenizers=[helpers.ToyTokenizer() for _ in range(6)],
                endpoints=args["endpoints"], capabilities=args["capabilities"],
                journal_path=root / "journal.sqlite", artifact_dir=root / "http",
                output_dir=root / "boost", max_seconds=args["max_seconds"], wait_seconds=1,
                execute=True, transports=(forbidden_network, forbidden_network))
            self.assertEqual(result["status"], "NO_NEW_WORK")
            self.assertEqual(result["valid_score_records"], 17)
            self.assertEqual(result["criterion_records"], 18)
            self.assertEqual(result["added_transport_dispatches_marked"], 0)
            self.assertEqual(result["client_accounting"]["reserved_request_identities"], 35)
            self.assertEqual(result["remaining"]["remaining_request_budget"], 1)
            self.assertEqual(result["actual_eligible_score_identity_count"], 17)
            self.assertEqual(result["missing_legitimate_request_ids"], [])
            self.assertEqual(old_local.read_bytes(), before)
            self.assertEqual(len(calls), 35)


if __name__ == "__main__":
    unittest.main()
