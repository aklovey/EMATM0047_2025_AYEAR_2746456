"""Synthetic, offline calibration protocol tests; not project accuracy evidence."""
import copy
import importlib.util
import json
import math
import sys
import tempfile
import unittest
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "src"))
spec = importlib.util.spec_from_file_location("calibrate_verifier", PACKAGE / "scripts" / "calibrate_verifier.py")
cal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cal)
from cause_verifier.core import CRITERIA, LABELS, content_hash, score_distribution


PARAMS = dict(thresholds=[.5, .8, .95], max_fpr=.2, min_tpr=.7,
              confidence=.9, min_positive=20, min_negative=20)


def synthetic(root, dev=60, heldout=60, repeated_eval_question=False):
    """Create independently bound fixed-test evidence, all explicitly synthetic."""
    candidates, scores, labels, dev_tasks, eval_tasks = [], [], [], [], []
    root.mkdir(parents=True, exist_ok=True)
    evidence = root / "evidence"
    evidence.mkdir()
    for i in range(dev + heldout):
        q = i if not repeated_eval_question or i < dev else dev + (i - dev) // 2
        task = {"messages": [{"role": "user", "content": "SYNTHETIC UNIT TEST QUESTION " + str(q)}]}
        task_id = "task_" + content_hash(task)[:20]
        candidate = {"candidate_id": "synthetic-" + str(i), "task_id": task_id, "task": task,
                     "rollout": {"reasoning": "synthetic chain " + str(i), "final_content": str(i % 2)}}
        candidates.append(candidate)
        (dev_tasks if i < dev else eval_tasks).append(task_id)
        label = "pass" if i % 2 == 0 else "fail"
        expected = .9 if label == "pass" else .2
        sidecar = {"candidate_id": candidate["candidate_id"], "task_id": task_id,
                   "candidate_hash": content_hash(candidate["rollout"]), "criteria": {}}
        for criterion in CRITERIA:
            mapping = {letter: [{"token_id": index, "text": letter}] for index, letter in enumerate(LABELS)}
            logprobs = [{"token_id": index, "logprob": math.log(expected) if index == 0 else
                        math.log(1 - expected) if index == 19 else -math.inf} for index in range(20)]
            scores.append(score_distribution(mapping, logprobs, prompt_hash="synthetic-prefix",
                score_position=0, position_verified=True, tokenization_verified=True,
                candidate_id=candidate["candidate_id"], candidate_hash=content_hash(candidate["rollout"]),
                criterion=criterion).to_dict())
            record = {"candidate_id": candidate["candidate_id"], "task_id": task_id,
                "candidate_hash": content_hash(candidate["rollout"]), "criterion": criterion, "label": label,
                "source_kind": "independent_executable_check", "source_id": "SYNTHETIC_TEST_CHECKER_ONLY",
                "scope": cal.SCOPE, "model_generated": False, "verifier_scores_used": False,
                "result": {"synthetic_test": True, "expected_fixed_fixture_label": label}}
            record["result_hash"] = content_hash(record["result"])
            path = evidence / f"{i}-{criterion}.json"
            path.write_text(json.dumps(record), encoding="utf-8")
            sidecar["criteria"][criterion] = {key: record[key] for key in
                ("label", "source_kind", "source_id", "scope", "model_generated", "verifier_scores_used")}
            sidecar["criteria"][criterion]["evidence_refs"] = [{"path": path.name, "sha256": cal.sha(path)}]
        labels.append(sidecar)
    split = {"dev_task_ids": list(dict.fromkeys(dev_tasks)), "eval_task_ids": list(dict.fromkeys(eval_tasks))}
    paths = {}
    for name, value in (("candidate", candidates), ("score", scores), ("label", labels)):
        path = root / (name + ".jsonl")
        path.write_text("".join(json.dumps(row, allow_nan=False) + "\n" for row in value), encoding="utf-8")
        paths[name + "_path"] = path
    paths["split_path"] = root / "split.json"
    paths["split_path"].write_text(json.dumps(split), encoding="utf-8")
    paths["evidence_root"] = evidence
    return paths, candidates, scores, labels, split


class CalibrationTests(unittest.TestCase):
    def test_exact_binomial_boundary_and_nonzero_error_cases(self):
        self.assertAlmostEqual(cal.binomial_upper(0, 1, .05), .95)
        self.assertAlmostEqual(cal.binomial_upper(1, 2, .05), math.sqrt(.95))
        self.assertAlmostEqual(cal.binomial_lower(1, 2, .05), 1 - math.sqrt(.95))
        self.assertEqual(cal.binomial_upper(5, 5, .05), 1)
        self.assertIsNone(cal.binomial_upper(0, 0, .05))
        self.assertAlmostEqual(cal.binomial_upper(0, 30, .1 / 6), 1 - (.1 / 6) ** (1 / 30))

    def test_real_file_evidence_pipeline_can_produce_only_disabled_gate_candidate(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths, *_ = synthetic(Path(temporary))
            result = cal.run_calibration(**paths, calibration_id="synthetic-calibration", **PARAMS)
            self.assertEqual(result["status"], "CALIBRATION_GATE_CANDIDATE", result.get("reason"))
            self.assertFalse(result["acceptance_enabled"])
            self.assertEqual(result["model_requests"], 0)
            self.assertEqual(result["calibration_gate_candidate"]["thresholds"], {criterion: .5 for criterion in CRITERIA})
            self.assertFalse(result["calibration_gate_candidate"]["acceptance_enabled"])
            self.assertEqual(result["counts"]["verified_evidence_file_references"], 360)

    def test_zero_empirical_fpr_is_not_sufficient_under_tight_risk_goal(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths, *_ = synthetic(Path(temporary))
            targets = dict(PARAMS, max_fpr=.05)
            result = cal.run_calibration(**paths, calibration_id="synthetic", **targets)
            self.assertEqual(result["status"], "CALIBRATION_REJECTED")
            self.assertIsNone(result["calibration_gate_candidate"])
            for criterion in CRITERIA:
                heldout = result["evaluation"]["per_criterion"][criterion]["heldout"]
                self.assertEqual(heldout["FPR"], 0)
                self.assertGreater(heldout["FPR_one_sided_exact_upper"], .05)

    def test_insufficient_heldout_labels_are_explicitly_not_run(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths, *_ = synthetic(Path(temporary), heldout=10)
            result = cal.run_calibration(**paths, calibration_id="synthetic", **PARAMS)
            self.assertEqual(result["status"], "NOT_RUN")
            self.assertIsNone(result["calibration_gate_candidate"])
            self.assertIn("insufficient", result["reason"])

    def test_same_question_candidates_cannot_inflate_independent_heldout_count(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths, *_ = synthetic(Path(temporary), repeated_eval_question=True)
            result = cal.run_calibration(**paths, calibration_id="synthetic", **PARAMS)
            self.assertEqual(result["status"], "CALIBRATION_REJECTED")
            self.assertFalse(result["counts"]["heldout_single_candidate_per_question"])
            heldout = result["evaluation"]["per_criterion"]["query_fidelity"]["heldout"]
            self.assertIsNone(heldout["FPR_one_sided_exact_upper"])

    def test_answer_only_model_labels_missing_provenance_and_hash_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths, candidates, scores, labels, split = synthetic(Path(temporary))
            for field, value in (("source_kind", "answer_only"), ("source_kind", "llm_judge"),
                                 ("model_generated", True), ("evidence_refs", [])):
                changed = copy.deepcopy(labels)
                changed[0]["criteria"]["query_fidelity"][field] = value
                with self.assertRaises(cal.NotRun):
                    cal.load_dataset(candidates, scores, changed, split, paths["evidence_root"])
            changed = copy.deepcopy(labels)
            changed[0]["criteria"]["query_fidelity"]["evidence_refs"][0]["sha256"] = "0" * 64
            with self.assertRaises(cal.NotRun):
                cal.load_dataset(candidates, scores, changed, split, paths["evidence_root"])

    def test_dev_size_split_leakage_and_swapped_full_candidate_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths, candidates, scores, labels, split = synthetic(Path(temporary), dev=49)
            with self.assertRaisesRegex(cal.NotRun, "50-100"):
                cal.load_dataset(candidates, scores, labels, split, paths["evidence_root"])
        with tempfile.TemporaryDirectory() as temporary:
            paths, candidates, scores, labels, split = synthetic(Path(temporary))
            leaking = copy.deepcopy(split)
            leaking["eval_task_ids"].append(split["dev_task_ids"][0])
            with self.assertRaisesRegex(cal.NotRun, "both"):
                cal.load_dataset(candidates, scores, labels, leaking, paths["evidence_root"])
            changed = copy.deepcopy(candidates)
            changed[0]["rollout"]["reasoning"] = "another unscored chain"
            with self.assertRaises(cal.NotRun):
                cal.load_dataset(changed, scores, labels, split, paths["evidence_root"])

    def test_unknown_labels_and_score_abstentions_not_forced_into_confusion_truth(self):
        rows = [{"label": "unknown", "score": .99}, {"label": "pass", "score": None},
                {"label": "fail", "score": None}, {"label": "pass", "score": .9},
                {"label": "fail", "score": .1}]
        values = cal.confusion(rows, .5)
        self.assertEqual(values["unknown_labels"], 1)
        self.assertEqual(values["unknown_scores"], 2)
        self.assertEqual(values["positive_score_abstentions"], 1)
        self.assertEqual(values["TPR"], 1)
        self.assertEqual(values["operational_acceptance_TPR"], .5)
        self.assertEqual(values["FP"] + values["TN"] + values["TP"] + values["FN"], 2)

    def test_heldout_failure_never_changes_development_thresholds(self):
        rows = [{"label": label, "score": score} for _ in range(30)
                for label, score in (("pass", .9), ("fail", .2))]
        dataset = {part: {criterion: copy.deepcopy(rows) for criterion in CRITERIA} for part in ("dev", "eval")}
        first = cal.evaluate(dataset, **PARAMS)
        for row in dataset["eval"]["query_fidelity"]:
            row["score"] = 1 - row["score"]
        second = cal.evaluate(dataset, **PARAMS)
        self.assertEqual(first["selected_thresholds"], second["selected_thresholds"])
        self.assertFalse(second["gate_candidate_eligible"])
        self.assertTrue(second["per_criterion"]["derivation_validity"]["heldout"]["independent_heldout_risk_and_sensitivity_goals_met"])

    def test_missing_inputs_are_not_run_and_plan_never_claims_calibration(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            result = cal.run_calibration(candidate_path=root / "missing", score_path=root / "missing",
                label_path=root / "missing", split_path=root / "missing", evidence_root=root,
                calibration_id="not-run", **PARAMS)
            self.assertEqual(result["status"], "NOT_RUN")
            self.assertIsNone(result["calibration_gate_candidate"])
        plan = cal.make_plan({"frozen_raw_rollout_count": 42}, **PARAMS)
        self.assertEqual(plan["status"], "NOT_RUN")
        self.assertEqual(plan["existing_pool_candidates"], 42)
        self.assertFalse(plan["existing_answer_only_labels_usable_as_criterion_truth"])
        self.assertEqual(plan["model_requests"], 0)


if __name__ == "__main__":
    unittest.main()
