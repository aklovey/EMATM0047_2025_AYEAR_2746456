import io
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch
import urllib.error

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cause_verifier.client import (
    BudgetExceeded, BudgetLimit, DuplicateRequestError, JournaledClient,
    logprob_items, phase_completion,
)


class Response(io.BytesIO):
    status = 200


class ClientTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.calls = []

    def tearDown(self):
        self.temp.cleanup()

    def client(self, *, transport=None, limits=None, **kwargs):
        def send(req, timeout):
            self.calls.append(req)
            with closing(sqlite3.connect(self.root / "journal.sqlite")) as db, db:
                self.assertEqual(db.execute("SELECT status FROM requests").fetchone()[0], "RESERVED")
            return Response(json.dumps({"choices": [{"finish_reason": "length"}],
                "usage": {"prompt_tokens": 2, "completion_tokens": 1, "total_tokens": 3}}).encode())
        return JournaledClient("http://127.0.0.1:8000", self.root / "journal.sqlite",
            self.root / "raw", limits=limits or {"global": BudgetLimit(20, 1000, 100)},
            transport=transport or send, **kwargs)

    def post(self, client, identity="one", **kwargs):
        return client.post("/v1/completions", {"model": "local", "prompt": [1, 2],
            "max_tokens": 1}, request_id=identity, stage=kwargs.get("stage", "score_read"),
            qid=kwargs.get("qid", "q1"), candidate_id=kwargs.get("candidate_id", "c1"),
            prompt_tokens=2)

    def test_reserved_before_send_raw_response_saved_and_duplicate_rejected(self):
        client = self.client()
        record = self.post(client)
        self.assertEqual(record.status, "OK")
        self.assertEqual(record.actual_total_tokens, 3)
        self.assertTrue(Path(record.raw_response_path).read_bytes())
        with self.assertRaises(DuplicateRequestError):
            self.post(client)
        self.assertEqual(len(self.calls), 1)

    def test_transport_failure_is_consumed_and_not_retried(self):
        def failure(req, timeout):
            self.calls.append(req)
            raise urllib.error.URLError("do not leak secret-key")
        client = self.client(transport=failure)
        record = self.post(client)
        self.assertEqual(record.status, "TRANSPORT_ERROR")
        self.assertNotIn("secret-key", record.error)
        with self.assertRaises(DuplicateRequestError):
            self.post(client)
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(client.summary()["usage_unknown_requests"], 1)
        self.assertEqual(client.summary()["network_outcome_unknown"], 1)
        self.assertIsNone(client.summary()["actual_http_count"])

    def test_reservation_survives_new_client(self):
        self.post(self.client())
        with self.assertRaises(DuplicateRequestError):
            self.post(self.client())

    def test_http_error_body_preserved_without_retry(self):
        def fail(req, timeout):
            self.calls.append(req)
            raise urllib.error.HTTPError(req.full_url, 503, "busy", {}, io.BytesIO(b'{"error":"busy"}'))
        record = self.post(self.client(transport=fail))
        self.assertEqual(record.status, "HTTP_ERROR")
        self.assertEqual(record.response["error"], "busy")
        self.assertEqual(Path(record.raw_response_path).read_bytes(), b'{"error":"busy"}')
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.client().summary()["confirmed_http_responses"], 1)

    def test_payload_artifact_failure_is_not_counted_as_http(self):
        client = self.client()
        with patch("cause_verifier.client._write_new", side_effect=OSError("disk full")):
            record = self.post(client)
        self.assertEqual(record.status, "RECORDING_ERROR")
        self.assertFalse(record.transport_attempted)
        self.assertEqual(client.summary()["reserved_request_identities"], 1)
        self.assertEqual(client.summary()["reserved_not_dispatched"], 1)
        self.assertEqual(client.summary()["actual_http_count"], 0)
        self.assertEqual(self.calls, [])

    def test_batched_prompts_and_dual_token_caps_fail_before_reservation(self):
        client = self.client()
        payloads = [{"prompt": ["first", "second"], "max_tokens": 1},
            {"prompt": [[1, 2], [3, 4]], "max_tokens": 1},
            {"prompt": [True], "max_tokens": 1},
            {"prompt": [1, 2], "max_tokens": 1, "max_completion_tokens": 100},
            {"prompt": [1, 2], "max_tokens": 1, "max_completion_tokens": 1}]
        for payload in payloads:
            with self.assertRaises(ValueError):
                client.post("/v1/completions", payload, request_id="bad", stage="score_read",
                    qid="q1", candidate_id="c1", prompt_tokens=2)
        self.assertEqual(client.summary()["reserved_request_identities"], 0)
        self.assertEqual(self.calls, [])

    def test_dispatch_marker_precedes_transport(self):
        def send(req, timeout):
            with closing(sqlite3.connect(self.root / "journal.sqlite")) as db, db:
                attempted, received = db.execute("SELECT transport_attempted_at,response_received_at FROM requests").fetchone()
            self.assertIsNotNone(attempted)
            self.assertIsNone(received)
            return Response(b'{}')
        record = self.post(self.client(transport=send))
        self.assertTrue(record.transport_attempted)
        self.assertTrue(record.response_received)
        self.assertTrue(record.response_complete)

    def test_requests_global_and_stage_budgets(self):
        client = self.client(limits={"global": BudgetLimit(2, 100, 100),
            "stage:score_read": BudgetLimit(1, 100, 100)})
        self.post(client)
        with self.assertRaises(BudgetExceeded):
            self.post(client, "two")
        self.post(client, "two", stage="review")
        with self.assertRaises(BudgetExceeded):
            self.post(client, "three", stage="review")
        self.assertEqual(len(self.calls), 2)

    def test_qid_and_candidate_scopes_independent(self):
        client = self.client(limits={"global": BudgetLimit(20, 100, 100),
            "qid:q1": BudgetLimit(1, 100, 100),
            "candidate:q2:c1": BudgetLimit(1, 100, 100)})
        self.post(client)
        with self.assertRaises(BudgetExceeded):
            self.post(client, "two", candidate_id="c2")
        self.post(client, "two", qid="q2")
        with self.assertRaises(BudgetExceeded):
            self.post(client, "three", qid="q2")
        self.post(client, "three", qid="q2", candidate_id="c2")

    def test_token_reservation_budget_stops_before_send(self):
        client = self.client(limits={"global": BudgetLimit(20, 5, 100)})
        self.post(client)
        with self.assertRaises(BudgetExceeded):
            self.post(client, "two")
        self.assertEqual(len(self.calls), 1)

    def test_elapsed_time_budget_persists(self):
        client = self.client(limits={"global": BudgetLimit(20, 100, 1)})
        self.post(client)
        with closing(sqlite3.connect(self.root / "journal.sqlite")) as db, db:
            db.execute("UPDATE requests SET reserved_at=reserved_at-10")
        with self.assertRaises(BudgetExceeded):
            self.post(client, "two")

    def test_missing_usage_stays_unknown(self):
        record = self.post(self.client(transport=lambda req, timeout: Response(b'{}')))
        self.assertIsNone(record.usage)
        self.assertIsNone(record.actual_total_tokens)

    def test_nonlocal_allowlist_and_ambient_credentials_not_permitted(self):
        for endpoint in ("https://api.openai.com", "http://192.168.1.2:8000", "http://u:p@127.0.0.1:8000"):
            with self.assertRaises(ValueError):
                JournaledClient(endpoint, self.root / "x", self.root / "raw",
                    allowed_endpoints=[endpoint], limits={"global": BudgetLimit(1, 1, 1)})
        with self.assertRaises(ValueError):
            JournaledClient("http://127.0.0.1:8001", self.root / "x", self.root / "raw",
                limits={"global": BudgetLimit(1, 1, 1)})

    def test_auth_not_written_to_artifacts(self):
        client = self.client(api_key="test-private-secret")
        record = self.post(client)
        self.assertEqual(self.calls[0].headers["Authorization"], "Bearer test-private-secret")
        for path in (Path(record.request_path), self.root / "journal.sqlite"):
            self.assertNotIn(b"test-private-secret", path.read_bytes())

    def test_invalid_json_response_keeps_raw_bytes(self):
        record = self.post(self.client(transport=lambda req, timeout: Response(b'not json')))
        self.assertEqual(record.status, "INVALID_RESPONSE")
        self.assertEqual(Path(record.raw_response_path).read_bytes(), b'not json')

    def test_usage_overrun_does_not_enter_valid_results(self):
        raw = b'{"usage":{"total_tokens":99},"choices":[]}'
        record = self.post(self.client(transport=lambda req, timeout: Response(raw)))
        self.assertEqual(record.status, "TOKEN_RESERVATION_OVERRUN")

    def test_stage_specific_length_classification(self):
        self.assertEqual(phase_completion("score_read", "length", distribution_complete=True), "COMPLETE_SCORE_READ")
        self.assertEqual(phase_completion("review", "length", distribution_complete=True), "TRUNCATED")
        self.assertEqual(phase_completion("rollout", "length"), "TRUNCATED")
        self.assertEqual(phase_completion("score_read", "length"), "TRUNCATED")

    def test_sampled_extra_id_kept_and_duplicates_deduplicated(self):
        body = {"choices": [{"logprobs": {"top_logprobs": [{"token_id:1": -1., "token_id:99": -2.}],
                "tokens": ["token_id:99"], "token_logprobs": [-2.]}}]}
        self.assertEqual({x["token_id"] for x in logprob_items(body, protocol="completion")}, {1, 99})

    def test_chat_reasoning_field_not_used_as_fake_distribution(self):
        body = {"choices": [{"message": {"reasoning": "A"}, "logprobs": None}]}
        with self.assertRaises(ValueError):
            logprob_items(body, protocol="chat")

    def test_text_token_and_conflicting_duplicates_rejected(self):
        body = {"choices": [{"logprobs": {"content": [{"token": "A", "logprob": -.1,
                "top_logprobs": []}]}}]}
        with self.assertRaises(ValueError):
            logprob_items(body, protocol="chat")
        pos = body["choices"][0]["logprobs"]["content"][0]
        pos.update(token="token_id:1", top_logprobs=[{"token":"token_id:1", "logprob":-.2}])
        with self.assertRaises(ValueError):
            logprob_items(body, protocol="chat")


if __name__ == "__main__":
    unittest.main()
