import copy
import json
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cause_verifier.core import (
    LABELS, LABEL_VALUES, CRITERIA, CalibrationGate, Candidate, HardCheck,
    RolloutLedger, TokenVariant, build_cache_key, build_pairwise_orders,
    check_raw_score_stability, choose_candidate, content_hash,
    count_independent_reviews, remap_pairwise_result, score_distribution,
    score_rollout, stage_status, verify_rollout,
)


def fixture(probabilities=None):
    variants = {label: [TokenVariant(i, label)] for i, label in enumerate(LABELS)}
    probabilities = probabilities or [0.04] * 20
    observed = [{"token_id": i, "logprob": math.log(p) if p else -math.inf, "text": label}
                for i, (label, p) in enumerate(zip(LABELS, probabilities))]
    return dict(label_tokens=variants, observed_logprobs=observed,
                prompt_hash="frozen-score-prefix", score_position=0,
                position_verified=True, tokenization_verified=True,
                review_seed=17, review_id="review-17", read_id="read-1",
                candidate_id="candidate-1", candidate_hash=content_hash("new text"), criterion="query_fidelity")


def score_at(probabilities):
    return score_distribution(**fixture(probabilities))


def all_scores(probabilities=None, candidate_id="good", rollout="new text"):
    result = {}
    for criterion in CRITERIA:
        kwargs = fixture(probabilities)
        kwargs["criterion"] = criterion
        kwargs["candidate_id"] = candidate_id
        kwargs["candidate_hash"] = content_hash(rollout)
        result[criterion] = score_distribution(**kwargs)
    return result


def verified(probabilities=None, candidate_id="good", rollout="new text"):
    return verify_rollout(all_scores(probabilities, candidate_id, rollout),
                          [HardCheck("independent arithmetic", "pass", ("tool-run-1",))],
                          task_information_sufficient=True)


def calibration():
    return CalibrationGate({key: 0.7 for key in CRITERIA}, "dev-calibration-1", True, True,
                           "sha256:calibration-artifact", ("independent-label-dataset",))


def cache_context():
    return dict(model_id="qwen-local", model_revision="weight-manifest-v1",
                tokenizer_hash="tokenizer-v1", template_hash="template-v1",
                task={"text": "original task"}, candidate="candidate full text",
                evidence=[{"tool_run_id": "run1", "result_hash": "abc"}],
                criteria_version="v1", criterion="query_fidelity",
                scoring_mode="raw_logprobs", review_seed=17,
                sampling_parameters={"review": {"max_tokens": 2048},
                                     "score_read": {"temperature": 1.0, "max_tokens": 1}},
                score_prompt_hash="prefix-v1", label_map_hash="tokens-v1")


class DistributionTests(unittest.TestCase):
    def test_mapping_direction_and_known_mixture(self):
        self.assertEqual(LABEL_VALUES["A"], 1)
        self.assertEqual(LABEL_VALUES["T"], 0)
        probabilities = [0.0] * 20
        probabilities[0], probabilities[19] = 0.6, 0.2
        record = score_at(probabilities)
        self.assertEqual(record.status, "VALID")
        self.assertAlmostEqual(record.score, 0.75)
        self.assertAlmostEqual(record.score_mass, 0.8)
        self.assertEqual(record.discrete_score, 1)

    def test_true_uniform_half_is_valid_but_upstream_fallback_is_not(self):
        record = score_distribution(**fixture())
        self.assertEqual(record.status, "VALID")
        self.assertAlmostEqual(record.score, 0.5)
        kwargs = fixture()
        kwargs["source"] = "upstream_fallback_0.5"
        invalid = score_distribution(**kwargs)
        self.assertEqual(invalid.status, "INVALID")
        self.assertIsNone(invalid.score)

    def test_same_grade_unique_variants_sum_and_duplicate_ids_do_not_sum_twice(self):
        kwargs = fixture([0.02] * 20)
        kwargs["label_tokens"]["A"] += [TokenVariant(100, " A"), TokenVariant(100, " A")]
        extra = {"token_id": 100, "logprob": math.log(0.2), "text": " A"}
        kwargs["observed_logprobs"] += [extra, dict(extra)]
        record = score_distribution(**kwargs)
        self.assertEqual(record.status, "VALID", record.error_detail)
        self.assertAlmostEqual(record.labels["A"]["probability"], 0.22)
        self.assertAlmostEqual(record.score_mass, 0.6)
        self.assertAlmostEqual(record.score, (0.2 + 0.4 * 0.5) / 0.6)

    def test_token_id_shared_between_grades_is_rejected(self):
        kwargs = fixture()
        kwargs["label_tokens"]["B"] = [TokenVariant(0, "B")]
        record = score_distribution(**kwargs)
        self.assertEqual(record.error_code, "cross_label_token_conflict")

    def test_top_twenty_does_not_guarantee_twenty_grades(self):
        kwargs = fixture()
        kwargs["observed_logprobs"][-1] = {"token_id": 999, "logprob": math.log(0.04), "text": "other"}
        record = score_distribution(**kwargs)
        self.assertEqual(record.error_code, "incomplete_distribution")
        self.assertEqual(record.missing_labels, ["T"])
        self.assertEqual(record.missing_token_ids, [19])

    def test_missing_same_grade_variant_invalidates_complete_grade_set(self):
        kwargs = fixture()
        kwargs["label_tokens"]["A"].append(TokenVariant(100, " A"))
        record = score_distribution(**kwargs)
        self.assertEqual(record.error_code, "incomplete_distribution")
        self.assertEqual(record.missing_token_ids, [100])

    def test_absent_distribution_and_missing_tag_rejected(self):
        kwargs = fixture()
        kwargs["observed_logprobs"] = None
        self.assertEqual(score_distribution(**kwargs).error_code, "missing_logprobs")
        kwargs = fixture()
        del kwargs["label_tokens"]["T"]
        self.assertEqual(score_distribution(**kwargs).error_code, "invalid_label_set")

    def test_nan_positive_infinity_positive_logprob_rejected(self):
        for bad in (math.nan, math.inf, 0.01, True, "-2"):
            with self.subTest(value=bad):
                kwargs = fixture()
                kwargs["observed_logprobs"][0]["logprob"] = bad
                self.assertEqual(score_distribution(**kwargs).error_code, "invalid_logprob")

    def test_conflicting_duplicate_observation_rejected(self):
        kwargs = fixture()
        kwargs["observed_logprobs"].append({"token_id": 0, "logprob": math.log(0.03)})
        self.assertEqual(score_distribution(**kwargs).error_code, "conflicting_duplicate_logprob")

    def test_whitespace_label_and_multitoken_label_rejected(self):
        for variant, code in ((TokenVariant(0, " "), "blank_label_token"),
                              (TokenVariant(0, "A", 2), "multi_token_label")):
            kwargs = fixture()
            kwargs["label_tokens"]["A"] = [variant]
            self.assertEqual(score_distribution(**kwargs).error_code, code)
        kwargs = fixture()
        kwargs["observed_logprobs"][0]["text"] = " "
        self.assertEqual(score_distribution(**kwargs).error_code, "blank_score_token")

    def test_unlocated_reasoning_score_and_position_mismatch_rejected(self):
        kwargs = fixture()
        kwargs["position_verified"] = False  # A label found only in reasoning is no score-position proof.
        self.assertEqual(score_distribution(**kwargs).error_code, "unverified_score_position")
        kwargs = fixture()
        kwargs["observed_score_position"] = 3
        self.assertEqual(score_distribution(**kwargs).error_code, "wrong_score_position")
        kwargs = fixture()
        kwargs["tokenization_verified"] = False
        self.assertEqual(score_distribution(**kwargs).error_code, "unverified_tokenization")

    def test_score_read_length_valid_review_rollout_length_invalid(self):
        self.assertEqual(score_distribution(**fixture()).status, "VALID")
        self.assertEqual(stage_status("review", "length"), "truncated_review")
        self.assertEqual(stage_status("rollout", "length"), "truncated_rollout")
        for stage in ("review", "rollout"):
            kwargs = fixture()
            kwargs["stage"] = stage
            self.assertEqual(score_distribution(**kwargs).error_code, "truncated_" + stage)
        kwargs = fixture()
        kwargs["finish_reason"] = "timeout"
        self.assertEqual(score_distribution(**kwargs).error_code, "invalid_finish_reason")

    def test_processed_distribution_cannot_be_mislabeled_raw(self):
        kwargs = fixture()
        kwargs["logprobs_mode"] = "processed_logprobs"
        self.assertEqual(score_distribution(**kwargs).error_code, "non_raw_or_fallback_source")

    def test_impossible_mass_and_true_zero_mass_rejected(self):
        self.assertEqual(score_at([0.1] * 20).error_code, "probability_mass_exceeds_one")
        self.assertEqual(score_at([0.0] * 20).error_code, "zero_score_mass")

    def test_low_mass_not_arbitrarily_rejected_and_underflow_stable(self):
        kwargs = fixture()
        for event in kwargs["observed_logprobs"]:
            event["logprob"] = -1000
        record = score_distribution(**kwargs)
        self.assertEqual(record.status, "VALID")
        self.assertAlmostEqual(record.score, 0.5)
        self.assertAlmostEqual(record.log_score_mass, -1000 + math.log(20))

    def test_zero_probability_json_is_portable_usage_unknown_retained(self):
        record = score_at([1.0] + [0.0] * 19)
        encoded = json.dumps(record.to_dict(), allow_nan=False)
        decoded = json.loads(encoded)
        self.assertEqual(decoded["labels"]["T"]["logprob"], "-Infinity")
        self.assertIsNone(decoded["usage"])

    def test_offline_score_rollout_binds_criterion_and_evidence(self):
        context = cache_context()
        record = score_rollout("task", "actual candidate", {"id": "query_fidelity", "version": "v2"},
                               ["evidence-actual"], {"score_read": fixture(), "cache_context": context})
        self.assertEqual(record.status, "VALID", record.error_detail)
        self.assertEqual(record.evidence_refs, ["evidence-actual"])
        self.assertIsNotNone(record.cache_key)
        self.assertNotEqual(record.cache_key, build_cache_key(context))


class SelectionTests(unittest.TestCase):
    def test_hard_counterexample_dominates_all_high_scores(self):
        scores = all_scores([1.0] + [0.0] * 19)
        verification = verify_rollout(scores, [HardCheck("SCM", "fail", ("counterexample-1",))],
                                      task_information_sufficient=True)
        self.assertEqual(verification.status, "fail")
        self.assertEqual(set(verification.criterion_scores), set(CRITERIA))
        result = choose_candidate("parent", "full parent", [Candidate("wrong", "wrong candidate", verification, 999)],
                                  mode="acceptance", calibration=calibration())
        self.assertFalse(result.accepted)
        self.assertEqual(result.selected_rollout, "full parent")

    def test_unknown_preserved_when_task_or_checks_or_criterion_missing(self):
        scores = all_scores()
        hard = [HardCheck("arithmetic", "pass", ("tool-run",))]
        self.assertEqual(verify_rollout(scores, hard).status, "unknown")
        self.assertEqual(verify_rollout(scores, task_information_sufficient=True).status, "unknown")
        del scores["query_fidelity"]
        self.assertEqual(verify_rollout(scores, hard, task_information_sufficient=True).status, "unknown")
        with self.assertRaises(ValueError):
            HardCheck("model says yes", "pass")

    def test_rollout_truncation_cannot_be_hidden_by_valid_score_read(self):
        outcome = verify_rollout(all_scores(), [HardCheck("format", "pass", ("tool-run",))],
                                 task_information_sufficient=True, rollout_finish_reason="length")
        self.assertEqual(outcome.status, "unknown")

    def test_default_shadow_keeps_parent_and_calibration_required(self):
        candidate = Candidate("good", "new text", verified([1.0] + [0.0] * 19), 100)
        for mode in ("shadow", "acceptance"):
            result = choose_candidate("parent", "unchanged parent", [candidate], mode=mode)
            self.assertFalse(result.accepted)
            self.assertEqual(result.selected_rollout, "unchanged parent")
        result = choose_candidate("parent", "unchanged parent", [candidate], calibration=calibration())
        self.assertEqual(result.mode, "shadow")
        self.assertEqual(result.recommended_id, "good")
        self.assertEqual(result.selected_id, "parent")

    def test_acceptance_quality_before_objective_without_criterion_average(self):
        good = Candidate("good", "long good", verified([1.0] + [0.0] * 19, rollout="long good"), 5)
        bad_verification = verified([1.0] + [0.0] * 19, candidate_id="bad", rollout="short but query changed")
        bad_verification.criterion_scores["query_fidelity"] = all_scores([0.0] * 19 + [1.0], "bad", "short but query changed")["query_fidelity"]
        bad = Candidate("bad", "short but query changed", bad_verification, 1000)
        result = choose_candidate("parent", "parent", [bad, good], mode="acceptance", calibration=calibration())
        self.assertTrue(result.accepted)
        self.assertEqual(result.selected_id, "good")
        self.assertIn("bad", result.rejected)
        self.assertEqual(result.rejected["bad"], "At least one separate criterion quality gate failed")

    def test_wrong_criterion_and_candidate_body_cannot_reuse_good_scores(self):
        scores = all_scores([1.0] + [0.0] * 19)
        scores["derivation_validity"] = scores["query_fidelity"]
        verification = verify_rollout(scores, [HardCheck("format", "pass", ("tool-run",))],
                                      task_information_sufficient=True)
        self.assertEqual(verification.status, "unknown")
        correctly_bound = verified([1.0] + [0.0] * 19)
        for wrong_id, wrong_text in (("different-id", "new text"), ("good", "changed unseen text")):
            candidate = Candidate(wrong_id, wrong_text, correctly_bound, 10)
            decision = choose_candidate("parent", "original", [candidate], mode="acceptance", calibration=calibration())
            self.assertFalse(decision.accepted)
            self.assertEqual(decision.selected_rollout, "original")

    def test_uncalibrated_labels_or_leaking_split_disable_acceptance(self):
        good = Candidate("good", "new", verified([1.0] + [0.0] * 19), 1)
        for independent, split in ((False, True), (True, False)):
            gate = CalibrationGate(calibration().thresholds, "id", independent, split, "hash", ("evidence",))
            self.assertFalse(choose_candidate("parent", "parent", [good], mode="acceptance", calibration=gate).accepted)

    def test_budget_exception_and_duplicate_ids_retain_parent(self):
        good = Candidate("good", "new", verified([1.0] + [0.0] * 19), 1)
        for kwargs in ({"budget_exhausted": True}, {"exception": "timeout"}):
            result = choose_candidate("parent", "parent", [good], mode="acceptance", calibration=calibration(), **kwargs)
            self.assertFalse(result.accepted)
        result = choose_candidate("parent", "parent", [good, good], mode="acceptance", calibration=calibration())
        self.assertFalse(result.accepted)


class IdentityAccountingTests(unittest.TestCase):
    def test_each_cache_identity_input_changes_key_and_key_order_does_not(self):
        context = cache_context()
        key = build_cache_key(context)
        self.assertEqual(key, build_cache_key(dict(reversed(list(context.items())))))
        for field in context:
            with self.subTest(field=field):
                changed = copy.deepcopy(context)
                if field == "review_seed":
                    changed[field] += 1
                elif field == "sampling_parameters":
                    changed[field]["score_read"]["temperature"] = 0.8
                elif isinstance(changed[field], str):
                    changed[field] += "-changed"
                else:
                    changed[field] = {"changed": "context"}
                self.assertNotEqual(key, build_cache_key(changed))
        for field in context:
            changed = dict(context)
            del changed[field]
            with self.assertRaises(ValueError):
                build_cache_key(changed)
        unknown = dict(context, model_revision="unknown")
        with self.assertRaises(ValueError):
            build_cache_key(unknown)

    def test_ab_ba_explicit_candidate_id_remapping(self):
        ab, ba = build_pairwise_orders("candidate-original-A", "candidate-original-B")
        first = remap_pairwise_result(ab, {"A": 0.9, "B": 0.1})
        second = remap_pairwise_result(ba, {"A": 0.2, "B": 0.8})
        self.assertEqual(first["candidate_results"]["candidate-original-A"], 0.9)
        self.assertEqual(second["candidate_results"]["candidate-original-A"], 0.8)
        self.assertEqual(second["slot_to_candidate"]["A"], "candidate-original-B")

    def test_rereading_frozen_prefix_is_not_independent_k(self):
        first = score_distribution(**fixture())
        kwargs = fixture()
        kwargs["read_id"] = "read-2"
        second = score_distribution(**kwargs)
        self.assertEqual(count_independent_reviews([first, second]), 1)
        kwargs.update(review_id="review-18", review_seed=18)
        third = score_distribution(**kwargs)
        self.assertEqual(count_independent_reviews([first, second, third]), 2)

    def test_raw_sampling_stability_is_diagnostic_and_detects_drift(self):
        first = score_distribution(**fixture())
        second = score_at([0.08] + [0.02] * 19)
        stable = check_raw_score_stability([first, first], tolerance=1e-6)
        self.assertEqual(stable["status"], "pass")
        self.assertEqual(stable["independent_votes"], 0)
        self.assertEqual(check_raw_score_stability([first, second], tolerance=1e-6)["status"], "fail")
        second.prompt_hash = "different prefix"
        self.assertEqual(check_raw_score_stability([first, second], tolerance=1e-6)["status"], "unknown")

    def test_failures_and_duplicate_content_remain_raw_samples(self):
        ledger = RolloutLedger()
        for i, status, hit in ((1, "valid", False), (2, "valid", True), (3, "truncated", False),
                               (4, "transport_failure", False), (5, "unknown", False)):
            ledger.append(dict(sample_id=str(i), decision_group_id="parent1-position2", condition="DELETE",
                               rollout="same content" if i < 3 else "partial-" + str(i), status=status, cache_hit=hit))
        counts = ledger.counts()[0]
        self.assertEqual(counts["raw_rollouts"], 5)
        self.assertEqual(counts["unique_contents"], 4)
        self.assertEqual(counts["validation_cache_hits"], 1)
        self.assertEqual(counts["statuses"]["truncated"], 1)
        with self.assertRaises(ValueError):
            ledger.append(ledger.rows[0])


if __name__ == "__main__":
    unittest.main()
