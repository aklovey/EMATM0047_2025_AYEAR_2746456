"""Controller safety under normal/optimized Python; all processes/signals mocked."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
import unittest

PACKAGE = Path(__file__).resolve().parents[1]


def run_restore(*, optimize, argv=None, starttime="original", process_group=123,
                hostname="task-host", already_stopped=False):
    tree = ast.parse((PACKAGE / "scripts/dual_service_control.py").read_text(encoding="utf-8"))
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ("require", "main")]
    module = ast.fix_missing_locations(ast.Module(body=definitions, type_ignores=[]))
    state = {"services": [{"pid": 123, "gpu": 0, "port": 8000,
                            "argv": ["owned"], "starttime": "original"}]}
    calls, saved = [], []

    class FakePath:
        def __init__(self, name): self.name = name
        def __truediv__(self, name): return FakePath(name)
        def read_text(self):
            return json.dumps({"instance": "task-host"}) if self.name == "task_identity.json" else json.dumps(state)
        def write_text(self, text): return len(text)

    def identity(pid):
        if already_stopped or calls:
            return None
        return {"argv": ["owned"] if argv is None else argv, "starttime": starttime, "state": "S"}

    namespace = {"ROOT": FakePath("root"), "STATE": FakePath("state"), "json": json,
        "socket": SimpleNamespace(gethostname=lambda: hostname),
        "base": SimpleNamespace(identity=identity, active_services=lambda: []),
        "os": SimpleNamespace(getpgid=lambda pid: process_group, killpg=lambda pid, sig: calls.append((pid, sig))),
        "signal": SimpleNamespace(SIGTERM=15), "health": lambda port: None,
        "time": SimpleNamespace(monotonic=lambda: 0, sleep=lambda seconds: None, time=lambda: 0),
        "save": lambda value: saved.append(dict(value)), "print": lambda *args: None}
    exec(compile(module, "dual_control_mock_only", "exec", optimize=optimize), namespace)
    error = None
    try:
        namespace["main"]("restore")
    except Exception as exc:
        error = exc
    return calls, saved, error


class DualControlTests(unittest.TestCase):
    def assert_rejected_without_signal(self, **kwargs):
        for optimize in (0, 1, 2):
            calls, saved, error = run_restore(optimize=optimize, **kwargs)
            self.assertEqual(calls, [], (optimize, calls))
            self.assertEqual(saved, [])
            self.assertIsInstance(error, RuntimeError)

    def test_changed_argv_rejected_even_with_optimized_python(self):
        self.assert_rejected_without_signal(argv=["unrelated-process"])

    def test_reused_pid_starttime_rejected_even_with_optimized_python(self):
        self.assert_rejected_without_signal(starttime="new-process")

    def test_wrong_process_group_rejected(self):
        self.assert_rejected_without_signal(process_group=456)

    def test_wrong_instance_rejected(self):
        self.assert_rejected_without_signal(hostname="another-instance")

    def test_exact_owned_identity_only_receives_graceful_sigterm(self):
        for optimize in (0, 1, 2):
            calls, saved, error = run_restore(optimize=optimize)
            self.assertIsNone(error)
            self.assertEqual(calls, [(123, 15)])
            self.assertEqual(saved[-1]["status"], "RESTORED_INITIAL_STOPPED_STATE")

    def test_already_stopped_process_not_signalled(self):
        calls, saved, error = run_restore(optimize=1, already_stopped=True)
        self.assertIsNone(error)
        self.assertEqual(calls, [])
        self.assertEqual(saved[-1]["status"], "RESTORED_INITIAL_STOPPED_STATE")


if __name__ == "__main__":
    unittest.main()
