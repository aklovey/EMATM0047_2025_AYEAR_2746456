import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import urllib.error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
spec = importlib.util.spec_from_file_location("official_compare_smoke", ROOT / "scripts" / "official_compare_smoke.py")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)
probe_spec = importlib.util.spec_from_file_location("probe_service_snapshot_test", ROOT / "scripts" / "probe_service.py")
probe = importlib.util.module_from_spec(probe_spec)
probe_spec.loader.exec_module(probe)
from cause_verifier.client import BudgetLimit, JournaledClient


class Response(io.BytesIO):
    status = 200


class OfficialSmokeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.calls = []

    def tearDown(self):
        self.temp.cleanup()

    def proxy(self, fail=False):
        def transport(req, timeout):
            self.calls.append(json.loads(req.data))
            if fail:
                raise urllib.error.HTTPError(req.full_url, 500, "failure", {}, io.BytesIO(b'{"error":"mock"}'))
            is_read = self.calls[-1]["max_tokens"] == 1
            body = {"choices": [{"finish_reason": "length" if is_read else "stop",
                "message": {"role": "assistant", "content": "A" if is_read else "Review"}}],
                "usage": {"prompt_tokens": 3, "completion_tokens": 1 if is_read else 2,
                          "total_tokens": 4 if is_read else 5}}
            return Response(json.dumps(body).encode())
        journal = JournaledClient("http://127.0.0.1:8000", self.root / "j.sqlite",
            self.root / "raw", limits={"global": BudgetLimit(3, 3000, 100)},
            transport=transport)
        counter = lambda payload: {"prompt_tokens": 3, "prompt_sha256": "mock-hash",
                                   "serialized_prompt": "mock-prefix"}
        return smoke.OfficialProxy(journal, "local", "test", counter,
                                   response_factory=lambda body: body)

    def review(self, proxy):
        return proxy.create(model="local", messages=[{"role": "user", "content": "mock"}],
            max_tokens=4096, logprobs=True, top_logprobs=20)

    def read(self, proxy):
        return proxy.create(model="local", messages=[{"role": "assistant", "content": "<score_A>"}],
            max_tokens=1, logprobs=True, top_logprobs=20,
            extra_body={"continue_final_message": True, "add_generation_prompt": False,
                        "structured_outputs": {"choice": ["A", " A"]}})

    def test_three_post_cap_and_2048_override_preserve_official_grammar(self):
        proxy = self.proxy()
        self.review(proxy)
        self.read(proxy)
        self.read(proxy)
        with self.assertRaises(RuntimeError):
            self.read(proxy)
        self.assertEqual([p["max_tokens"] for p in self.calls], [2048, 1, 1])
        self.assertEqual(self.calls[1]["structured_outputs"]["choice"], ["A", " A"])
        self.assertEqual(proxy.client.summary()["actual_http_count"], 3)

    def test_upstream_retry_cannot_dispatch_after_http_failure(self):
        proxy = self.proxy(fail=True)
        with self.assertRaises(RuntimeError):
            self.review(proxy)
        with self.assertRaises(RuntimeError):
            self.review(proxy)
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(len(proxy.blocked_invocations), 1)

    def test_text_and_neutral_fallbacks_are_detected(self):
        valid = {**{chr(65+i): 20-i for i in range(20)},
                 **{chr(97+i): 20-i for i in range(20)}}
        module = SimpleNamespace(SCALE={"valid_tokens": valid},
                                 _find_tag_logprobs=lambda tokens, lp, tag: lp)
        text = smoke.inspect_extraction(module, "<score_A>A</score_A>", None, None, "<score_A>")
        neutral = smoke.inspect_extraction(module, "missing", None, None, "<score_A>")
        partial = smoke.inspect_extraction(module, "", [], [("A", -.1)], "<score_A>")
        self.assertEqual(text["source"], "TEXT_DISCRETE_FALLBACK")
        self.assertEqual(neutral["source"], "DEFAULT_0_5_FALLBACK")
        self.assertFalse(partial["all_20_grades_observed"])
        self.assertFalse(partial["strict_main_result"])

    def test_wrong_commit_and_changed_installed_source_fail_closed(self):
        with self.assertRaises(ValueError):
            smoke.verify_sources(self.root, {"official_verifier_commit": "changed"})
        (self.root / "__init__.py").write_text("changed")
        with self.assertRaises(ValueError):
            smoke.verify_sources(self.root, {"official_verifier_commit": smoke.OFFICIAL_COMMIT})

    def test_source_hash_verifier_reads_actual_files(self):
        (self.root / "fixture.py").write_bytes(b"source\n")
        hashes = {"fixture.py": hashlib.sha256(b"source\n").hexdigest()}
        with patch.object(smoke, "SOURCE_HASHES", hashes):
            result = smoke.verify_sources(self.root, {"official_verifier_commit": smoke.OFFICIAL_COMMIT})
        self.assertEqual(result["status"], "PASS")

    def test_local_snapshot_recomputation_detects_file_changes(self):
        names = ("config.json", "generation_config.json", "tokenizer.json",
                 "tokenizer_config.json", "chat_template.jinja", "model.safetensors.index.json")
        for name in names:
            (self.root / name).write_bytes(b"mock config")
        shard = self.root / "model-00001-of-00001.safetensors"
        shard.write_bytes(b"mock weight bytes")
        meta = {"config_hashes": {name: probe.file_hash(self.root/name) for name in names},
            "shards": [{"name": shard.name, "bytes": shard.stat().st_size,
                        "mtime_ns": shard.stat().st_mtime_ns}]}
        fingerprint = hashlib.sha256(json.dumps(meta, sort_keys=True).encode()).hexdigest()
        exported = {"model_local_snapshot_fingerprint": fingerprint,
                    "model_revision": "UNKNOWN_HUB_REVISION_LOCAL_SNAPSHOT_" + fingerprint}
        result = probe.verify_local_snapshot(exported, self.root)
        self.assertFalse(result["hub_revision_verified"])
        (self.root / "config.json").write_bytes(b"changed config")
        with self.assertRaises(ValueError):
            probe.verify_local_snapshot(exported, self.root)

    def test_venv_python_argument_does_not_follow_interpreter_symlink(self):
        launcher = self.root / "client-env" / "bin" / "python"
        base_python = self.root / "base-python"
        original_resolve = Path.resolve
        def resolve_like_posix_symlink(path, *args, **kwargs):
            if path == launcher:
                return base_python
            return original_resolve(path, *args, **kwargs)
        with patch.object(Path, "resolve", resolve_like_posix_symlink):
            counter = smoke.LocalTemplateCounter(launcher, self.root, 16384)
        self.assertEqual(counter.python, os.path.abspath(launcher))
        self.assertNotEqual(counter.python, str(base_python))
        completed = SimpleNamespace(returncode=0, stderr="", stdout=json.dumps({
            "prompt_tokens": 2, "prompt_token_ids": [1, 2],
            "serialized_prompt": "mock", "prompt_sha256": "mock"}))
        with patch.object(smoke.subprocess, "run", return_value=completed) as run:
            counter({"messages": [], "max_tokens": 1})
        self.assertEqual(run.call_args.args[0][0], os.path.abspath(launcher))

    def test_helper_first_failure_and_stderr_survive_upstream_retry_latch(self):
        proxy = self.proxy()
        proxy.tokenizer = smoke.LocalTemplateCounter(self.root / "venv/bin/python", self.root, 16384)
        failed = SimpleNamespace(returncode=1, stdout="",
            stderr="ModuleNotFoundError: No module named 'transformers'\n")
        with patch.object(smoke.subprocess, "run", return_value=failed):
            with self.assertRaises(ValueError):
                self.review(proxy)
        with self.assertRaises(RuntimeError):
            self.review(proxy)
        self.assertEqual(len(self.calls), 0)
        self.assertEqual(proxy.first_error["completed_transport_records"], 0)
        self.assertIn("ModuleNotFoundError", proxy.first_error["tokenizer_diagnostics"][0]["stderr"])


if __name__ == "__main__":
    unittest.main()
