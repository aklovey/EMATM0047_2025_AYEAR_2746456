"""Fake dual endpoint tests with the actual SQLite journal, zero network/model calls."""
import importlib.util
import io
import json
import math
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from types import SimpleNamespace
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "src"))
spec = importlib.util.spec_from_file_location("parallel_replay", PACKAGE / "scripts" / "parallel_replay.py")
parallel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parallel)
from cause_verifier.client import BudgetExceeded, BudgetLimit, JournaledClient
from cause_verifier.core import CRITERIA, ScoreRecord, canonical_json, content_hash
from cause_verifier.scorer import ScorerConfig


class ToyTokenizer:
    def encode(self, text, add_special_tokens=False):
        return list(map(ord, text))

    def decode(self, ids, skip_special_tokens=False):
        return "".join(map(chr, ids))

    def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=False,
                            continue_final_message=False, **kwargs):
        text = "".join("<" + item["role"] + ">" + item["content"] + "\n" for item in messages)
        return text.rstrip() if continue_final_message else text + ("<assistant>" if add_generation_prompt else "")


class Response(io.BytesIO):
    status = 200


def fixture():
    candidates, raw, requests, groups = [], [], [], []
    for qid in (101, 202):
        task = {"messages": [{"role": "user", "content": "Synthetic causal question " + str(qid)}]}
        tid, cid = "task_" + content_hash(task)[:20], "candidate-" + str(qid)
        rollout = {"reasoning": "Synthetic candidate full reasoning " + str(qid), "final_content": "No."}
        candidates.append({"candidate_id": cid, "task_id": tid, "task": task, "rollout": rollout})
        raw.append({"candidate_id": cid, "task_id": tid, "question_id": qid,
            "decision_group_id": "group-" + str(qid), "candidate_hash": content_hash(rollout), "status": "valid"})
        requests.append({"candidate_id": cid, "original_request": {"state": "completed", "valid": 1,
            "finish_reason": "stop", "complete_chain": rollout["reasoning"], "final_content": rollout["final_content"]}})
        groups.append({"task_id": tid, "question_id": qid, "decision_group_id": "group-" + str(qid), "raw_sample_ids": [cid]})
    manifest = {"qid_order": [202, 101], "groups": groups, "frozen_raw_rollout_count": 2,
                "blind_payload_hash": content_hash(candidates)}
    config = ScorerConfig(model_id="mock-local", model_revision="mock-weights", tokenizer_hash="mock-tokenizer",
        template_hash="mock-template", run_id="parallel-test-001", max_model_len=10000, max_requests=12, max_tokens=120000)
    endpoints = ["http://127.0.0.1:8000", "http://127.0.0.1:8001"]
    snapshots = [{"status": "PASS", "model_revision": config.model_revision,
                  "model_local_snapshot_fingerprint": "MOCK_SNAPSHOT_NOT_MODEL_EVIDENCE"} for _ in (0, 1)]
    caps = [{"status": "PASS", "model_id": config.model_id, "model_revision": config.model_revision,
        "endpoint": endpoint, "model_local_snapshot_fingerprint": snapshots[0]["model_local_snapshot_fingerprint"],
        "tokenizer": {"tokenizer_sha256": config.tokenizer_hash, "chat_template_sha256": config.template_hash,
                      "single_token_labels": {"status": "PASS"}},
        "capabilities": {"exact_raw_completion": {"status": "PASS", "logprobs_mode": "raw_logprobs",
            "response_parser": "completion_token_id_keys_v1", "prompt_token_ids_supported": True,
            "request_fields": {"logprobs": 20, "logprob_token_ids": [], "return_tokens_as_token_ids": True},
            "evidence_refs": ["MOCK_ONLY"]}}} for endpoint in endpoints]
    rubrics = json.loads((PACKAGE / "rubrics.json").read_text(encoding="utf-8"))
    return dict(candidates=candidates, raw_rows=raw, original_requests=requests, manifest=manifest,
        rubrics=rubrics, config=config, tokenizers=[ToyTokenizer(), ToyTokenizer()],
        endpoints=endpoints, capabilities=caps, local_snapshots=snapshots, max_seconds=30)


class FakeEndpoints:
    def __init__(self, output, fail_worker_one=False):
        self.output = Path(output)
        self.lock = threading.Lock()
        self.first_reviews = threading.Barrier(2)
        self.calls, self.reviews = [], 0
        self.fail_worker_one = fail_worker_one
        self.seen_endpoints = set()

    def __call__(self, request, timeout):
        payload = json.loads(request.data)
        with self.lock:
            self.calls.append((request.full_url, payload))
        if "messages" in payload:
            first_for_endpoint = False
            with self.lock:
                if request.host not in self.seen_endpoints:
                    self.seen_endpoints.add(request.host)
                    first_for_endpoint = True
            if first_for_endpoint:
                self.first_reviews.wait(timeout=10)  # Proves two clients truly overlap.
            prompt = ToyTokenizer().apply_chat_template(payload["messages"], tokenize=False, add_generation_prompt=True)
            with self.lock:
                self.reviews += 1
            finish = "length" if self.fail_worker_one and request.host.endswith(":8001") else "stop"
            body = {"choices": [{"index": 0, "message": {"content": "Synthetic independent review."}, "finish_reason": finish}],
                    "usage": {"prompt_tokens": len(prompt), "completion_tokens": 8, "total_tokens": len(prompt) + 8}}
        else:
            assert (self.output / "global_score_preflight.json").exists()
            assert self.reviews == 6, "No score read may begin until BOTH workers finish review batches"
            assert isinstance(payload["prompt"], list)
            values = {"token_id:" + str(tid): math.log(.04) for tid in payload["logprob_token_ids"]}
            body = {"choices": [{"index": 0, "text": "A", "finish_reason": "length",
                "logprobs": {"tokens": ["token_id:65"], "top_logprobs": [values]}}],
                "usage": {"prompt_tokens": len(payload["prompt"]), "completion_tokens": 1,
                          "total_tokens": len(payload["prompt"]) + 1}}
        return Response(json.dumps(body).encode())


class ParallelTests(unittest.TestCase):
    def run_fake(self, directory, fail_worker_one=False):
        root = Path(directory)
        args = fixture()
        backend = FakeEndpoints(root / "run", fail_worker_one)
        result = parallel.run_parallel(**args, output_dir=root / "run", journal_path=root / "shared.sqlite",
            artifact_dir=root / "http", execute=True, transports=(backend, backend))
        return result, backend, args, root

    def test_two_worker_shared_full_pool_budgets_seed_identity_and_original_merge_order(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            result, backend, args, root = self.run_fake(directory)
            self.assertEqual(result["status"], "COMPLETE", result.get("barrier_error"))
            self.assertEqual(result["criterion_records"], 6)
            self.assertEqual(result["valid_score_records"], 6)
            self.assertEqual(result["maximum_observed_client_call_concurrency"], 2)
            self.assertEqual(result["client_accounting"]["reserved_request_identities"], 12)
            self.assertEqual(result["stage_limits"]["stage:verifier_review"]["max_requests"], 6)
            self.assertEqual(result["stage_limits"]["stage:verifier_score_read"]["max_requests"], 6)
            self.assertEqual(result["new_rollout_requests"], 0)
            merged = parallel.read_jsonl(root / "run" / "score_records.jsonl")
            self.assertEqual([row["candidate_id"] for row in merged], ["candidate-101"] * 3 + ["candidate-202"] * 3)
            plan = parallel.read_json(root / "run" / "parallel_plan.json")
            self.assertEqual(plan["candidate_owner"], {"candidate-101": 1, "candidate-202": 0})
            master = {row["request_id"]: row for row in plan["full_pool_preflight"]["requests"]}
            for shard in plan["worker_preflights"]:
                for row in shard["requests"]:
                    self.assertEqual(row["seed"], master[row["request_id"]]["seed"])
                    self.assertEqual(row["payload"], master[row["request_id"]]["payload"])
            with closing(sqlite3.connect(root / "shared.sqlite")) as db:
                counts = dict(db.execute("SELECT endpoint,COUNT(*) FROM requests GROUP BY endpoint"))
            self.assertEqual(counts, {endpoint: 6 for endpoint in args["endpoints"]})
            self.assertEqual(len(backend.calls), 12)

    def test_zero_score_worker_releases_global_phase_barrier_without_extra_calls(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            result, backend, args, root = self.run_fake(directory, fail_worker_one=True)
            self.assertEqual(result["status"], "COMPLETE_WITH_UNKNOWN")
            self.assertEqual(result["valid_score_records"], 3)
            self.assertEqual(result["invalid_score_records"], 3)
            self.assertEqual(len(backend.calls), 9)
            self.assertTrue((root / "run" / "global_score_preflight.json").exists())

    def test_preflight_never_creates_journal_or_contacts_endpoints(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            result = parallel.run_parallel(**fixture(), output_dir=root / "run", journal_path=root / "none.sqlite",
                artifact_dir=root / "none", execute=False)
            self.assertEqual(result["model_requests"], 0)
            self.assertEqual(result["planned_http_max"], 12)
            self.assertFalse((root / "none.sqlite").exists())

    def test_shared_sqlite_atomic_global_budget_allows_only_one_of_two_simultaneous_attempts(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            calls = []
            lock = threading.Lock()
            def transport(request, timeout):
                with lock:
                    calls.append(request.full_url)
                return Response(b'{"choices":[],"usage":{"total_tokens":2}}')
            endpoints = ["http://127.0.0.1:8000", "http://127.0.0.1:8001"]
            clients = [JournaledClient(endpoint, root / "journal.sqlite", root / "http",
                       allowed_endpoints=endpoints, limits={"global": BudgetLimit(1, 2, 30)}, transport=transport)
                       for endpoint in endpoints]
            start = threading.Barrier(2)
            def send(i):
                start.wait(timeout=10)
                try:
                    return clients[i].post("/v1/completions", {"model": "mock", "prompt": [1], "max_tokens": 1},
                        request_id="atomic-" + str(i), stage="verifier_score_read", qid="q" + str(i),
                        candidate_id="c" + str(i), prompt_tokens=1).status
                except BudgetExceeded:
                    return "BUDGET_EXCEEDED"
            with ThreadPoolExecutor(max_workers=2) as executor:
                values = list(executor.map(send, (0, 1)))
            self.assertEqual(sorted(values), ["BUDGET_EXCEEDED", "OK"])
            self.assertEqual(len(calls), 1)
            self.assertEqual(clients[0].summary()["reserved_request_identities"], 1)
            self.assertEqual(clients[1].summary()["reserved_tokens"], 2)

    def interrupted_worker(self, root, broken_last_line):
        args = fixture()
        backend = FakeEndpoints(root / "run")
        backend.first_reviews = SimpleNamespace(wait=lambda **kwargs: None)
        original = parallel.run_frozen_replay
        retained = {}

        def interrupted(**kwargs):
            output = Path(kwargs["output_dir"])
            if output.name == "worker_1" and not kwargs.get("preflight_only"):
                output.mkdir(parents=True, exist_ok=True)
                candidate = kwargs["candidates"][0]
                row = ScoreRecord("INVALID", error_code="known_partial_original",
                    candidate_id=candidate["candidate_id"], criterion="query_fidelity").to_dict()
                retained.update(row)
                data = canonical_json(row) + "\n"
                if broken_last_line:
                    data += '{"candidate_id":'
                (output / "score_records.jsonl").write_text(data, encoding="utf-8")
                raise RuntimeError("SYNTHETIC interruption while writing terminal scores")
            return original(**kwargs)

        with patch.object(parallel, "run_frozen_replay", side_effect=interrupted):
            result = parallel.run_parallel(**args, output_dir=root / "run", journal_path=root / "journal.sqlite",
                artifact_dir=root / "http", execute=True, transports=(backend, backend))
        return result, backend, retained

    def test_partial_worker_file_preserves_complete_row_fills_missing_unknown_and_saves_summary(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            result, backend, retained = self.interrupted_worker(root, broken_last_line=False)
            self.assertEqual(result["status"], "FAILED")
            self.assertEqual(result["criterion_records"], 6)
            self.assertEqual(len(backend.calls), 3)  # Only the other worker's already planned reviews.
            self.assertTrue((root / "run" / "parallel_summary.json").exists())
            merged = parallel.read_jsonl(root / "run" / "score_records.jsonl")
            self.assertEqual(merged[0], retained)
            self.assertEqual([row["recovery_status"] for row in merged[1:3]], ["UNKNOWN", "UNKNOWN"])
            self.assertEqual(result["worker_recovery"][1]["preserved_terminal_slots"], 1)
            self.assertEqual(result["worker_recovery"][1]["synthesized_unknown_slots"], 2)
            self.assertEqual(result["client_accounting"]["reserved_request_identities"], 3)

    def test_broken_last_jsonl_line_preserves_previous_complete_rows_and_never_resends(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            result, backend, retained = self.interrupted_worker(root, broken_last_line=True)
            self.assertEqual(result["status"], "FAILED")
            self.assertEqual(result["criterion_records"], 6)
            self.assertEqual(len(backend.calls), 3)
            merged = parallel.read_jsonl(root / "run" / "score_records.jsonl")
            self.assertEqual(merged[0], retained)
            recovery = result["worker_recovery"][1]
            self.assertIn("broken_jsonl_record", [item["code"] for item in recovery["issues"]])
            self.assertEqual(recovery["model_requests_during_recovery"], 0)
            self.assertEqual(len(recovery["source_files"][0]["sha256"]), 64)

    def test_complete_json_array_recovers_all_slots_despite_broken_jsonl_copy(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            root = Path(directory)
            candidate = fixture()["candidates"][0]
            original = [ScoreRecord("INVALID", error_code="preserved_" + criterion,
                candidate_id=candidate["candidate_id"], criterion=criterion).to_dict() for criterion in CRITERIA]
            (root / "score_records.json").write_text(canonical_json(original), encoding="utf-8")
            (root / "score_records.jsonl").write_text(canonical_json(original[0]) + "\n" + '{"broken":', encoding="utf-8")
            recovered, audit = parallel.recover_worker_records(root, [candidate], {"error": "interrupted JSONL"})
            self.assertEqual(recovered, original)
            self.assertEqual(audit["preserved_terminal_slots"], 3)
            self.assertEqual(audit["synthesized_unknown_slots"], 0)
            self.assertIn("broken_jsonl_record", [item["code"] for item in audit["issues"]])

    def test_shared_sqlite_schema_initialization_is_sequential_on_main_thread(self):
        with tempfile.TemporaryDirectory(dir=PACKAGE.parent) as directory:
            original_client = parallel.JournaledClient
            seen = []
            def construct(*args, **kwargs):
                seen.append(threading.get_ident())
                return original_client(*args, **kwargs)
            with patch.object(parallel, "JournaledClient", side_effect=construct):
                result, _, _, _ = self.run_fake(directory)
            self.assertEqual(result["status"], "COMPLETE")
            self.assertEqual(seen, [threading.get_ident(), threading.get_ident()])


if __name__ == "__main__":
    unittest.main()
