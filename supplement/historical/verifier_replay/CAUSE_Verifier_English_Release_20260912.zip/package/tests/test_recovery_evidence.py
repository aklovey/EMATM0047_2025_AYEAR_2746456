import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.core import content_hash
from cause_verifier.recovery_evidence import (audit_recovery_evidence, check_answer_format,
                                            check_replacement_generator, check_rollout_completion, inspect_openapi_choice)


def fixture(condition="delete", suffix="Target operation. Then finish.", finish="stop"):
    messages = [{"role": "system", "content": 'Return exactly {"answer":"yes"} or {"answer":"no"}.'},
                {"role": "user", "content": "Is the causal effect positive?"}]
    parent = "Target operation. Final conclusion."
    split = len("Target operation. ")
    segments = [{"step_index": 1, "char_start": 0, "char_end": split,
                 "text": parent[:split], "answer_exposed_prefix": False},
                {"step_index": 2, "char_start": split, "char_end": len(parent),
                 "text": parent[split:], "answer_exposed_prefix": True}]
    item = {"question_id": 1, "messages": messages, "parent_reasoning": parent,
            "segments": segments, "base_serialized_prompt": "ORIGINAL_PROMPT"}
    prefix = parent[:split] if condition == "keep" else ("Alternative operation. " if condition == "replace" else "")
    final = '{"answer":"yes"}'
    obs = {"prefix": prefix, "reasoning_suffix": suffix, "full_reasoning": prefix + suffix, "final_content": final}
    raw = {"candidate_id": "c", "question_id": 1, "task_id": "t", "decision_group_id": "g",
           "condition": condition, "target_step": 1, "rollout_index": 1, "request_key": "r",
           "candidate_hash": content_hash({"reasoning": prefix+suffix, "final_content": final}), "original_observation": obs}
    request = {"candidate_id": "c", "original_request": {"request_key": "r", "qid": 1,
               "step_index": 1, "branch": condition, "rollout": 1, "state": "completed", "valid": 1,
               "finish_reason": finish, "complete_chain": prefix+suffix, "reasoning_suffix": suffix,
               "final_content": final, "request_json": json.dumps({"prompt": "ORIGINAL_PROMPT" + prefix})}}
    return [item], [raw], [request]


class RecoveryEvidenceTests(unittest.TestCase):
    def test_literal_reappearance_never_claims_semantic_recovery(self):
        result = audit_recovery_evidence(*fixture(), run_id="test")
        record = result["records"][0]
        self.assertTrue(record["recovery"]["target_text_literal_reappears_in_suffix"])
        self.assertEqual(record["recovery"]["class"], "failed_or_unknown")
        self.assertEqual(record["recovery"]["semantic_operation_identity"], "unknown")
        self.assertIn("text overlap", record["recovery"]["reason"])

    def test_absence_does_not_prove_no_reconstruction(self):
        result = audit_recovery_evidence(*fixture(suffix="A valid-looking alternative."), run_id="test")
        self.assertEqual(result["records"][0]["recovery"]["class"], "failed_or_unknown")
        self.assertIn("does not prove", result["records"][0]["recovery"]["reason"])

    def test_keep_is_not_a_recovery_claim(self):
        result = audit_recovery_evidence(*fixture(condition="keep"), run_id="test")
        self.assertTrue(result["records"][0]["recovery"]["not_applicable"])

    def test_true_rollout_length_is_failure_even_if_record_says_completed(self):
        result = audit_recovery_evidence(*fixture(finish="length"), run_id="test")
        check = result["records"][0]["hard_checks"][0]
        self.assertEqual(check["status"], "fail")
        self.assertEqual(result["evidence"][0]["result"]["failure_kind"], "truncated_rollout")

    def test_unknown_state_is_not_known_semantic_failure(self):
        self.assertEqual(check_rollout_completion({"state": "posting"})["status"], "unknown")

    def test_format_checks_duplicate_keys_and_does_not_use_gold(self):
        messages = fixture()[0][0]["messages"]
        self.assertEqual(check_answer_format(messages, '{"answer":"yes","answer":"no"}')["status"], "fail")
        self.assertEqual(check_answer_format(messages, '{"answer":"yes"}')["status"], "pass")
        self.assertEqual(check_answer_format([], '{"answer":"yes"}')["status"], "unknown")

    def test_changed_prefix_fails_provenance_even_if_answer_is_valid(self):
        inputs, raw, original = fixture()
        original[0]["original_request"]["request_json"] = json.dumps({"prompt": "CHANGED"})
        result = audit_recovery_evidence(inputs, raw, original, run_id="test")
        self.assertEqual(next(c for c in result["records"][0]["hard_checks"] if c["name"] == "frozen_prefix_provenance")["status"], "fail")

    def test_replace_slot_and_recovery_are_independent_and_generator_unknown(self):
        result = audit_recovery_evidence(*fixture(condition="replace", suffix="Wrong mathematical claim."), run_id="test")
        legality = next(e for e in result["evidence"] if e["checker"] == "intervention_slot_legality")["result"]
        self.assertEqual(legality["status"], "unknown")
        self.assertEqual(legality["slot_shape_status"], "pass")
        self.assertEqual(result["records"][0]["recovery"]["class"], "failed_or_unknown")

    def test_tool_hashes_and_hardcheck_refs_cover_actual_inputs_results(self):
        result = audit_recovery_evidence(*fixture(), run_id="test")
        for evidence in result["evidence"]:
            self.assertEqual(evidence["input_hash"], content_hash(evidence["input"]))
            self.assertEqual(evidence["result_hash"], content_hash(evidence["result"]))
            self.assertFalse(evidence["allowed_online"])
        self.assertEqual(len(result["records"][0]["hard_checks"]), 4)

    def test_saved_generator_proves_allowed_inputs_and_exact_output(self):
        item = fixture()[0][0]
        target = item["segments"][0]
        instruction = {"task": "Generate exactly one alternative local reasoning step. Do not solve the whole problem and do not state a final yes/no answer.",
            "question_messages": item["messages"], "prior_reasoning_prefix": "", "original_step": target["text"],
            "output_contract": "Return only the replacement step text."}
        generator = {"qid": 1, "step_index": 1, "branch": "replacement_generate", "rollout": 0,
            "state": "completed", "valid": 1, "finish_reason": "stop", "replacement_text": "Alternative operation.",
            "request_json": json.dumps({"messages": [
                {"role": "system", "content": "You rewrite one local reasoning step using only the supplied question, prior prefix, and original step."},
                {"role": "user", "content": json.dumps(instruction)}]})}
        self.assertEqual(check_replacement_generator(item, target, generator, "Alternative operation.\n\n")["status"], "pass")
        self.assertEqual(check_replacement_generator(item, target, generator, "Different replacement.\n\n")["status"], "fail")
        instruction["gold_answer"] = "yes"
        body = json.loads(generator["request_json"])
        body["messages"][1]["content"] = json.dumps(instruction)
        generator["request_json"] = json.dumps(body)
        self.assertEqual(check_replacement_generator(item, target, generator, "Alternative operation.\n\n")["status"], "fail")

    def test_openapi_reference_support_is_schema_only(self):
        schema = {"openapi": "3.1.0", "components": {"schemas": {
            "ChatCompletionRequest": {"properties": {"structured_outputs": {"anyOf": [
                {"$ref": "#/components/schemas/StructuredOutputsParams"}, {"type": "null"}]}}},
            "CompletionRequest": {"properties": {}},
            "StructuredOutputsParams": {"properties": {"choice": {"type": "array", "items": {"type": "string"}}}}}}}
        result = inspect_openapi_choice(schema)
        self.assertIs(result["request_schemas"][0]["schema_advertised_choice_support"], True)
        self.assertIs(result["request_schemas"][1]["schema_advertised_choice_support"], False)
        self.assertEqual(result["request_schemas"][0]["runtime_choice_execution"], "NOT_RUN")
        self.assertFalse(result["strict_scoring_uses_choice"])

    def test_unresolved_schema_ref_is_unknown_not_unsupported(self):
        schema = {"openapi": "3.1.0", "components": {"schemas": {
            "ChatCompletionRequest": {"$ref": "#/components/schemas/Missing"}}}}
        result = inspect_openapi_choice(schema)
        self.assertEqual(result["request_schemas"][0]["schema_advertised_choice_support"], "unknown")


if __name__ == "__main__":
    unittest.main()
