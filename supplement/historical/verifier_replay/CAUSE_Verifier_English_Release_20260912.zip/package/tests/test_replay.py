import copy
import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from cause_verifier.core import LABELS, content_hash, score_distribution
from cause_verifier.evidence import run_toy_confounding_check
from cause_verifier.replay import coverage_curves, derive_paired_scores, prepare_replay_records, summarize_scores


def fixture():
    item = {"question_id": 1, "query_type": "toy", "messages": [{"role": "user", "content": "Does X cause Y?"}],
            "parent_reasoning": "first second", "gold_answer": "SECRET_GOLD", "segments": [
                {"step_index": 1, "char_start": 0, "char_end": 6, "text": "first ", "answer_exposed_prefix": False},
                {"step_index": 2, "char_start": 6, "char_end": 12, "text": "second", "answer_exposed_prefix": True}]}
    observations = []
    for condition in ("keep", "delete"):
        for trial in (1, 2):
            prefix = "first " if condition == "keep" else ""
            observations.append({"step_index": 1, "intervention": condition, "trial": trial,
                "request_key": f"q1-s001-{condition}-r{trial}", "prefix": prefix, "reasoning_suffix": "same suffix",
                "full_reasoning": prefix + "same suffix", "final_content": '{"answer":"yes"}',
                "observation_valid": trial == 1, "answer_correct": condition == "keep" and trial == 1,
                "error": None if trial == 1 else "length"})
    return item, {"question_id": 1, "observations": observations}


def score(cid, a, b):
    probs = [a, b] + [(1-a-b)/18] * 18
    tokens = {label: [{"token_id": i, "text": label}] for i, label in enumerate(LABELS)}
    events = [{"token_id": i, "text": label, "logprob": math.log(probs[i])}
              for i, label in enumerate(LABELS)]
    return score_distribution(tokens, events, prompt_hash="frozen", score_position=3,
        position_verified=True, tokenization_verified=True, candidate_id=cid,
        criterion="query_fidelity", review_id="review-" + cid, review_seed=1).to_dict()


class ReplayTests(unittest.TestCase):
    def test_no_metadata_leakage_and_invalid_samples_not_deduplicated(self):
        item, pool = fixture()
        data = prepare_replay_records([item], [pool], qids=[1])
        self.assertEqual(len(data["blind_candidates"]), 4)
        self.assertEqual(data["groups"][0]["invalid_rollouts"], 2)
        self.assertEqual(data["groups"][0]["condition_counts"], {"keep": 2, "delete": 2})
        for row in data["blind_candidates"]:
            self.assertEqual(set(row), {"candidate_id", "task_id", "task", "rollout"})
            self.assertNotIn("SECRET_GOLD", str(row))
        self.assertIsNone(data["offline_labels"][1]["answer_only_correct"])

    def test_missing_earliest_trial_cannot_change_target(self):
        item, pool = fixture()
        pool["observations"].pop(0)
        with self.assertRaises(ValueError):
            prepare_replay_records([item], [pool], qids=[1])

    def test_coverage_retains_invalid_and_never_combines_condition(self):
        item, pool = fixture()
        data = prepare_replay_records([item], [pool], qids=[1])
        result = coverage_curves(data["raw_rollouts"], data["offline_labels"])
        self.assertEqual({p["M"] for p in result["points"]}, {1, 2})
        self.assertEqual(len(result["points"]), 4)
        delete_m2 = next(p for p in result["points"] if p["condition"] == "delete" and p["M"] == 2)
        self.assertEqual(delete_m2["invalid_samples"], 1)
        self.assertIsNone(delete_m2["answer_only_coverage_at_m"])
        self.assertEqual(delete_m2["oracle_valid_at_m"], "unknown")
        with self.assertRaises(ValueError):
            coverage_curves(data["raw_rollouts"] + data["raw_rollouts"][:1], data["offline_labels"])

    def test_same_argmax_tie_split_by_expectation_and_missing_criteria_unknown(self):
        raw = [{"candidate_id": "a", "decision_group_id": "g", "status": "valid"},
               {"candidate_id": "b", "decision_group_id": "g", "status": "valid"}]
        result = summarize_scores(raw, [score("a", .40, .30), score("b", .60, .20)])
        comp = next(r for r in result["comparisons"] if r["criterion"] == "query_fidelity")
        self.assertEqual(comp["discrete"]["pairwise_tie_rate"], 1)
        self.assertEqual(comp["continuous"]["pairwise_tie_rate"], 0)
        self.assertEqual(comp["discrete"]["selected_id"], "a")
        self.assertEqual(comp["continuous"]["selected_id"], "b")
        self.assertTrue(comp["selection_changed"])
        self.assertEqual(result["joint_correctness"], "unknown")
        self.assertEqual(next(r for r in result["comparisons"] if r["criterion"] == "derivation_validity")["unknown_or_missing_samples"], 2)

    def test_reread_and_changed_cached_scalar_rejected(self):
        raw = [{"candidate_id": "a", "decision_group_id": "g", "status": "valid"}]
        record = score("a", .40, .30)
        with self.assertRaises(ValueError):
            summarize_scores(raw, [record, record])
        corrupt = copy.deepcopy(record)
        corrupt["score"] = 0
        with self.assertRaises(ValueError):
            derive_paired_scores(corrupt)

    def test_reread_cannot_be_relabelled_as_second_review_repeat(self):
        raw = [{"candidate_id": "a", "decision_group_id": "g", "status": "valid"}]
        first = score("a", .40, .30)
        reread = copy.deepcopy(first)
        reread.update(review_repeat=1, read_id="second-read-same-review")
        with self.assertRaises(ValueError):
            summarize_scores(raw, [first, reread])
        reread.update(review_id="new-review-but-same-seed")
        with self.assertRaises(ValueError):
            summarize_scores(raw, [first, reread])
        reread.update(review_seed=2)
        report = summarize_scores(raw, [first, reread])
        self.assertEqual(len([row for row in report["comparisons"] if row["criterion"] == "query_fidelity"]), 2)

    def test_scoring_another_text_under_same_candidate_id_is_rejected(self):
        raw = [{"candidate_id": "a", "decision_group_id": "g", "status": "valid",
                "candidate_hash": content_hash({"reasoning": "actual frozen candidate"})}]
        record = score("a", .40, .30)
        record["candidate_hash"] = content_hash({"reasoning": "other candidate"})
        with self.assertRaises(ValueError):
            summarize_scores(raw, [record])
        record["candidate_hash"] = raw[0]["candidate_hash"]
        summary = summarize_scores(raw, [record])
        self.assertEqual(summary["comparisons"][0]["valid_scored_samples"], 1)

    def test_fixed_scm_true_enumeration_hashes_and_scope(self):
        evidence = run_toy_confounding_check()
        self.assertEqual(evidence["status"], "pass")
        self.assertEqual(evidence["result"]["P_Y1_given_X0"], "0")
        self.assertEqual(evidence["result"]["P_Y1_do_X0"], "1/2")
        self.assertEqual(evidence["input_hash"], content_hash(evidence["inputs"]))
        self.assertEqual(evidence["result_hash"], content_hash(evidence["result"]))
        self.assertIn("not_original_project_question", evidence["scope"])


if __name__ == "__main__":
    unittest.main()
