from pathlib import Path
import json
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "integration"))
from cause_verifier_runtime_shadow import blind_rollout_observation, build_shadow_observer


class RuntimeShadowBoundaryTests(unittest.TestCase):
    def test_enabled_factory_calls_real_keyword_only_scorer_with_zero_network(self):
        from cause_verifier.client import BudgetLimit, JournaledClient
        from cause_verifier.scorer import ScorerConfig
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            row = blind_rollout_observation(task_messages=[{"role": "user", "content": "Synthetic original task"}],
                reasoning="Incomplete recorded chain", final_content="", opaque_candidate_id="a"*64,
                completed=False)
            config = ScorerConfig(model_id="test-local", model_revision="test-snapshot",
                tokenizer_hash="test-tokenizer", template_hash="test-template", run_id="factory-mock",
                max_model_len=16384, max_requests=6, max_tokens=98304)
            client = JournaledClient("http://127.0.0.1:8000", root/"http.sqlite", root/"raw",
                limits={"global": BudgetLimit(6, 98304, 300)},
                transport=lambda *a, **kw: (_ for _ in ()).throw(AssertionError("NETWORK FORBIDDEN")))
            caps = {"status": "PASS", "model_id": config.model_id, "model_revision": config.model_revision,
                "endpoint": client.endpoint, "tokenizer": {"tokenizer_sha256": config.tokenizer_hash,
                    "chat_template_sha256": config.template_hash, "single_token_labels": {"status": "PASS"}},
                "capabilities": {"exact_raw_completion": {"status": "PASS", "logprobs_mode": "raw_logprobs",
                    "response_parser": "completion_token_id_keys_v1", "prompt_token_ids_supported": True,
                    "evidence_refs": ["SYNTHETIC_TEST_CAPABILITY_NOT_MODEL_EVIDENCE"]}}}
            rubrics = json.loads((Path(__file__).resolve().parents[1]/"rubrics.json").read_text(encoding="utf-8"))
            events = []
            observer = build_shadow_observer(settings={"enabled": True, "mode": "shadow",
                "acceptance_enabled": False, "max_candidates": 1, "max_http_requests": 6,
                "max_tokens": 98304, "allowed_task_ids": [row["task_id"]]}, capabilities=caps,
                client=client, tokenizer=object(), scorer_config=config, rubrics=rubrics,
                output_dir=root/"shadow", record=events.append)
            result = observer(row)
            self.assertEqual(result["status"], "unknown")
            records = json.loads((root/"shadow"/row["candidate_id"]/"score_records.json").read_text())
            self.assertEqual(len(records), 3)
            self.assertTrue(all(record["status"] == "INVALID" for record in records))
            self.assertEqual(client.summary()["reserved_request_identities"], 0)
            self.assertEqual(client.summary()["actual_http_count"], 0)
            self.assertTrue(any(event.get("event") == "verifier_shadow_unknown" for event in events))
            self.assertFalse(any(event.get("event") == "verifier_shadow_error" for event in events))

    def test_default_off_requires_no_client_tokenizer_caps_or_output(self):
        observer = build_shadow_observer(settings={"enabled": False}, capabilities=None,
            client=None, tokenizer=None, scorer_config=None, rubrics=None,
            output_dir=None, record=None)
        self.assertIsNone(observer)

    def test_acceptance_mode_rejected_before_any_client_or_model(self):
        with self.assertRaises(ValueError):
            build_shadow_observer(settings={"enabled": True, "mode": "acceptance",
                "acceptance_enabled": True}, capabilities=None, client=None,
                tokenizer=None, scorer_config=None, rubrics=None, output_dir=None, record=None)

    def test_blind_boundary_copies_messages_and_rejects_metadata_keys(self):
        messages = [{"role": "user", "content": "Original question"}]
        row = blind_rollout_observation(task_messages=messages, reasoning="Reasoning",
            final_content="Answer", opaque_candidate_id="a"*64, completed=False)
        row["task"]["messages"][0]["content"] = "attempted mutation"
        self.assertEqual(messages[0]["content"], "Original question")
        self.assertEqual(row["operational"], {"status": "unknown", "completed": False, "finish_reason": None})
        with self.assertRaises(ValueError):
            blind_rollout_observation(task_messages=[dict(messages[0], gold_answer="yes")],
                reasoning="Reasoning", final_content="Answer", opaque_candidate_id="a"*64, completed=True)


if __name__ == "__main__":
    unittest.main()
