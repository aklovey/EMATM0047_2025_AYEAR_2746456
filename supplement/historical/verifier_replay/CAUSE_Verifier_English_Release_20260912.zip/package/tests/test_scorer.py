import copy
import json
import math
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cause_verifier.client import HTTPRecord
from cause_verifier.core import CRITERIA, content_hash
from cause_verifier.scorer import (
    ScorerConfig, ScorerPreflightError, bind_operational_status,
    parse_completion_distribution, render_score_prefix, review_messages,
    run_frozen_replay, sanitize_blind_candidate, verify_frozen_pool_manifest,
)
from cause_verifier.shadow import shadow_hook


class ToyTokenizer:
    """A deterministic mock tokenizer, not model or service capability evidence."""
    def encode(self, text, add_special_tokens=False):
        return list(map(ord, text))

    def decode(self, ids, skip_special_tokens=False):
        return "".join(map(chr, ids))

    def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=False,
                            continue_final_message=False, **kwargs):
        value = "".join("<" + item["role"] + ">" + item["content"] + "\n" for item in messages)
        if continue_final_message:
            value = value.rstrip()
        elif add_generation_prompt:
            value += "<assistant>"
        return value


class BrokenPrefixTokenizer(ToyTokenizer):
    def encode(self, text, add_special_tokens=False):
        ids = super().encode(text, add_special_tokens)
        if text.endswith("[score]A"):
            return ids[:-2] + [99999]
        return ids


def config():
    return ScorerConfig(model_id="local-qwen", model_revision="weights-v1",
        tokenizer_hash="tokenizer-v1", template_hash="template-v1", run_id="mock-run-only",
        max_model_len=10000, max_requests=12, max_tokens=500000)


def capabilities():
    return {"status": "PASS", "model_id": "local-qwen", "model_revision": "weights-v1",
        "endpoint": "http://127.0.0.1:8000", "tokenizer": {"tokenizer_sha256": "tokenizer-v1",
            "chat_template_sha256": "template-v1", "single_token_labels": {"status": "PASS"}},
        "capabilities": {"exact_raw_completion": {"status": "PASS", "logprobs_mode": "raw_logprobs",
            "response_parser": "completion_token_id_keys_v1", "prompt_token_ids_supported": True,
            "request_fields": {"logprobs": 20, "logprob_token_ids": [], "return_tokens_as_token_ids": True},
            "evidence_refs": ["MOCK_CAPABILITY_NOT_REAL_SERVICE_PROOF"]}}}


def candidate(cid="candidate-1"):
    task = {"messages": [{"role": "user", "content": "Is observational conditioning equal to intervention in the stated model?"}]}
    return {"candidate_id": cid, "task_id": "task_" + content_hash(task)[:20], "task": task,
            "rollout": {"reasoning": "Check the causal definitions against the given assumptions.", "final_content": "Not generally."}}


def rubrics():
    return json.loads((Path(__file__).resolve().parents[1] / "rubrics.json").read_text(encoding="utf-8"))


def operational(cid="candidate-1"):
    return {cid: {"status": "valid", "completed": True, "finish_reason": "stop"}}


class FakeClient:
    endpoint = "http://127.0.0.1:8000"

    def __init__(self, output, *, review_failure=None, score_failure=None):
        self.output, self.calls = Path(output), []
        self.review_failure, self.score_failure = review_failure, score_failure

    def post(self, path, payload, *, request_id, stage, qid, candidate_id, prompt_tokens):
        assert (self.output / "review_preflight.json").exists(), "All reviews must be frozen before any mock call"
        self.calls.append({"path": path, "payload": copy.deepcopy(payload), "stage": stage, "request_id": request_id})
        usage = {"prompt_tokens": prompt_tokens, "completion_tokens": 8, "total_tokens": prompt_tokens + 8}
        if stage == "verifier_review":
            message, finish = {"content": "The candidate preserves the query; the evidence is insufficient for causal identification."}, "stop"
            if self.review_failure == "length":
                finish = "length"
            elif self.review_failure == "empty":
                message = {"content": " ", "reasoning": None}
            elif self.review_failure == "reasoning_only":
                message = {"content": None, "reasoning": "Review text is returned in the reasoning field."}
            elif self.review_failure == "usage_mismatch":
                usage["prompt_tokens"] += 1
            body = {"choices": [{"index": 0, "message": message, "finish_reason": finish}], "usage": usage}
        else:
            assert (self.output / "score_preflight.json").exists(), "Every actual score payload must be frozen before first read"
            assert path == "/v1/completions"
            assert isinstance(payload["prompt"], list) and all(isinstance(i, int) for i in payload["prompt"])
            assert payload["max_tokens"] == 1
            values = {"token_id:" + str(i): math.log(.04) for i in payload["logprob_token_ids"]}
            if self.score_failure == "missing":
                values.pop(next(iter(values)))
            elif self.score_failure == "nan":
                values[next(iter(values))] = math.nan
            body = {"choices": [{"index": 0, "text": "A", "finish_reason": "length",
                    "logprobs": {"tokens": ["token_id:65"], "top_logprobs": [values]}}],
                    "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": 1, "total_tokens": prompt_tokens + 1}}
        return HTTPRecord(request_id, "OK", 200, body, usage=body["usage"], transport_attempted=True,
                          response_received=True, response_complete=True)


class ScorerTests(unittest.TestCase):
    def run_mock(self, temporary, **kwargs):
        output = Path(temporary) / "run"
        client = FakeClient(output, **kwargs)
        result = run_frozen_replay(candidates=[candidate()], rubrics=rubrics(), client=client,
                tokenizer=ToyTokenizer(), capabilities=capabilities(), config=config(),
                output_dir=output, operational_status=operational())
        return result, client, output

    def test_two_phase_real_api_shape_mock_exact_and_discrete_same_distribution(self):
        with tempfile.TemporaryDirectory() as temporary:
            result, client, output = self.run_mock(temporary)
            self.assertEqual([call["stage"] for call in client.calls], ["verifier_review"] * 3 + ["verifier_score_read"] * 3)
            self.assertEqual(result["valid_score_records"], 3)
            self.assertEqual(result["new_rollout_requests"], 0)
            self.assertFalse(result["acceptance_enabled"])
            self.assertEqual(result["verifications"][0]["verification"]["status"], "unknown")
            scores = json.loads((output / "score_records.json").read_text(encoding="utf-8"))
            self.assertEqual({row["criterion"] for row in scores}, set(CRITERIA))
            for row in scores:
                self.assertAlmostEqual(row["score"], .5)
                self.assertEqual(row["discrete_score"], 1.0)
                self.assertEqual(row["candidate_hash"], content_hash(candidate()["rollout"]))
                self.assertEqual(len(row["labels"]), 20)
                self.assertIsNotNone(row["cache_key"])
            for call in client.calls:
                self.assertNotIn("logit_bias", call["payload"])
                self.assertNotIn("structured_outputs", call["payload"])
                self.assertNotIn("gold", json.dumps(call["payload"]))

    def test_truncated_empty_and_template_mismatch_review_never_read_score(self):
        for failure in ("length", "empty", "usage_mismatch"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary:
                result, client, _ = self.run_mock(temporary, review_failure=failure)
                self.assertEqual(len(client.calls), 3)
                self.assertEqual(result["valid_score_records"], 0)
                self.assertEqual(result["invalid_score_records"], 3)

    def test_reasoning_only_review_is_allowed_but_score_goes_through_raw_completion(self):
        with tempfile.TemporaryDirectory() as temporary:
            result, client, _ = self.run_mock(temporary, review_failure="reasoning_only")
            self.assertEqual(result["valid_score_records"], 3)
            self.assertEqual([call["path"] for call in client.calls[-3:]], ["/v1/completions"] * 3)

    def test_missing_distribution_and_nan_are_unknown_without_retry(self):
        for failure in ("missing", "nan"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temporary:
                result, client, _ = self.run_mock(temporary, score_failure=failure)
                self.assertEqual(len(client.calls), 6)
                self.assertEqual(result["valid_score_records"], 0)
                self.assertEqual(result["invalid_score_records"], 3)

    def test_original_failed_rollout_preserved_with_all_three_unknown_and_no_calls(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "run"
            client = FakeClient(output)
            state = operational()
            state["candidate-1"]["completed"] = False
            result = run_frozen_replay(candidates=[candidate()], rubrics=rubrics(), client=client,
                tokenizer=ToyTokenizer(), capabilities=capabilities(), config=config(), output_dir=output,
                operational_status=state)
            self.assertEqual(client.calls, [])
            self.assertEqual(result["criterion_records"], 3)
            self.assertEqual(result["invalid_score_records"], 3)

    def test_capability_identity_partial_probe_and_missing_tokenization_block_before_calls(self):
        for field, value in (("model_revision", "other"), ("model_id", "other"), ("endpoint", "http://127.0.0.1:8001"), ("status", "PARTIAL")):
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temporary:
                caps = capabilities()
                caps[field] = value
                client = FakeClient(Path(temporary) / "run")
                with self.assertRaises(ScorerPreflightError):
                    run_frozen_replay(candidates=[candidate()], rubrics=rubrics(), client=client,
                        tokenizer=ToyTokenizer(), capabilities=caps, config=config(),
                        output_dir=client.output, operational_status=operational())
                self.assertEqual(client.calls, [])

    def test_all_review_payloads_preflight_without_service_and_budget_excess_has_zero_calls(self):
        with tempfile.TemporaryDirectory() as temporary:
            result = run_frozen_replay(candidates=[candidate()], rubrics=rubrics(), client=None,
                tokenizer=ToyTokenizer(), capabilities={}, config=config(),
                output_dir=Path(temporary) / "plan", operational_status=operational(), preflight_only=True)
            self.assertEqual(result["model_requests"], 0)
            self.assertEqual(result["preflight"]["planned_http_max"], 6)
            self.assertFalse(result["preflight"]["score_payloads_known"])
            self.assertEqual(len(result["preflight"]["requests"]), 3)
        with tempfile.TemporaryDirectory() as temporary:
            client = FakeClient(Path(temporary) / "run")
            with self.assertRaises(ScorerPreflightError):
                run_frozen_replay(candidates=[candidate()], rubrics=rubrics(), client=client,
                    tokenizer=ToyTokenizer(), capabilities=capabilities(), config=replace(config(), max_tokens=10),
                    output_dir=client.output, operational_status=operational())
            self.assertEqual(client.calls, [])

    def test_actual_prefix_marker_survives_rstrip_but_merging_is_rejected(self):
        rubric = rubrics()["criteria"][0]
        messages = review_messages(candidate(), rubric, [])
        self.assertIn("20 ordered", messages[0]["content"])
        prefix, ids, labels = render_score_prefix(ToyTokenizer(), messages, "review", config())
        self.assertTrue(prefix.endswith("[score]"))
        self.assertEqual(labels["A"][0].token_id, ord("A"))
        with self.assertRaises(ScorerPreflightError):
            render_score_prefix(BrokenPrefixTokenizer(), messages, "review", config())

    def test_extra_metadata_and_oracle_content_fields_not_admitted(self):
        contaminated = candidate()
        contaminated["operation"] = "DELETE"
        with self.assertRaises(ScorerPreflightError):
            sanitize_blind_candidate(contaminated)
        contaminated = candidate()
        contaminated["task"]["gold_answer"] = "hidden"
        with self.assertRaises(ScorerPreflightError):
            sanitize_blind_candidate(contaminated)

    def test_original_task_and_rollout_binding_reject_swapped_question_or_chain(self):
        row = candidate()
        raw = {"candidate_id": row["candidate_id"], "task_id": row["task_id"], "candidate_hash": content_hash(row["rollout"]), "status": "valid"}
        request = {"candidate_id": row["candidate_id"], "original_request": {"state": "completed", "valid": 1,
            "finish_reason": "stop", "complete_chain": row["rollout"]["reasoning"], "final_content": row["rollout"]["final_content"]}}
        self.assertTrue(bind_operational_status([row], [raw], [request])[row["candidate_id"]]["completed"])
        for change_id in (False, True):
            changed = copy.deepcopy(row)
            changed["task"]["messages"][0]["content"] = "Different original question"
            if change_id:
                changed["task_id"] = "task_" + content_hash(changed["task"])[:20]
            with self.assertRaises(ScorerPreflightError):
                bind_operational_status([changed], [raw], [request])
        changed = copy.deepcopy(row)
        changed["rollout"]["reasoning"] = "Different unseen chain"
        with self.assertRaises(ScorerPreflightError):
            bind_operational_status([changed], [raw], [request])

    def test_manifest_rejects_changed_pool_and_extra_duplicate_sample(self):
        row = candidate()
        raw = dict(candidate_id=row["candidate_id"], task_id=row["task_id"], decision_group_id="group1", question_id=1)
        manifest = {"blind_payload_hash": content_hash([row]), "frozen_raw_rollout_count": 1,
                    "groups": [{"task_id": row["task_id"], "decision_group_id": "group1", "question_id": 1,
                                "raw_sample_ids": [row["candidate_id"]]}]}
        verify_frozen_pool_manifest([row], [raw], manifest)
        with self.assertRaises(ScorerPreflightError):
            verify_frozen_pool_manifest([row, row], [raw], manifest)
        with self.assertRaises(ScorerPreflightError):
            verify_frozen_pool_manifest([row], [raw, raw], manifest)

    def test_score_parser_refuses_multiple_positions_or_wrong_prompt_length(self):
        body = {"choices": [{"logprobs": {"tokens": ["token_id:65", "token_id:66"],
                    "top_logprobs": [{"token_id:65": -.1}, {"token_id:66": -.2}]}, "finish_reason": "length"}]}
        with self.assertRaises(ScorerPreflightError):
            parse_completion_distribution(body, prompt_tokens=10)
        body["choices"][0]["logprobs"] = {"tokens": ["token_id:65"], "top_logprobs": [{"token_id:65": -.1}]}
        body["usage"] = {"prompt_tokens": 11, "completion_tokens": 1}
        with self.assertRaises(ScorerPreflightError):
            parse_completion_distribution(body, prompt_tokens=10)

    def test_shadow_callback_preserves_object_identity_even_when_logger_fails(self):
        expected, seen = object(), []
        def callback(value):
            seen.append(value)
            return expected
        def bad_log(_):
            raise OSError("mock full disk")
        wrapped = shadow_hook(callback, parent_id="parent", parent_rollout="original", candidates=[], record=bad_log)
        self.assertIs(wrapped("argument"), expected)
        self.assertEqual(seen, ["argument"])

    def test_existing_output_never_restarts_or_resends_run(self):
        with tempfile.TemporaryDirectory() as temporary:
            result, client, output = self.run_mock(temporary)
            before = len(client.calls)
            with self.assertRaises(ScorerPreflightError):
                run_frozen_replay(candidates=[candidate()], rubrics=rubrics(), client=client,
                    tokenizer=ToyTokenizer(), capabilities=capabilities(), config=config(), output_dir=output,
                    operational_status=operational())
            self.assertEqual(len(client.calls), before)


if __name__ == "__main__":
    unittest.main()
