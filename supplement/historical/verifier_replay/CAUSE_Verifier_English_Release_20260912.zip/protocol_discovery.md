# Read-only identification of the CAUSE PNS protocol and actual candidate pool

Review date 2026-09-09. This subtask performed only read-only checks on the local machine. It sent no model requests, started or stopped no services, and did not modify D:\CAUSE, historical experiment directories, data or SQLite databases. All SQLite connections used `mode=ro`. The search was restricted to the specified CAUSE roots, PNS directories identified by directory indexes, and original experiment roots located through memory.

## 1. Authoritative paths and version boundaries

| Purpose | Path verified on the machine | Status and availability |
|---|---|---|
| Latest local adaptive runner snapshot | `D:\CAUSE\qwen_pns_adaptive_20260826\runtime_v1` | Contains actual execution code with policy version `qwen_pns_adaptive_rollout_v1`, rather than the fixed two-trial mode from 8/17. The directory has no Git repository of its own and is an untracked directory under D:\CAUSE. |
| Latest local service scripts | `D:\CAUSE\qwen_pns_adaptive_20260826\service\launch_qwen_pns_adaptive_service.py`, `launch_qwen_pns_adaptive_service_gpu085.py` | These locate historical deployments only and do not establish that the current AutoDL service parameters or paths are unchanged. |
| Adaptive execution checkpoint | `D:\CAUSE\qwen_pns_adaptive_20260826\checkpoint_before_gpu2_v1\journal.sqlite3` | Read-only queries found 520 actual requests, comprising KEEP completed245, DELETE completed227, KEEP posting30 and DELETE posting18 across 48 questions. This is an incomplete historical checkpoint. Files or locks do not establish that it is currently active. |
| Adaptive prepare checkpoint | `D:\CAUSE\qwen_pns_adaptive_20260826\remote_prepare_snapshot_v1\journal.sqlite3` | requests=0 |
| Completed fixed candidate pool, preferred for replay | `C:\Users\aklovey\Documents\Codex\2026-08-17\qwen36-pns-256\outputs\qwentest100_demo56_pns_final_20260817\pns_item_results_56.jsonl` | Parsing on the machine found 56 questions and 6858 actual suffix observations, rather than only the selected short traces. |
| Completed original full journal, preferred as evidence of original requests | `C:\Users\aklovey\Documents\Codex\2026-08-17\qwen36-fewshot-icl-pilot\outputs\pns56_final_extracted_20260817\final\journal_snapshot.sqlite3` | Confirmed to exist; read-only queries found 6910 records, all completed/scientific_invalid. |
| Complete backup archive | `C:\Users\aklovey\Documents\Codex\2026-08-17\qwen36-pns-256\outputs\qwentest100_demo56_pns_final_20260817\qwentest100_demo56_pns_final.tar.gz` | 167924677 bytes, with a historical acceptance record. It was not unpacked again in this check. |
| Frozen inputs corresponding to the candidates | `C:\Users\aklovey\Documents\Codex\2026-08-17\qwen36-pns-256\work\batch56\batch_input_56.jsonl` | Exists. `D:\CAUSE\qwen_pns_adaptive_20260826\runtime_v1\runtime_bundle\batch_input_56.jsonl` is also available. Replay inputs should preferably be extracted from original journal items or inputs referenced by acceptance records and checked question by question. |
| Original method contract | `D:\CAUSE_SYNC\packages\worker\handoffs\qwen_pns_logic_reference_20260817\docs\PNS_METHOD_CN.md` | Read. It explicitly includes every pre-answer-exposure step in the intervention, with 2 KEEP and 2 DELETE trials and, when triggered, one replacement generation plus 2 REPLACE trials. |
| Entry point for the synchronised copy of the historical full pool | `D:\CAUSE_SYNC\evidence\worker\projects\2026-08-17\qwen36-pns-256` | Located through W008 in experiment_evidence_catalog.csv. The original path was preferred in this check. |

`D:\CAUSE` Git HEAD = `1b9ee57d0981bd42c00a3bb64ae3d57ece6cd7a8`, dated 2026-07-17 22:47:07+0100. User modifications and untracked files already exist in several places, including the latest adaptive directory. Do not overwrite or reset them directly. The original `qwen36-pns-256` project root is not a Git repository, so the D:\CAUSE commit cannot be used as its version. A restricted `rg --files -g AGENTS.md` search found no experiment-local AGENTS files in the relevant directories. The workstation rules supplied by the parent task still apply.

`D:\CAUSE_SYNC\README.md` describes D:\CAUSE as a lower-priority dirty copy. New experiments are identified by independent Codex projects and actual execution evidence. D:\CAUSE_CACHE contains only pip/HuggingFace/temporary caches and old startup CMD files, with no formal PNS pool. No SSH/connect address script was found in the current snapshot/service directories or original PNS archives. No passwords or private keys were extracted or output.

## 2. The fixed 8/17 protocol and new adaptive 8/26 protocol are different distributions

The fixed pool uses the old protocol. For each pre-answer-exposure step, the KEEP prefix is `parent[:segment.char_end]` and the DELETE prefix is `parent[:segment.char_start]`, with 2 trials for each. A replacement step is generated only when the KEEP success count is strictly greater than DELETE. If generation succeeds, the same text is frozen and 2 REPLACE suffixes are run. A complete trace is that branch's frozen_prefix plus the current reasoning_suffix; different branches must not be concatenated.

The new adaptive defaults are `initial_valid_rounds=2,max_valid_rounds=5,max_raw_attempts_per_lineage=10`. KEEP/DELETE voting uses only matched valid rounds, excluding execution errors. It stops when the sign of the final difference over the prespecified 5 rounds can no longer change, or after 5 rounds. REPLACE candidates also use this adaptive lineage logic, so the latest policy cannot still be summarised as always using REPLACE2. The new policy outputs raw attempt and invalid counts and must be labelled adaptive, rather than treated as a fixed M=2 probability estimate.

Key evidence

- `runtime_v1/src/qwen_pns_adaptive.py:21` contains the default configuration; `:50` the seed; `:220` the difference-based stopping rule; `:556` the full-question traversal; `:615` frozen replacement text; and `:659` output budgets.
- `runtime_v1/src/qwen_pns_batch56_adapter.py:355` contains run_item; `:390` extracts every unexposed step; `:395` checks safe_step_count; and `:435` passes all eligible_steps, with no CLI for trimming targets.
- `runtime_v1/runtime_bundle/batch56_runner.py:1279` enforces the fixed 56-question input; `:1312` enforces 1691 safe steps; and `:2680` exposes only input/run-dir/base-url/prepare-only/execute in the CLI.
- `runtime_v1/scripts/run_qwen_pns_adaptive.py` likewise has no qid/target/step filter and exposes only options such as configured round counts and run-dir.

## 3. Frozen generation, continuation, token, seed and retry settings

`runtime_bundle/batch56_runner.py:38-49,1410-1471,1840-1875`:

- The model is `Qwen/Qwen3.6-35B-A3B`. Suffix generation uses `/v1/completions` with `prompt=base_serialized_prompt+frozen_prefix`, rather than opening a new assistant message. The original base prompt's `<think>` boundary must be checked by regression comparison between the local tokenizer and actual service.
- The requested suffix cap is 8000, the replacement cap is 1024, the context length is 16384, and the reserve is 128. The effective cap is `min(request_cap,16384-prompt_tokens-128)`.
- Generation parameters are `temperature=1.0,top_p=0.95,top_k=20,min_p=0,repetition_penalty=1,presence_penalty=0,frequency_penalty=0,n=1,stream=false,ignore_eos=false,include_stop_str_in_output=false,return_token_ids=true`.
- Replacement generation uses `/v1/chat/completions` with `enable_thinking=false,preserve_thinking=false`. It sees only the question, the parent trace's preceding prefix and the original target step, without gold, old suffixes or the old final answer.
- The original seed is `20260817 + (((qid*256+step)*8+branch_code)*4+rollout)`, with keep1/delete2/replace3/replacement_generate4. Replacement generation uses r0; the others use r1/r2.
- Adaptive retains the original r0-r3 seeds and changes r4-r10 to `1000000000+cell*7+rollout-4`, where `cell=(qid*256+step)*8+branch_code`. Duplicate seeds must not be added arbitrarily and counted as new repeated reviews or new samples.
- SQLite reserves before POST. An existing identical identity reuses its record only; reserved/posting recovers as unknown_no_resend and cannot be POSTed again. Failures must not be duplicated by rerunning requests. See `batch56_runner.py:616-767`.
- The request-field allowlist excludes gold/oracle/selection labels. Gold remains in the local scoring sidecar of RequestTask. The path audit can read audit_reference, so it is offline oracle-assisted and cannot be inserted directly into an online no-gold verification prompt.
- For actual rollouts, `length`, empty content, parse failure and communication failure are invalid. Score-reading with max_tokens=1/length must be handled separately by phase in the new module rather than inheriting the rollout truncation rule.

## 4. Full pool and candidate fields

Counts obtained by reading the complete JSONL and SQLite files on the machine

- 56 questions, comprising det-counterfactual36, nie9, ate6, ett3 and nde2.
- 6858 suffix observations, comprising KEEP3382, DELETE3382 and REPLACE94; 6627 valid+answer_correct, 202 valid+answer_wrong and 29 invalid. Here, `answer_correct` denotes only the legacy answer-equivalence check, not an independent trajectory-validity label.
- Exactly 2 actual candidates in each of 3429 `(qid,step,condition)` groups. This fixed pool can therefore report only M=1,2 for those groups. Different targets must not be pooled into M=4/8/16/32, and samples must not be copied to fill M.
- 52 additional replacement-generation requests, comprising 47completed+5scientific_invalid, giving original HTTP=6858+52=6910.
- Current read-only checks of the full journal found DELETE completed3367/invalid15, KEEP3371/11, REPLACE91/3 and replacement_generate47/5.
- The smallest complete-question observation counts are qid29590=40, 29980=44, 10009=52 and 9686=56.

Top-level item JSONL fields are `schema_version,item_id,question_id,query_type,status,parent_reasoning_tokens,parent_reasoning_chars,segments,replacement_triggered_steps,replacement_errors,observations,shortlist,audits,selection,metrics`.

Each observation contains `candidate_key,request_key,branch_id,intervention,step_index,trial,prefix,reasoning_suffix,full_reasoning,final_content,predicted_answer,observation_valid,answer_correct,reasoning_tokens,reasoning_chars,latency_ms,usage,error`.

Original journal request fields are `request_seq,request_id,request_key,qid,step_index,branch,rollout,seed,endpoint,prompt_key,headers_json,request_json,state,reserved_at,posting_at,response_received_at,completed_at,latency_seconds,http_status,raw_response_text,response_json,finish_reason,provider_prompt_token_ids_json,output_token_ids_json,provider_usage_json,reasoning_suffix,final_content,parsed_answer,valid,correct,invalid_reason,failure_class,complete_chain,chain_token_count,chain_token_ids_json,replacement_text`.

Frozen input fields are `schema_version,question_id,query_type,messages,base_serialized_prompt,parent_reasoning,parent_final_content,parent_answer,gold_answer,parent_reasoning_tokens_stored,parent_reasoning_chars,frozen_first_answer_exposure_unit,effective_first_answer_exposure_unit,safe_step_count,segments,audit_reference`. Online scoring uses only original question messages, complete candidate text and independent evidence permitted by the protocol. Intervention names, legacy answer correctness, selection labels and hidden oracle content in audit_reference should be stored separately.

## 5. Conclusions on the 10-question replay and online limit

The actual data needed for a 10-question replay exists. A deterministic qid list with 2 questions from each of five types can be frozen in advance, for example det-counterfactual29590/29980, ate4171/4274, ett4255/19407, nde18188/24894 and nie1428/8752. This is not selection by effectiveness, and questions must not be replaced after freezing because of poor scores. The scoring subpool should state the selected target, condition and original request_key and retain a complete source-pool manifest. A selected subpool must not be presented as complete coverage of every condition. Each candidate's new scores must be reported separately for the three criteria. Argmax discrete scores and expected scores are derived from the same review/distribution, with no extra request for the discrete score. Available independent labels currently consist only of answer equivalence and historical path audits for a small number of shortlist entries. Independent semantic labels for all 6858 observations have not been established, so three-criterion identification accuracy cannot be claimed from these records.

**The original full-question runner has no valid online path with <=32 additional rollouts.** The shortest question under the fixed legacy protocol has 10 safe steps and requires at least 40 suffixes. The two shortest questions have 10+11 steps and require at least 84 suffixes; if every replacement is triggered and generated successfully, the maximum is 126 suffixes+21 replacement generations=147 HTTP. Adaptive cannot stop at the default 2 rounds. At 2 rounds, the maximum difference is 2 with 3 remaining, so the sign is not fixed; normally the earliest stop is after 3 rounds. The shortest full question requires at least 60, and two questions at least 126, with a raw cap of 10 per lineage and a higher full upper bound. The direct CLI also enforces 56 questions/1691steps and does not accept a small 2-question input.

`C:\Users\aklovey\Documents\Codex\2026-08-17\qwen36-pns-256\work\minimal_probe1\run_live_microprobe.py` exists. It is a historical independent RAW-prefix capability probe for qid10096/step10 with exactly 4 KEEP/DELETE suffixes and fixed historical seeds, not a complete PNS question or complete REPLACE decision group. Its capability-regression implementation may be referenced, but rerunning historical seeds must not be counted as a new independent formal experiment or presented as a passed online PNS experiment.

Under section 8 of the user-authorised document, the formal online phase should therefore be marked `NOT_RUN_PROTOCOL_MINIMUM_EXCEEDS_32`, with budgets of 40/84 for the old protocol or 60/126 for the normal adaptive minimum. Preserve the old acceptance behaviour and complete the actual fixed-pool replay and service capability probes. If the user explicitly authorises a new single-target smoke protocol in future, document it as a new protocol rather than silently changing the old within-question traversal.

## 6. Inspection script and memory sources for the parent task

The read-only inspection script for this task is `work/inspect_protocol_assets.py`, run with `python work/inspect_protocol_assets.py`. It queries only the fixed paths above and outputs fields/counts, without outputting original question text or secrets.

Memory was used for discovery through `MEMORY.md:241-298` and `rollout_summaries/2026-08-17T02-41-19-CbM1-qwen36_pns_256_offline_validation_formal_run_and_artifact_ac.md` with thread_id `01a00d98-49ae-7382-a86a-00ce901a53cd`. Key pool fields, counts, the latest adaptive policy and local Git status were all reread from current files, rather than relying only on memory.
