# Frozen replay of actual candidates

This directory contains a fixed replay subpool of 10 questions and 42 original suffix candidates. It is not an additional PNS experiment.
The two questions declared in advance are selected for each of five question types. The earliest valid target is selected for each question, retaining all actual conditions and both trials in that group.
The pool includes 1 original invalid candidate. No question was removed or replaced because of a poor result or format failure. Actual M=2 in every group, so only the M=1,2 coverage points can be reported.

- `blind_candidates.jsonl` is the only candidate input that may be passed to the scoring-prompt builder. Its fields contain only opaque candidate/question IDs, original question messages, and each candidate's complete reasoning and final_content.
- `raw_rollouts.jsonl` contains original observations and accounting metadata for questions, conditions, targets, failures and related information. It must not be passed wholesale into a scoring prompt.
- `original_requests.jsonl` contains original request/response/usage/token assets individually verified against the candidates. Headers have been excluded.
- `offline_labels.jsonl` contains legacy offline answer-equivalence labels. They are not ground-truth labels for the three causal-trajectory criteria and cannot enter online prompts.
- `manifest.json` records the rules declared in advance, qid order, per-group counts, source-file hashes and blind-review content hashes. Repeated preparation is permitted only when content is identical.
- `coverage_before_scoring.json` contains M1/M2 points without pooling questions, targets or conditions. Answer-only coverage is reported separately; OracleValid/SelectedValid/OracleImprovement are all unknown.
- `statistics_before_scoring.json` contains empty scoring statistics from the stage before model execution. All scores are missing and accuracy is unknown. It must not be described as a completed model replay.

query_fidelity, derivation_validity and conclusion_support are scored separately.
The argmax discrete score and continuous expectation are calculated from the same complete raw distribution. No additional discrete-baseline call is made, and the three criteria are not averaged.
All 42 original samples are retained. If no scoring HTTP request is sent for the 1 original invalid candidate, explicit UNKNOWN records must be saved for its three criteria without reducing the original sample denominator.
For 41 complete candidates, C=3 and K=1, exactly 1 review plus 1 score-read per criterion would require 246 HTTP requests. Each extra request for an official compare/probe or another purpose is counted separately.
Without independent calibration, acceptance is not enabled. Incorrect acceptances, correct rejections and joint accuracy cannot be estimated from answer labels.

Statistics command, for use when actual scores are available

```text
python scripts/analyze_replay.py --replay-dir <this-directory> --scores <score-records.jsonl> --output <new-statistics.json>
```

The trusted toy SCM interface is `src/cause_verifier/evidence.py:run_toy_confounding_check`, which enumerates only the two exogenous worlds of the specified toy model.
It is not the SCM for these 10 actual questions. A pass on the toy model must not be used as experimental evidence for these candidates.
