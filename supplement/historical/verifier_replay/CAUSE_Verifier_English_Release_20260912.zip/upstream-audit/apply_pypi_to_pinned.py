"""Apply only the audited PyPI 0.2.0 -> Git 8db8a114 source delta.

No imports of the target package, dependency installation, or network access.
Only an explicitly named module inside the explicitly named client venv changes.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile

OLD = "52a30b2be884876f7710c3b9ff2b9918cc2b8b10ce4a7dc7e22f4111fe201074"
NEW = "3f5adc9d47ce995ce1cf7a2273bcf8ec382bbde1a6497e4e88f5bc819974450e"
COMMIT = "8db8a114355a9d7fdf9a8d1d5c87f6aeebd18770"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def apply_patch(target_path, prefix_path, patch_path, apply=False):
    supplied_target = Path(target_path)
    if supplied_target.is_symlink():
        raise ValueError("Refusing a symlinked target")
    prefix = Path(prefix_path).resolve(strict=True)
    target = supplied_target.resolve(strict=True)
    if not prefix.is_dir() or prefix == Path(prefix.anchor):
        raise ValueError("Explicit client-venv directory required")
    try:
        target.relative_to(prefix)
    except ValueError:
        raise ValueError("Resolved target escapes the explicitly named client venv")
    if target.name != "fine_grained_reward.py" or target.parent.name != "llm_verifier":
        raise ValueError("Target is not the one approved module")
    if not target.is_file():
        raise ValueError("Expected one existing regular source file")
    patch = json.loads(Path(patch_path).read_text(encoding="utf-8-sig"))
    if (patch.get("original_sha256") != OLD or patch.get("target_sha256") != NEW
            or patch.get("target_commit") != COMMIT
            or patch.get("target_relative_path") != "llm_verifier/fine_grained_reward.py"):
        raise ValueError("Patch metadata differs from the hardcoded audited identities")
    original = target.read_bytes()
    current = sha(original)
    backup = target.with_name(target.name + ".pypi-0.2.0." + OLD[:16] + ".bak")
    report = {"target": str(target), "client_venv": str(prefix), "target_commit": COMMIT,
              "original_sha256": current, "expected_target_sha256": NEW,
              "backup": str(backup), "patch_sha256": sha(Path(patch_path).read_bytes())}
    if current == NEW:
        report.update(status="ALREADY_PINNED_VERIFIED", written=False,
                      backup_verified=backup.is_file() and not backup.is_symlink()
                      and sha(backup.read_bytes()) == OLD)
        return report
    if current != OLD:
        raise ValueError("Current source hash is neither approved PyPI source nor pinned target; no write")
    text = original.decode("utf-8")
    hunks = patch.get("hunks")
    if not isinstance(hunks, list) or len(hunks) != 2:
        raise ValueError("Expected exactly the two audited text hunks")
    for hunk in hunks:
        old, new = hunk["old"], hunk["new"]
        if not old or text.count(old) != 1:
            raise ValueError("A hunk's original text is not uniquely present")
        text = text.replace(old, new, 1)
    replacement = text.encode("utf-8")
    if sha(replacement) != NEW or len(replacement) != patch["target_bytes"]:
        raise ValueError("Constructed replacement is not byte-identical to the audited Git source")
    # Compiles the text only; it does not import or execute the verifier module.
    compile(text, str(target), "exec", dont_inherit=True)
    if not apply:
        report.update(status="DRY_RUN_VERIFIED", written=False,
                      constructed_sha256=NEW, replacement_bytes=len(replacement))
        return report
    if backup.is_symlink():
        raise ValueError("Refusing a symlinked backup")
    if backup.exists():
        if not backup.is_file() or sha(backup.read_bytes()) != OLD:
            raise ValueError("Existing backup is not the exact original PyPI source")
    else:
        with backup.open("xb") as stream:
            stream.write(original)
            stream.flush()
            os.fsync(stream.fileno())
    if sha(backup.read_bytes()) != OLD or sha(target.read_bytes()) != OLD:
        raise ValueError("Backup or live source changed before replacement")
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=target.parent,
                prefix=".fine_grained_reward.pinned.", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(replacement)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, stat.S_IMODE(target.stat().st_mode))
        if sha(temporary.read_bytes()) != NEW or sha(target.read_bytes()) != OLD:
            raise ValueError("Source changed during atomic-write preparation")
        os.replace(temporary, target)
        temporary = None
        if sha(target.read_bytes()) != NEW:
            raise RuntimeError("Post-write target verification failed; original backup remains intact")
        report.update(status="PATCHED_AND_VERIFIED", written=True,
                      final_sha256=NEW, backup_verified=sha(backup.read_bytes()) == OLD,
                      package_metadata_note="Version stays 0.2.0; module source is pinned Git bytes, so retain this report alongside pip freeze.")
        return report
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", required=True)
    parser.add_argument("--venv-prefix", required=True)
    parser.add_argument("--patch", required=True)
    parser.add_argument("--apply", action="store_true", help="Without this flag only verifies the constructed replacement")
    parser.add_argument("--report", help="Optional new JSON audit report path")
    args = parser.parse_args()
    if args.report and Path(args.report).exists():
        raise ValueError("Audit report already exists; choose a new report path before any write")
    result = apply_patch(args.target, args.venv_prefix, args.patch, args.apply)
    output = json.dumps(result, ensure_ascii=False, indent=2)
    if args.report:
        with Path(args.report).open("x", encoding="utf-8") as stream:
            stream.write(output + "\n")
    print(output)


if __name__ == "__main__":
    main()
